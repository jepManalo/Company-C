from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DataDrivenComparisonModel:
    measurement: str
    saccharose: Optional[float] = field(default=None)
    glukose: Optional[float] = field(default=None)
    fruktose: Optional[float] = field(default=None)
    milchsaeure: Optional[float] = field(default=None)
    essigsaeure: Optional[float] = field(default=None)
    brenztraubensaeure: Optional[float] = field(default=None)
    bernsteinsaeure: Optional[float] = field(default=None)
    zitronensaeure: Optional[float] = field(default=None)
    ameisensaeure: Optional[float] = field(default=None)
    alanin: Optional[float] = field(default=None)
    cystein: Optional[float] = field(default=None)
    lysin: Optional[float] = field(default=None)
    glutaminsaeure: Optional[float] = field(default=None)
    isoleucin: Optional[float] = field(default=None)
    threonin: Optional[float] = field(default=None)
    phenylalanin: Optional[float] = field(default=None)
    glutamin: Optional[float] = field(default=None)
    phosphorsaeure: Optional[float] = field(default=None)
    ammoniak: Optional[float] = field(default=None)
    schwefelsaeure: Optional[float] = field(default=None)
    nacl: Optional[float] = field(default=None)
