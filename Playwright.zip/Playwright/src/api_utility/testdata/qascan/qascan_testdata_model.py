from dataclasses import dataclass, field
from typing import Optional


@dataclass
class QAScanComparisonModel:
    measurement: str
    histidin: Optional[float] = field(default=None)
    polysorbat80: Optional[float] = field(default=None)
    polysorbat20: Optional[float] = field(default=None)
    trehalose: Optional[float] = field(default=None)
    nacl: Optional[float] = field(default=None)
    methionin: Optional[float] = field(default=None)
    saccharose: Optional[float] = field(default=None)
    zitronensaeure: Optional[float] = field(default=None)
    protein: Optional[float] = field(default=None)
    phosphorsaeure: Optional[float] = field(default=None)
    ph: Optional[float] = field(default=None)
    alphahelix: Optional[float] = field(default=None)
    betasheet: Optional[float] = field(default=None)
    proteinIdsimilarity: Optional[float] = field(default=None)
