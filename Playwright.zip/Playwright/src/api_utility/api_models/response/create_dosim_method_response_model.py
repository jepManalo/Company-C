from dataclasses import dataclass
from typing import List, Optional


@dataclass
class PreprocessorParams:
    deriv: int
    R_compat: bool
    polyorder: int
    presmoothing: bool
    window_length: int


@dataclass
class RoiSelectParams:
    x_scale: dict
    roi_list: List[List[int]]


@dataclass
class Preprocessor:
    method: str
    params: Optional[dict]


@dataclass
class Component:
    id: str
    name: str


@dataclass
class SelectedComponent:
    component: Component
    is_auxiliary: Optional[bool]
    min_concentration: float
    max_concentration: float
    preprocessors: List[Preprocessor]


@dataclass
class DosimResponseModel:
    archived: bool
    comment: Optional[str]
    created_by: str
    created: str
    id: str
    has_evaluations: bool
    maximal_ph: float
    method_type: str
    minimal_ph: float
    name: str
    selected_components: List[SelectedComponent]
    status: str
    status_information: Optional[str]
    updated: str
    validation_result: Optional[str]
    validations: List[str]
