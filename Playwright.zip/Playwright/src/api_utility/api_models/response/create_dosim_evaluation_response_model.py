from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class Component:
    name: str
    unit: str
    value: float


@dataclass
class ComponentReference:
    id: str
    name: str


@dataclass
class Result:
    component: ComponentReference
    unit: str
    value: float


@dataclass
class ResultSummaryData:
    components: List[Component]


@dataclass
class ResultSummary:
    data: List[ResultSummaryData]
    success: bool
    error: Optional[str]


@dataclass
class Method:
    id: str
    name: str


@dataclass
class Measurement:
    acquisition_method: str
    archived: bool
    created: datetime
    id: str
    measurement_timestamp: datetime
    name: str
    source: str
    updated: datetime


@dataclass
class EvaluationResponse:
    archived: bool
    comment: str
    created: datetime
    created_by: str
    id: str
    measurement: Measurement
    method: Method
    name: str
    result_summary: ResultSummary
    results: List[Result]
    status: str
    status_information: Optional[str]
    updated: datetime
