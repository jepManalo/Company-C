from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Component:
    id: str
    name: str


@dataclass
class ComponentEntry:
    component: Component
    unit: str
    value: float


@dataclass
class Result:
    alpha_helix_unit: str
    alpha_helix_value: float
    beta_sheet_unit: str
    beta_sheet_value: float
    components: List[ComponentEntry]
    ph_value: float
    protein_concentration_unit: str
    protein_concentration_value: float
    similarity_value: float


@dataclass
class Measurement:
    acquisition_method: str
    archived: bool
    created: str
    id: str
    measurement_timestamp: str
    name: str
    source: str
    updated: str


@dataclass
class Method:
    id: str
    name: str


@dataclass
class QAScanEvalResponse:
    archived: bool
    comment: str
    created: str
    created_by: str
    id: str
    measurement: Measurement
    method: Method
    name: str
    result: Result
    status: str
    status_information: Optional[str]
    updated: str
