from dataclasses import dataclass
from typing import List, Optional


@dataclass
class IUPACName:
    iupac_id: str
    name: str


@dataclass
class Component:
    formula: str
    id: str
    iupac: List[IUPACName]
    max_concentration: str
    min_concentration: str
    name: str


@dataclass
class ComponentList:
    count: int
    next: Optional[str]
    previous: Optional[str]
    results: List[Component]
