from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class Measurement:
    acquisition_method: str
    archived: bool
    created: datetime
    id: str
    measurement_timestamp: datetime
    name: str
    source: str
    updated: datetime


@dataclass
class MeasurementResponse:
    count: int
    next: Optional[str]
    previous: Optional[str]
    results: List[Measurement]
