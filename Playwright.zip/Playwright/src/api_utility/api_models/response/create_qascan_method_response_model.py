from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class IUPAC:
    iupac_id: str
    name: str


@dataclass
class ComponentInfo:
    id: str
    name: str
    iupac: List[IUPAC] = field(default_factory=list)


@dataclass
class Component:
    component: ComponentInfo
    concentration_buffer: Optional[float] = None
    concentration_formulation: Optional[float] = None
    concentration_limit_lower: Optional[float] = None
    concentration_limit_upper: Optional[float] = None
    main: Optional[bool] = None


@dataclass
class Calibration:
    id: str
    measurement_timestamp: str  # Or datetime
    name: str


@dataclass
class QAScanMethod:
    id: str
    name: str
    method_type: str
    created: str
    updated: str
    created_by: str
    archived: bool
    has_evaluations: bool
    last_step: str
    status: str

    comment: Optional[str] = None
    status_information: Optional[str] = None

    buffer_calibrations: List[Calibration] = field(default_factory=list)
    formulation_calibrations: List[Calibration] = field(default_factory=list)
    components: List[Component] = field(default_factory=list)

    ph_buffer: Optional[float] = None
    ph_formulation: Optional[float] = None
    ph_limit_lower: Optional[float] = None
    ph_limit_upper: Optional[float] = None

    protein_concentration_formulation: Optional[float] = None
    protein_concentration_limit_lower: Optional[float] = None
    protein_concentration_limit_upper: Optional[float] = None

    validations: List = field(default_factory=list)

    with_concentration: Optional[bool] = None
    with_secondary_structure: Optional[bool] = None
    with_similarity: Optional[bool] = None
    with_excipients: Optional[bool] = None
    with_polysorbate: Optional[bool] = None
    with_ph: Optional[bool] = None
