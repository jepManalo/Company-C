from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID


@dataclass
class UploadResponse:
    created: datetime
    error: Optional[str]
    filename: str
    id: UUID
    name: str
    state: str
    updated: datetime
    zip_filename: str
