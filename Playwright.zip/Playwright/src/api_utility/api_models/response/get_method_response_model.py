from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class Results:
    archived: bool
    created: datetime
    created_by: str
    has_evaluations: bool
    id: str
    method_type: str
    name: str
    status: str
    updated: datetime


@dataclass
class MethodList:
    count: int
    next: Optional[str]
    previous: Optional[str]
    results: List[Results]
