import json
from dataclasses import asdict, dataclass, field
from typing import List, Optional


@dataclass
class Component:
    id: str
    main: bool


@dataclass
class QAScanComponentPayload:
    components: List[Component]

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))


@dataclass
class FormulationBuffer:
    id: str


@dataclass
class QAScanFormulationPayload:
    formulation_calibrations: List[FormulationBuffer]

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))


@dataclass
class QAScanBufferPayload:
    buffer_calibrations: List[FormulationBuffer]

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))


@dataclass
class ComponentDetails:
    component_id: str
    concentration_buffer: float
    concentration_formulation: float


@dataclass
class QAScanReferenceValuePayload:
    components: List[ComponentDetails]
    ph_buffer: float
    ph_formulation: float
    protein_concentration_formulation: float
    concentration_custom_range: Optional[float] = field(default=None)
    ph_custom_range: Optional[float] = field(default=None)

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))
