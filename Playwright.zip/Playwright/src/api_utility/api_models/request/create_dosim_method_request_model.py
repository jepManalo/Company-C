import json
from dataclasses import asdict, dataclass
from typing import List


@dataclass
class ComponentPayload:
    id: str
    min_concentration: float
    max_concentration: float


@dataclass
class ValidationDetails:
    component: str
    measurement: str
    concentration: float


@dataclass
class DosimPayload:
    components: List[ComponentPayload]
    max_ph: float
    min_ph: float
    name: str

    def toJson_str(self):
        return json.dumps(asdict(self))

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))
