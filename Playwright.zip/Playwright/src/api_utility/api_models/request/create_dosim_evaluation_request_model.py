import json
from dataclasses import asdict, dataclass
from typing import List


@dataclass
class EvaluationRequest:
    comment: str
    measurements: List[str]
    method: str
    name: str

    def toJson_dict(self):
        return json.loads(json.dumps(asdict(self)))
