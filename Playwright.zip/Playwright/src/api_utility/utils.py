import json
import os
import time
from typing import Callable, List, TypeVar

import src.api_utility.api_deserializer as deserializer
import src.constants as const
from src.api_utility.api_models.request.create_dosim_evaluation_request_model import (
    EvaluationRequest,
)
from src.api_utility.api_models.request.create_dosim_method_request_model import (
    ComponentPayload,
    DosimPayload,
)
from src.api_utility.api_models.request.create_qascan_method_request_model import (
    Component,
    ComponentDetails,
    FormulationBuffer,
    QAScanBufferPayload,
    QAScanComponentPayload,
    QAScanFormulationPayload,
    QAScanReferenceValuePayload,
)
from src.api_utility.api_models.response.create_qascan_method_response_model import QAScanMethod
from src.api_utility.testdata.dosim.dosim_testdata_model import DataDrivenComparisonModel
from src.api_utility.testdata.qascan.qascan_testdata_model import QAScanComparisonModel
from src.utility import build_step2_attribute_string, compare_qascan_details, count_files_in_zip

T = TypeVar("T")


def get_status(client, base_url: str, endpoint: str):
    """
    Fetches the status from any API response.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.

    Returns:
        str: The status from an API response.
    """
    response = client.api_request(
        method=const.HttpMethod.GET.value, base_url=base_url, endpoint=endpoint
    )
    parsed = json.loads(response.content)
    return parsed["status"]


def get_count(client, base_url: str, endpoint: str, params: dict):
    """
    Fetches count from any API response.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.

    Returns:
        str: The count from an API response.
    """
    response = client.api_request(
        method=const.HttpMethod.GET.value, base_url=base_url, endpoint=endpoint, params=params
    )
    parsed = json.loads(response.content)
    return parsed["count"]


def poll_status(client, base_url: str, endpoint: str, status: str):
    """
    Wait until the status is <status>.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.
        status: The expected status to stop the poll.
    """
    for _ in range(30):
        current_status = get_status(client, base_url=base_url, endpoint=endpoint)

        if current_status == status:
            return

        time.sleep(5)

    if current_status == const.Status.FAILED.value:
        raise Exception(f"Evaluation creation failed with status: {current_status}.")
    else:
        raise Exception(
            f"Status update from {current_status} to {status} is taking too long. "
            "Please check with developers."
        )


def poll_measurement_count(client, base_url: str, endpoint: str, params: dict, count: str):
    """
    Wait until the measurement count is <count>.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.
        count: The expected number of measurements.
    """
    for _ in range(30):
        current_count = get_count(client, base_url=base_url, endpoint=endpoint, params=params)

        if current_count == count:
            return

        time.sleep(5)

    raise Exception(
        f"Measurement count update from {current_count} to {count} is taking too long.\n"
        "1. Check the measurement count and names in the ZIP file vs. CSV file.\n"
        "2. Check with the developers why immporting measurement is taking so long."
    )


def get_measurement_id(client, base_url: str, endpoint: str, params_payload: dict):
    """
    Fetches the first measurement ID instance based on a measurement name.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.
        params_payload: The paramter payload used to query.

    Returns:
        str: The measurement ID from an API response.
    """
    # Execute GET measurement API
    response = client.api_request(
        method=const.HttpMethod.GET.value,
        base_url=base_url,
        endpoint=endpoint,
        params=params_payload,
    )

    # Deserialize response
    response_details = json.loads(response.content)

    # Check if we get a valid result
    if response_details["count"] == 0:
        raise Exception(
            f"There are no Measurement Id found for Measurement {params_payload.get('name')}. "
            "Pls check if measurement is uploaded."
        )

    return response_details["results"][0]["id"]


def get_measurement_ids(context, names: set) -> List[str]:
    return [
        get_measurement_id(
            context.client,
            base_url=context.url,
            endpoint=f"analytics/api/v2/measurements/{context.proj_id}/",
            params_payload={"name": name, "archived": False},
        )
        for name in names
    ]


def get_org_id(client, base_url, org_name):
    """
    Get org id of a specific organization.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        org_name: The organization name to be used.

    Returns:
        str: Organization id
    """
    response = client.api_request(
        method=const.HttpMethod.GET.value,
        base_url=base_url,
        endpoint="tenantservice/api/v1/organizations/",
    )

    orgs = json.loads(response.content)

    for org in orgs:
        if org["name"] == org_name:
            return org["id"]

    raise ValueError(f"Organization '{org_name}' not found.")


def get_component_id(client, base_url, endpoint, component_name):
    """
    Get component id of a specific component.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        endpoint: The specific API endpoint to query.
        component_name: The component name to be used.

    Returns:
        str: Component id
    """
    response = client.api_request(
        method=const.HttpMethod.GET.value,
        base_url=base_url,
        endpoint=endpoint,
        params={"name": component_name},
    )

    component_data = json.loads(response.content)

    for component in component_data["results"]:
        if component["name"].lower() == component_name.lower():
            return component["id"]

    raise ValueError(f"Component '{component_name}' not found.")


def get_project_id(client, base_url, org_id, project_name):
    """
    Get project id of a specific project under an organization.

    Args:
        client: An object with an `api_request` method for making HTTP requests.
        base_url: The base URL of the API.
        org_id: The organization id where the project is under.
        project_name: The project name to be used.

    Returns:
        str: Project id
    """
    endpoint = f"tenantservice/api/v1/organizations/{org_id}/projects/"
    response = client.api_request(
        method=const.HttpMethod.GET.value, base_url=base_url, endpoint=endpoint
    )
    projects = json.loads(response.content)

    for proj in projects:
        if proj["name"] == project_name:
            return proj["id"]

    raise ValueError(f"Project '{project_name}' not found.")


def create_and_poll_evaluation(
    context,
    method_id: str,
    measurement_id: List,
    evaluation_name: str,
    parser: Callable,
    index=0,
):
    """
    Creates and polls DOSIM and QASCAN evaluation(s).
    Polls until the evaluation is in 'finished' status.

    Args:
        context: pytest-bdd context.
        method_id: Method Id to be used for evaluation creation.
        measurement_id: List of measurement Ids to be used for evaluation creation.
        evaluation_name: Name of the evaluation.
        index (Optional): Index appended to evaluation name in case of multiple evaluation creation.

    Returns:
        List of Evaluation Ids
    """

    resource_prefix = (
        "analytics/api/v2/dosim/"
        if context.product == const.MethodType.DOSIM
        else "analytics/api/v2/qascan/"
    )

    # list_actual_api_result = []
    evaluation_endpoint = f"{resource_prefix}{context.proj_id}/evaluations/"
    index = "" if index == 0 else index

    # Create payload for creating evaluations using list of measurement
    payload = EvaluationRequest(
        comment="N/A",
        measurements=measurement_id,
        method=method_id,
        name=evaluation_name,
    ).toJson_dict()

    # Execute POST create evaluation
    post_response = context.client.api_request(
        method=const.HttpMethod.POST.value,
        base_url=context.url,
        endpoint=evaluation_endpoint,
        json=payload,
    )

    if not post_response.ok:
        raise Exception(
            f"Creating {context.product} Evaluation {index} failed! "
            f"Response code: {post_response.status_code}"
        )

    print(f"{context.product} Evaluation {index} creation is successful!")

    # Deserialize and Map to dataclass response object
    eval_response = parser(json.loads(post_response.content))

    # Get the evaluation id
    list_evaluation_ids = [row.id for row in eval_response]

    print("Polling until evaluation(s) have 'Finished' status...")

    for evaluation_id in list_evaluation_ids:
        # Wait for evaluation to reach finished status
        poll_status(
            context.client,
            base_url=context.url,
            endpoint=f"{evaluation_endpoint}{evaluation_id}/",
            status=const.Status.FINISHED.value,
        )

    return list_evaluation_ids


def get_dosim_concentration_values(
    context,
    list_evaluation_ids: List[str],
) -> List[DataDrivenComparisonModel]:
    """
    Extract the concentration values from the DOSIM evaluation API response.

    Args:
        context: pytest-bdd context.
        list_evaluation_ids: Evaluation ids where concentration values are extracted.

    Returns:
        List[DataDrivenComparisonModel]
    """
    list_actual_api_result = []
    evaluation_endpoint = f"analytics/api/v2/dosim/{context.proj_id}/evaluations/"

    for evaluation_id in list_evaluation_ids:
        # Execute GET evaluation using the evaluation id
        get_response = context.client.api_request(
            method=const.HttpMethod.GET.value,
            base_url=context.url,
            endpoint=f"{evaluation_endpoint}{evaluation_id}/",
        )

        # Deserialize and Map to dataclass response object
        eval_data = deserializer.map_json_to_dosim_eval_result_model(
            json.loads(get_response.content)
        )

        list_actual_api_result.append(eval_data)

    return list_actual_api_result


def get_qascan_concentration_values(
    context,
    list_evaluation_ids: List[str],
) -> List[QAScanComparisonModel]:
    """
    Extract the concentration values from the QA Scan evaluation API response.

    Args:
        context: pytest-bdd context.
        list_evaluation_ids: Evaluation ids where concentration values are extracted.

    Returns:
        List[QAScanComparisonModel]
    """
    list_actual_api_result = []
    evaluation_endpoint = f"analytics/api/v2/qascan/{context.proj_id}/evaluations/"

    for evaluation_id in list_evaluation_ids:
        # Execute GET evaluation using the evaluation id
        get_response = context.client.api_request(
            method=const.HttpMethod.GET.value,
            base_url=context.url,
            endpoint=f"{evaluation_endpoint}{evaluation_id}/",
        )

        # Deserialize and Map to dataclass comparison object
        eval_data = deserializer.map_json_to_qascan_eval_result_model(
            json.loads(get_response.content)
        )

        list_actual_api_result.append(eval_data)

    return list_actual_api_result


def check_existing_dosim_methods(context, search_name: str, component_list):
    """
    Checks if dosim methods matching the search name exist. Returns matching methods
    if they match the component configuration.

    Args:
        context: pytest-bdd context.
        search_name: Method name (or Substring) to be searched.
        component_list: Expected list of components to check against existing methods.

    Returns:
        Method object if found, or None if new method needs to be created.
        If multiple methods are found, returns the latest method.

    Raises:
        Exception: If returned method count > expected_count.
    """
    base_endpoint = f"analytics/api/v2/methods/{context.proj_id}/"
    dosim_details_endpoint = f"analytics/api/v2/dosim/{context.proj_id}/methods/"

    # Create parameter payload with search name and creation date
    params_payload = {"name": search_name}

    # Execute GET methods API
    response1 = context.client.api_request(
        method=const.HttpMethod.GET.value,
        base_url=context.url,
        endpoint=base_endpoint,
        params=params_payload,
    )

    resp_data = deserializer.map_to_dataclass_get_method(json.loads(response1.content))

    if resp_data.count == 0:
        # Method creation needed
        return None

    # Go through all existing methods with the same search_name
    for method in resp_data.results:
        dosim_response = context.client.api_request(
            method=const.HttpMethod.GET.value,
            base_url=context.url,
            endpoint=f"{dosim_details_endpoint}{method.id}/",
        )

        # Get the existing method details
        dosim_details = deserializer.map_to_dataclass_create_dosim_method(
            json.loads(dosim_response.content)
        )

        # Map existing method details to ComponentPayload dataclass
        existing_components = [
            ComponentPayload(
                id=d.component.id,
                min_concentration=d.min_concentration,
                max_concentration=d.max_concentration,
            )
            for d in dosim_details.selected_components
        ]

        # If we find an existing method with same configuration, return that method details
        if sorted(existing_components, key=lambda x: (x.id)) == sorted(
            component_list, key=lambda x: (x.id)
        ):
            return method

    # If we did not find methods with our criteria, return none
    return None


def check_existing_qascan_methods(context, search_name: str, expected_details: QAScanMethod):
    """
    Checks if QA Scan methods matching the search name exist. Returns matching methods
    if they match the method setup.

    Args:
        context: pytest-bdd context.
        search_name: Method name (or Substring) to be searched.
        expected_details: Expected list of details to check against existing methods.

    Returns:
        Method object if found, or None if new method needs to be created.\n
        If multiple methods are found, returns the latest method.
    """
    base_endpoint = f"analytics/api/v2/methods/{context.proj_id}/"
    qascan_details_endpoint = f"analytics/api/v2/qascan/{context.proj_id}/methods/"

    # Create parameter payload with search name and creation date
    params_payload = {"name": search_name}

    # Execute GET methods API
    response1 = context.client.api_request(
        method=const.HttpMethod.GET.value,
        base_url=context.url,
        endpoint=base_endpoint,
        params=params_payload,
    )

    resp_data = deserializer.map_to_dataclass_get_method(json.loads(response1.content))

    if resp_data.count == 0:
        # Method creation needed
        return None

    # Go through all existing methods with the same search_name
    for method in resp_data.results:
        dosim_response = context.client.api_request(
            method=const.HttpMethod.GET.value,
            base_url=context.url,
            endpoint=f"{qascan_details_endpoint}{method.id}/",
        )

        # Get the existing method details
        qascan_details = deserializer.map_to_dataclass_create_qascan_method(
            json.loads(dosim_response.content)
        )

        # If we find an existing method with same configuration, return that method details
        if compare_qascan_details(qascan_details, expected_details):
            return method

    # If we did not find methods with our criteria, return none
    return None


def create_component_payload(context, datatable):
    """
    Create component list payload for creating DOSIM method.

    Args:
        context: pytest-bdd context.
        datatable: Table from step definition.

    Returns:
        ComponentPayload
    """
    component_endpoint = f"analytics/api/v2/sdb/{context.proj_id}/components/"

    component_list = []

    for row in datatable.rows:
        # We get the component Ids based on the component names
        component_id = get_component_id(
            client=context.client,
            base_url=context.url,
            endpoint=component_endpoint,
            component_name=row.get("component"),
        )

        # Once we have the component Ids & concentrations, we map it to ComponentPayload dataclass
        component_list.append(
            ComponentPayload(
                id=component_id,
                min_concentration=float(row["min_concentration"]),
                max_concentration=float(row["max_concentration"]),
            )
        )

    return component_list


def create_dosim_method(context, method_name: str, min_ph: float, max_ph: float, component_list):
    """
    Create a new DOSIM method using API.

    Args:
        context: pytest-bdd context.
        method_name: Name of the method.
        min_ph: Minimum pH value.
        max_ph: Maximum pH value.
        component_list: List of components.

    Returns:
        Tuple of (method_id, method_status)
    """
    create_endpoint = f"analytics/api/v2/dosim/{context.proj_id}/methods/"

    # Prepare payload using DosimPayload dataclass
    payload = DosimPayload(
        components=component_list,
        name=method_name,
        min_ph=min_ph,
        max_ph=max_ph,
    ).toJson_dict()

    # Execute POST Create DOSIM API
    post_response = context.client.api_request(
        method=const.HttpMethod.POST.value,
        base_url=context.url,
        endpoint=create_endpoint,
        json=payload,
    )

    if not post_response.ok:
        raise Exception(f"DOSIM Method creation failed! Response code: {post_response.status_code}")

    print("DOSIM Method Successfully created!")

    return deserializer.map_to_dataclass_create_dosim_method(json.loads(post_response.content))


def make_method_available(context, method_type: str, method_id: str, index=None):
    """
    Make a single method available via PATCH request if not yet available.
    Polls until the method is in 'draft' status before sending the PATCH.

    Args:
        context: pytest-bdd context.
        method_type: Type of the method to be made available.
        method_id: ID of the method to make available.
        index (Optional): Index for logging (used in multi-method case).
    """
    if method_type == const.MethodType.QASCAN:
        resource_prefix = "analytics/api/v2/qascan/"
    else:
        resource_prefix = "analytics/api/v2/dosim/"

    endpoint = f"{resource_prefix}{context.proj_id}/methods/{method_id}/"

    print("Polling until method(s) have 'Draft' status...")

    # Wait for method to reach draft status
    poll_status(
        context.client,
        base_url=context.url,
        endpoint=endpoint,
        status=const.Status.DRAFT.value,
    )

    # Make method available via PATCH
    patch_response = context.client.api_request(
        method=const.HttpMethod.PATCH.value,
        base_url=context.url,
        endpoint=endpoint,
        json={"status": const.Status.AVAILABLE.value},
    )

    index = f"{index}" if index else ""

    if (
        patch_response.ok
        and json.loads(patch_response.content)["status"] == const.Status.AVAILABLE.value
    ):
        print(f"{method_type.value.upper()} Method {index} is now available!")
    else:
        raise Exception(
            f"Making {method_type.value.upper()} Method {index} available failed! "
            f"Response code: {patch_response.status_code}"
        )


def check_measurement_exist(context, measurement_name, target_measurement_count=1):
    """
    Checks if measurements are uploaded or not based on the measurement_name.

    Args:
        context: pytest-bdd context.
        measurement_name: Measurement name for filtering.
        target_measurement_count: How many measurements are expected to be active.

    Returns:
        Boolean True or False
    """
    count_active = 0
    offset = 0
    page_size = 10

    while True:
        response = context.client.api_request(
            method=const.HttpMethod.GET.value,
            base_url=context.url,
            endpoint=f"analytics/api/v2/measurements/{context.proj_id}/",
            params={"name": measurement_name, "offset": offset},
        )

        resp_data = deserializer.map_to_dataclass_get_measurement(json.loads(response.content))

        # Break if no data or results is empty
        if not resp_data or not resp_data.results:
            break

        # Add up count of active measurements
        count_active += sum(not data.archived for data in resp_data.results)

        # If number of results less than page_size, no more data to fetch
        if len(resp_data.results) < page_size:
            break

        offset += page_size

    # If active count == 0, explicitly return False and we upload measurements
    if count_active == 0:
        return False

    # If the active count is different from target count, raise an error
    if count_active != target_measurement_count:
        raise Exception(
            f"{count_active} measurement(s) with name {measurement_name} found. "
            "Please delete or archive any existing measurements with the same name. "
            f"We are uploading in bulk {target_measurement_count} measurement(s) "
            "and duplicate measurements may cause flakiness in test execution."
        )

    # When active count == target count, return True and do not upload measurements
    return True


def upload_measurement(context, endpoint, file_path, file_name, file_type):
    """
    Uploads measurements using a zip file or a single JSON file.

    Args:
        context: pytest-bdd context.
        endpoint: endpoint of the Upload Measurement API.
        file_path: Location of the zip file or the single JSON file.
        file_name: File name of the zip file or the single JSON files.
        file_type: Value should either "zip" or "json".
    """

    full_file_path = os.path.normpath(os.path.join(file_path, file_name))

    try:
        with open(full_file_path, "rb") as f:
            content_type = (
                "application/json" if file_type == "json" else "application/x-zip-compressed"
            )
            files = {"files": (file_name, f, content_type)}

            upload_response = context.client.api_request_upload(
                method=const.HttpMethod.POST.value,
                base_url=context.url,
                endpoint=endpoint,
                files=files,
            )

        upload_result = deserializer.map_to_dataclass_post_measurement(
            json.loads(upload_response.content)
        )

        return upload_result

    except FileNotFoundError:
        raise FileNotFoundError(f"File not found: {file_path}")


def import_measurement(context, endpoint, upload_result):
    """
    Imports the uploaded measurement(s).

    Args:
        context: pytest-bdd context.
        endpoint: endpoint of the import measurement API.
        upload_result: Dataclass of the upload API response.
    """
    if isinstance(upload_result, list):
        import_payload = [{"id": result.id} for result in upload_result]
    else:
        import_payload = [{"id": upload_result.id}]

    import_response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=endpoint,
        json=import_payload,
    )

    return import_response


def upload_measurement_zip_file_if_missing(
    context,
    subname: str,
    file_path: str,
    zip_file_name: str,
):
    """
    Checks if a subname in a collection of measurement names is uploaded.\n
    If not yet uploaded, uploads and imports a zip file that contains a collection of measurements.

    Args:
        context: pytest-bdd context.
        subname: Subname that is common to all measurement names in the zip file.
        file_path: Path where the zip file is located.
        zip_file_name: File name of the zip file.
    """
    context.org_id = get_org_id(client=context.client, base_url=context.url, org_name=context.org)

    context.proj_id = get_project_id(
        client=context.client,
        base_url=context.url,
        org_id=context.org_id,
        project_name=context.project,
    )

    base_endpoint = f"analytics/api/v2/measurements/{context.proj_id}/"
    endpoint = f"{base_endpoint}import/"

    # Get how many measurements are in the ZIP file
    zip_path = os.path.normpath(os.path.join(file_path, zip_file_name))
    zip_measurement_count = count_files_in_zip(zip_path)

    if check_measurement_exist(
        context=context,
        measurement_name=subname,
        target_measurement_count=zip_measurement_count,
    ):
        print(f"Measurements with subname {subname} are already uploaded. Skipping upload...")
        return

    print("Uploading ZIP measurement file...")

    upload_response = upload_measurement(
        context=context,
        endpoint=endpoint,
        file_path=file_path,
        file_name=zip_file_name,
        file_type="zip",
    )

    if not upload_response:
        raise Exception(
            "ZIP file upload failed! Check server response. "
            f"Response code: {upload_response.status_code}"
        )

    print(f"ZIP file {zip_file_name} successfully uploaded! Importing...")

    import_response = import_measurement(
        context=context, endpoint=endpoint, upload_result=upload_response
    )

    if import_response.status_code != 202:
        raise Exception(
            f"Importing Measurement failed! Response code: {import_response.status_code}"
        )

    for measurement_name in context.measurement_names:
        poll_measurement_count(
            context.client,
            base_url=context.url,
            endpoint=base_endpoint,
            count=1,
            params={"name": measurement_name, "archived": False},
        )

    print("Measurement successfully imported!")


def upload_json_measurements_if_missing(
    context,
    search_names: List[str],
    file_path: str,
    json_file_names: List[str],
):
    """
    Checks if measurement(s) are uploaded.
    If not yet uploaded, uploads and imports the measurement json file(s).

    Examples:
        Single Measurement:\n
            context.measurement_name = measurement

            utility.upload_json_measurements_if_missing(
                context=context,
                search_names=[context.measurement_name],
                file_path=const.API_DOSIM_TESTDATA_PATH,
                json_file_names=["71468279465443.json"],
            )

        Multiple Measurement:\n
            context.measurement_name = ["71468279465444", "71468279465443"]
            filenames = ["71468279465443.json", "71468279465444.json"]

            utility.upload_json_measurements_if_missing(
                context=context,
                search_names=[context.measurement_name],
                file_path=const.API_DOSIM_MEASUREMENT_PATH,
                json_file_names=[filenames],
            )

    Args:
        context: pytest-bdd context.
        search_names: A measurement name or a list of measurement names.
        file_path: Path where the json file(s) are located.
        json_file_names: A json file or a list of json files to be uploaded.
    """
    context.org_id = get_org_id(client=context.client, base_url=context.url, org_name=context.org)

    context.proj_id = get_project_id(
        client=context.client,
        base_url=context.url,
        org_id=context.org_id,
        project_name=context.project,
    )

    base_endpoint = f"analytics/api/v2/measurements/{context.proj_id}/"
    endpoint = f"{base_endpoint}import/"
    context.measurement_names = []

    for search_name in search_names:
        if check_measurement_exist(context=context, measurement_name=search_name):
            print(f"Measurement {search_name} is already uploaded. Skipping upload...")
            continue

        print(f"Measurement {search_name} not available. Uploading measurement...")

        # Try to find a matching json file
        matched_json_file = next(
            (file_name for file_name in json_file_names if search_name in file_name), None
        )

        if not matched_json_file:
            raise Exception(f"No matching json file found for measurement '{search_name}'.")

        upload_result = upload_measurement(
            context=context,
            endpoint=endpoint,
            file_path=file_path,
            file_name=matched_json_file,
            file_type="json",
        )

        if not upload_result:
            raise Exception(
                "JSON Measurement upload failed! Check server response. "
                f"Response code: {upload_result.status_code}"
            )

        measurement_name = upload_result[0].name

        # We store all the measurement names
        context.measurement_names.extend(measurement_name)

        print(f"Measurement {measurement_name} successfully uploaded! Importing...")

        import_response = import_measurement(
            context=context, endpoint=endpoint, upload_result=upload_result
        )

        if import_response.status_code != 202:
            raise Exception(
                f"Importing Measurement failed! Response code: {import_response.status_code}"
            )

        poll_measurement_count(
            context.client,
            base_url=context.url,
            endpoint=base_endpoint,
            count=1,
            params={"name": measurement_name},
        )

        print(f"Measurement {measurement_name} successfully imported!")


def create_step_2_payload(attributes: str):
    """
    Create payload for step 2 Analytical Attributes of QA Scan method creation.

    Args:
        attributes: Attributes to be used for QA Scan method creation.

    Returns:
        'All' if all attributes are to be used else the specific attributes.
    """
    attributes_set = (
        {"all"} if attributes == "all" else {attr.strip() for attr in attributes.split(",")}
    )

    keys = [
        "with_concentration",
        "with_excipients",
        "with_ph",
        "with_polysorbate",
        "with_secondary_structure",
        "with_similarity",
    ]

    payload = {key: (attributes == "all" or key in attributes_set) for key in keys}

    return payload


def create_step_3_1_payload(context, datatable) -> QAScanComponentPayload:
    """
    Create payload for step 3-1 Component Selection of QA Scan method creation.
    Stores a dictionary of [{<component>: <component_ids>}].

    Args:
        context: pytest-bdd context.
        datatable: Table from step definition.

    Returns:
        QAScanComponentPayload
    """
    component_endpoint = f"analytics/api/v2/sdb/{context.proj_id}/components/"
    component_list = []
    context.component_ids = {}

    for row in datatable.rows:
        # We get the component Ids based on the component names
        component_id = get_component_id(
            client=context.client,
            base_url=context.url,
            endpoint=component_endpoint,
            component_name=row.get("component"),
        )

        # Once we have the component Ids & buffer, we map it to ComponentPayload dataclass
        component_list.append(Component(id=component_id, main=row.get("main")))

        # We store components and their component ids
        context.component_ids[row.get("component").lower()] = component_id

    return QAScanComponentPayload(component_list)


def create_step_3_x_payload(
    measurement_ids: List, parser: Callable[[List[FormulationBuffer]], T]
) -> T:
    """
    Create payload for step 3-2 Formulation and Step 3-3 Buffer of QA Scan method creation.

    Args:
        measurement_ids: List of measurement Ids for formulation or buffer.
    """

    payload = parser([FormulationBuffer(id=measurement_id) for measurement_id in measurement_ids])

    return payload


def create_step_3_4_1_payload(context, datatable) -> QAScanReferenceValuePayload:
    """
    Create payload for step 3-4-1 Reference Values of QA Scan method creation.

    Args:
        context: pytest-bdd context.
        datatable: Table from step definition.

    Returns:
        QAScanReferenceValuePayload
    """

    components = []
    ph_buffer = None
    ph_formulation = None
    protein_concentration_formulation = None

    for row in datatable.rows:
        component_name = row.get("component", "").lower()

        # Build components list for QAScanReferenceValuePayload
        component_id = context.component_ids.get(component_name)

        if component_id:
            components.append(
                ComponentDetails(
                    component_id=component_id,
                    concentration_buffer=row.get("formulation_buffer"),
                    concentration_formulation=row.get("formulation"),
                )
            )

        # Extract pH and protein concentration values
        if component_name == "ph":
            ph_buffer = row.get("formulation_buffer")
            ph_formulation = row.get("formulation")

        elif component_name == "protein concentration":
            protein_concentration_formulation = row.get("formulation")

    payload = QAScanReferenceValuePayload(
        components=components,
        ph_buffer=float(ph_buffer),
        ph_formulation=float(ph_formulation),
        protein_concentration_formulation=float(protein_concentration_formulation),
        concentration_custom_range=const.CONC_RANGE_OF_INTEREST / 100,
        ph_custom_range=const.PH_RANGE_OF_INTEREST,
    )

    return payload


def reuse_existing_qascan_method_if_any(context, search_name: str) -> bool:
    expected_details = deserializer.map_datatable_to_qascan_method(
        step2=context.step2_datatable.rows,
        step31=context.step3_1_datatable.rows,
        step32=context.step3_2_datatable.rows,
        step33=context.step3_3_datatable.rows,
        step341=context.step3_4_1_datatable.rows,
    )

    method_result = check_existing_qascan_methods(
        context=context, search_name=search_name, expected_details=expected_details
    )

    if method_result:
        print(f"Existing method found! Name: {method_result.name}")

        context.method_id = method_result.id
        context.method_status = method_result.status

        # Override method name with the existing method
        context.method_name = method_result.name

        return True

    return False


def create_initial_qascan_method(context):
    """
    Step 1 QA Scan method creation.
    """
    endpoint = f"analytics/api/v2/qascan/{context.proj_id}/methods/"

    payload = {"name": context.method_name}
    response = context.client.api_request(
        method=const.HttpMethod.POST.value,
        base_url=context.url,
        endpoint=endpoint,
        json=payload,
    )

    if not response.ok or response.status_code != 201:
        raise Exception(f"Step 1 - Method creation failed! Code: {response.status_code}")

    result = deserializer.map_to_dataclass_create_qascan_method(json.loads(response.content))

    # Store method_id for later use
    context.method_id = result.id

    print("Step 1 - Method creation completed.")


def set_analytical_attributes(context):
    """
    Step 2 - Analystical Attributes QA Scan method creation.
    """
    selected_attrs = build_step2_attribute_string(context.step2_datatable.rows)

    payload = create_step_2_payload(attributes=selected_attrs)
    response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=(
            f"analytics/api/v2/qascan/{context.proj_id}/methods/"
            f"{context.method_id}/analytical-attributes/"
        ),
        json=payload,
    )

    if not response.ok or response.status_code != 202:
        raise Exception(f"Step 2 - Analytical Attributes failed! Code: {response.status_code}")

    result = deserializer.map_to_dataclass_create_qascan_method(json.loads(response.content))

    # Store with_polysorbate for later use
    context.with_polysorbate = result.with_polysorbate

    print("Step 2 - Analytical Attributes set.")


def select_components(context):
    """
    Step 3-1 - Select Components QA Scan method creation.
    """
    payload = create_step_3_1_payload(context, datatable=context.step3_1_datatable).toJson_dict()
    response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=(
            f"analytics/api/v2/qascan/{context.proj_id}/methods/"
            f"{context.method_id}/select-components/"
        ),
        json=payload,
    )

    if not response.ok or response.status_code != 202:
        raise Exception(f"Step 3-1 - Component Selection failed! Code: {response.status_code}")

    print("Step 3-1 - Component Selection completed.")


def calibrate_formulation(context):
    """
    Step 3-2 - Formulation QA Scan method creation.
    """
    measurement_names = {row["measurement"] for row in context.step3_2_datatable.rows}
    context.measurement_formulation_ids = get_measurement_ids(context, measurement_names)

    payload = create_step_3_x_payload(
        measurement_ids=context.measurement_formulation_ids, parser=QAScanFormulationPayload
    ).toJson_dict()

    response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=(
            f"analytics/api/v2/qascan/{context.proj_id}/methods/"
            f"{context.method_id}/calibrate-formulation/"
        ),
        json=payload,
    )

    if not response.ok or response.status_code != 202:
        raise Exception(f"Step 3-2 - Formulation failed! Code: {response.status_code}")

    print("Step 3-2 - Formulation completed.")


def calibrate_buffer(context):
    """
    Step 3-3 - Buffer QA Scan method creation.
    """
    measurement_names = {row["measurement"] for row in context.step3_3_datatable.rows}
    context.measurement_formulation_ids = get_measurement_ids(context, measurement_names)

    payload = create_step_3_x_payload(
        measurement_ids=context.measurement_formulation_ids, parser=QAScanBufferPayload
    ).toJson_dict()

    response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=(
            f"analytics/api/v2/qascan/{context.proj_id}/methods/"
            f"{context.method_id}/calibrate-buffer/"
        ),
        json=payload,
    )

    if not response.ok or response.status_code != 202:
        raise Exception(f"Step 3-3 - Buffer failed! Code: {response.status_code}")

    print("Step 3-3 - Buffer calibration completed.")


def set_reference_values(context):
    """
    Step 3-4-1 - Reference Values QA Scan method creation.
    """
    payload = create_step_3_4_1_payload(
        context, datatable=context.step3_4_1_datatable
    ).toJson_dict()

    response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=(
            f"analytics/api/v2/qascan/{context.proj_id}/methods/"
            f"{context.method_id}/reference-values/"
        ),
        json=payload,
    )

    if not response.ok or response.status_code != 202:
        raise Exception(f"Step 3-4-1 - Reference Values failed! Code: {response.status_code}")

    context.method_status = json.loads(response.content).get("status")
    print("Step 3-4-1 - Reference Values completed.")


def complete_review_page(context):
    """
    Step 4 - Review QA Scan method creation.
    """
    put_response = context.client.api_request(
        method=const.HttpMethod.PUT.value,
        base_url=context.url,
        endpoint=f"analytics/api/v2/qascan/{context.proj_id}/methods/{context.method_id}/review/",
    )

    if not put_response.ok or put_response.status_code != 202:
        raise Exception("Step 4 - Review failed! " f"Response code: {put_response.status_code}")

    context.method_status = json.loads(put_response.content).get("status")

    print("Step 4 - Review for QA Scan method creation is completed.")
