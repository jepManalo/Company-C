import requests


class APIClient:
    """This class handles HTTP requests to the specific base URL"""

    def __init__(self):
        self.session = requests.Session()

    def api_request(self, method, base_url, endpoint, json=None, params=None):
        """Sends a request to the specific endpoint"""

        default_headers = {"Content-Type": "application/json", "accept": "application/json"}
        url = f"{base_url}{endpoint}"

        return self.session.request(method, url, headers=default_headers, json=json, params=params)

    def api_request_upload(self, method, base_url, endpoint, files=None):
        """Upload zip files using the specific endpoint"""

        default_headers = {"accept": "application/json"}
        url = f"{base_url}{endpoint}"

        return self.session.request(method, url, headers=default_headers, files=files)
