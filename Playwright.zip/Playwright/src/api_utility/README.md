# Sphere Replicability and Consistency Tests

## api_utility folder
api_utility folder consists of all the api methods and functions in executing API calls, serializing and deserializing JSONs, dataclass models and the test data to be used for our automated API replicability and consistency tests. These are segregated into several files and folders:

1. api_models folder
2. testdata folder
3. api_client.py
4. api_deserializer.py
5. utils.py

### api_models folder
This folder contains all the dataclasses to be used whenever we serialize our API requests payload and deserialize our API responses.

### testdata folder
This folder contains all the testdata to be used in executing replicability and consistency tests.

In this section, we will discuss how to setup the consistency and replicability tests for evaluations in Sphere.

#### Test Data Setup for Persistency Tests
1. First we must ensure that we have 1 test data under api_utility -> testdata -> dosim folder. Currently, we have a file named `201105-01_BASFKTC523_MBio3461_MIRA0013_71468279465443.json`. This file comes from Data Science.
2. `201105-01_BASFKTC523_MBio3461_MIRA0013_71468279465443.json` is a JSON file from `measurements.zip`. Note that `measurement.zip` still contains this JSON file. We copied one JSON file out of the `measurementts.zip` because we only need 1 measurement for persistency tests.
3. If there is a need to change the test data for persistency test, ensure that the new single measurement JSON file is under api_utility -> testdata -> dosim folder.
4. The *measurement_name* in the gherkin statement `And the measurement "{measurement_name}" is uploaded to the Project` must match the *measurement name* inside the JSON file and the JSON *filename*.

**Example**:
Old version: *measurement_A*
New version: *measurement_B*

Change the following:
- JSON filename from *measurement_A.json* to *measurement_B.json* in the api_utility -> testdata -> dosim folder
- Change the measurement name inside the JSON file from `"name": "NAM", "value": ["measurement_A"]` to `"name": "NAM", "value": ["measurement_B"]`
- Change the measurement name in the Gherkin statement from `And the measurement "measurement_A" is uploaded to the Project` to `And the measurement "measurement_B" is uploaded to the Project`

5. For **Persistency for DOSIM using multiple runs**, pH levels can be modified in the WHEN gherkin statement: `When the user creates a Data Driven Method using "{x}", "{y}" and the following input data via API:`. Change the value of **x** and **y** to your desired min. and max. pH values respectively.
6. For **Persistency for DOSIM using multiple runs**, the number of evaluations created can be modified in the WHEN gherkin statement: `And the user creates "{x}" evaluation/s via API`. Change the value of **x** to the number of evaluations to be created.
7. For **Persistency for DOSIM with different evaluation in between**, we are restricting the number of methods created to only 2. In the WHEN gherkin statement `When the user creates a Data Driven Method "{a}" using "{x}", "{y}" and the following input data via API:`, **a** is the unique indentifier between the 2 methods.
8. For **Persistency for DOSIM with different evaluation in between**, pH levels can be modified in the WHEN gherkin statement: `When the user creates a Data Driven Method "{a}" using "{x}", "{y}" and the following input data via API:`. Change the value of **x** and **y** to your desired min. and max. pH values respectively.
9. For **Persistency for DOSIM with different evaluation in between**, the number of evaluations created can be modified using `And the user creates "{x}" evaluation/s with "{y}" evaluation/s in between via API`. **x** is the number of evaluations created using the first method. **y** is the number of evaluations created in between the creation of the first evaluation set.
10. If there is a need to add / remove components, update the table of the gherkin statements. 

#### Test Data Setup for Consistency Tests
1. First we must ensure that we have 3 test data under api_utility -> testdata -> dosim folder. These files are `measurements.zip`, `testdata_with_nacl.csv` and `testdata_without_nacl.csv`.
2. Currently, `measurements.zip` contains 30 measurements in JSON format. This test data comes from Data Science team.
3. `testdata_with_nacl.csv` and `testdata_without_nacl.csv` contains the expected results for consistency tests. This also comes from Data Science.
4. To ensure that everything works without any issues, use small letters for the headers (line 1 of the csv file) in the CSV files.
5. Ensure that the measurement names under measurement column of the CSVs have exactly the same measurement name in the individual JSON files inside the `measurements.zip`. Note that measurement names are used as the primary_key in comparing the concentration values.
6. If there is a need to update the individual JSON files inside the `measurements.zip`, ensure to append a unique version identifier. See example below:

**Example**:
Old version: 201105-01_*BASFKTC523*_MBio3461_MIRA0013_71468279465443
New version: 201105-01_*BASFKTC523-V2*_MBio3461_MIRA0013_71468279465443

Change the following:
- Update the measurement name in the expected result *CSV* file from `201105-01_BASFKTC523_MBio3461_MIRA0013_71468279465443,0,0.1,...` to `201105-01_BASFKTC523-V2_MBio3461_MIRA0013_71468279465443,0,0.1,...`
- Update the measurement name in the *individual JSON* files from `"name": "NAM", "value": ["201105-01_BASFKTC523_MBio3461_MIRA0013_71468279465443"]` to `"name": "NAM", "value": ["201105-01_BASFKTC523-V2_MBio3461_MIRA0013_71468279465443"]`

**NOTE**: The *italized* text in the example above is the subname that will be used to search if the measurements are uploaded or not.

7. The components in the CSV files must exactly match the components from the table in the gherkin statement. That goes the same with the number of components to be used. 
8. The component names in the gherkin statement can have lower or upper case.
9. files with `_demo` are used for debugging purposes. It contains the first 3 lines of the original csv file.
10. pH levels can be modified in the WHEN gherkin statement: `When the user creates a Data Driven Method using "x", "y" and the following input data via API:`. Change the value of **x** and **y** to your desired min. and max. pH values respectively.
11. Concentration value tolerance can be changed in the THEN gherkin statement: `Then the concentration values are within "{x}"% tolerance range for API vs Excel`. Change the value of **x** to your desired tolerance.
12. If there is a need to add components, add them in the table of the gherkin statements. After that, add the components in the api_utility -> testdata -> dosim -> testdata_model.py. Add the expected concentration in the *CSV* file as well.

**Example**: We want to add Polysorbat20 as a component.
1. Add Polysorbat20 in the gherking statement with its corresponding concentration values
| Polysorbat20     | {x}     | {y}      |
2. Add Polysorbat20 in the `testdata_model.py` file
polysorbat20: Optional[float] = field(default=None)
3. Check the CSVs that they have Polysorbat20
measurement,alanin,ameisensaeure,ammoniak,bernsteinsaeure,polysorbat20,...

### api_client.py
This file contains a method that mimics the API requests to the server. We have 2 methods in this file namely:

1. api_request -> executes normal requests to the servers
2. api_request_upload -> executes requests with attachments. Example: Uploading measurements to Sphere.

### api_deserializer.py
This file contains multiple methods that serializes and deserializes our JSON request payload and JSON responses. These methods transforms the JSON data to dataclasses and vice versa.

### utils.py
This file contains all utility methods for executing our API automated tests.
