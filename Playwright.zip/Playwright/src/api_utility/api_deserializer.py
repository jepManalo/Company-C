from typing import Dict, List

import api_utility.api_models.response.create_qascan_method_response_model as cqmm
import constants as const
import src.api_utility.api_models.response.create_dosim_evaluation_response_model as cderm
import src.api_utility.api_models.response.create_dosim_method_response_model as cdmrm
import src.api_utility.api_models.response.create_qascan_evaluation_response_model as cqerm
import src.api_utility.api_models.response.get_component_response_model as get_component_rm
import src.api_utility.api_models.response.get_measurement_response_model as get_measurement_rm
import src.api_utility.api_models.response.get_method_response_model as get_method_rm
import src.api_utility.api_models.response.upload_measurement_model as upload_measurement_m
from src.api_utility.testdata.dosim.dosim_testdata_model import DataDrivenComparisonModel
from src.api_utility.testdata.qascan.qascan_testdata_model import QAScanComparisonModel
from src.utility import safe_round


def map_to_dataclass_create_dosim_method(response_data: Dict) -> cdmrm.DosimResponseModel:
    # map the response data to the selected_components dataclass
    selected_components = [
        cdmrm.SelectedComponent(
            component=cdmrm.Component(id=row["component"]["id"], name=row["component"]["name"]),
            is_auxiliary=row["is_auxiliary"],
            min_concentration=row["min_concentration"],
            max_concentration=row["max_concentration"],
            preprocessors=[
                cdmrm.Preprocessor(method=pre["method"], params=pre["params"])
                # We need to handle nacl component with preprocessors = None in the API response
                for pre in row["preprocessors"] or []
            ],
        )
        for row in response_data["selected_components"]
    ]

    # map the response data to the DosimResponseModel dataclass + selected_components
    response_model = cdmrm.DosimResponseModel(
        archived=response_data["archived"],
        comment=response_data.get("comment"),
        created_by=response_data["created_by"],
        created=response_data["created"],
        id=response_data["id"],
        has_evaluations=response_data["has_evaluations"],
        maximal_ph=response_data["maximal_ph"],
        method_type=response_data["method_type"],
        minimal_ph=response_data["minimal_ph"],
        name=response_data["name"],
        selected_components=selected_components,
        status=response_data["status"],
        status_information=response_data.get("status_information"),
        updated=response_data["updated"],
        validation_result=response_data.get("validation_result"),
        validations=response_data["validations"],
    )

    return response_model


def map_to_dataclass_get_measurement(response_data: Dict) -> get_measurement_rm.MeasurementResponse:
    # map the response data to the results dataclass
    results = [get_measurement_rm.Measurement(**row) for row in response_data["results"]]

    # map the response data to the MeasurementResponse dataclass + results
    return get_measurement_rm.MeasurementResponse(
        count=response_data["count"],
        next=response_data.get("next"),
        previous=response_data.get("previous"),
        results=results,
    )


def map_to_dataclass_create_dosim_eval(response_data: dict) -> List[cderm.EvaluationResponse]:
    return [
        cderm.EvaluationResponse(
            archived=row["archived"],
            comment=row["comment"],
            created=row["created"],
            created_by=row["created_by"],
            id=row["id"],
            measurement=cderm.Measurement(
                acquisition_method=row["measurement"]["acquisition_method"],
                archived=row["measurement"]["archived"],
                created=row["measurement"]["created"],
                id=row["measurement"]["id"],
                measurement_timestamp=row["measurement"]["measurement_timestamp"],
                name=row["measurement"]["name"],
                source=row["measurement"]["source"],
                updated=row["measurement"]["updated"],
            ),
            method=cderm.Method(id=row["method"]["id"], name=row["method"]["name"]),
            name=row["name"],
            result_summary=cderm.ResultSummary(
                data=[
                    cderm.ResultSummaryData(components=entry["components"])
                    for entry in row["result_summary"]["data"]
                ],
                success=row["result_summary"]["success"],
                error=row["result_summary"]["error"],
            ),
            results=row["results"],
            status=row["status"],
            status_information=row["status_information"],
            updated=row["updated"],
        )
        for row in response_data
    ]


def map_to_dataclass_get_dosim_eval(response_data: dict) -> cderm.EvaluationResponse:
    measurement = cderm.Measurement(
        acquisition_method=response_data["measurement"]["acquisition_method"],
        archived=response_data["measurement"]["archived"],
        created=response_data["measurement"]["created"],
        id=response_data["measurement"]["id"],
        measurement_timestamp=response_data["measurement"]["measurement_timestamp"],
        name=response_data["measurement"]["name"],
        source=response_data["measurement"]["source"],
        updated=response_data["measurement"]["updated"],
    )

    method = cderm.Method(id=response_data["method"]["id"], name=response_data["method"]["name"])

    data = [
        cderm.ResultSummaryData(
            components=[
                cderm.Component(name=comp["name"], unit=comp["unit"], value=comp["value"])
                for comp in row.get("components", [])
            ]
        )
        for row in response_data["result_summary"]["data"]
    ]

    result_summary = cderm.ResultSummary(
        data=data,
        success=response_data["result_summary"]["success"],
        error=response_data["result_summary"]["error"],
    )

    result = [
        cderm.Result(
            component=cderm.ComponentReference(
                id=row["component"]["id"], name=row["component"]["name"]
            ),
            unit=row["unit"],
            value=row["value"],
        )
        for row in response_data["results"]
    ]

    return cderm.EvaluationResponse(
        archived=response_data["archived"],
        comment=response_data["comment"],
        created=response_data["created"],
        created_by=response_data["created_by"],
        id=response_data["id"],
        measurement=measurement,
        method=method,
        name=response_data["name"],
        result_summary=result_summary,
        results=result,
        status=response_data["status"],
        status_information=response_data.get("status_information"),
        updated=response_data["updated"],
    )


def map_to_dataclass_get_method(response_data: Dict) -> get_method_rm.MethodList:
    # map the response data to the results dataclass
    results = [get_method_rm.Results(**row) for row in response_data["results"]]

    # map the response data to the MethodList dataclass + results
    response_model = get_method_rm.MethodList(
        count=response_data["count"],
        next=response_data["next"],
        previous=response_data["previous"],
        results=results,
    )

    return response_model


def map_to_dataclass_get_component(data: dict) -> get_component_rm.ComponentList:
    results = [
        get_component_rm.Component(
            formula=item["formula"],
            id=item["id"],
            iupac=[get_component_rm.IUPACName(**iupac_item) for iupac_item in item["iupac"]],
            max_concentration=item["max_concentration"],
            min_concentration=item["min_concentration"],
            name=item["name"],
        )
        for item in data["results"]
    ]

    return get_component_rm.ComponentList(
        count=data["count"],
        next=data.get("next"),
        previous=data.get("previous"),
        results=results,
    )


def map_to_dataclass_post_measurement(response_data: Dict) -> upload_measurement_m.UploadResponse:
    # map the response data to the results dataclass
    return [upload_measurement_m.UploadResponse(**row) for row in response_data]


def map_to_dataclass_create_qascan_method(data: dict) -> cqmm.QAScanMethod:
    def parse_iupac_list(iupac_list: List[dict]) -> List[cqmm.IUPAC]:
        return [cqmm.IUPAC(**iupac) for iupac in iupac_list]

    def parse_component_info(info: dict) -> cqmm.ComponentInfo:
        return cqmm.ComponentInfo(
            id=info["id"], name=info["name"], iupac=parse_iupac_list(info.get("iupac", []))
        )

    def parse_component(comp: dict) -> cqmm.Component:
        return cqmm.Component(
            component=parse_component_info(comp["component"]),
            concentration_buffer=comp.get("concentration_buffer"),
            concentration_formulation=comp.get("concentration_formulation"),
            concentration_limit_lower=comp.get("concentration_limit_lower"),
            concentration_limit_upper=comp.get("concentration_limit_upper"),
            main=comp.get("main"),
        )

    def parse_calibration(cal: dict) -> cqmm.Calibration:
        return cqmm.Calibration(
            id=cal["id"], measurement_timestamp=cal["measurement_timestamp"], name=cal["name"]
        )

    return cqmm.QAScanMethod(
        id=data["id"],
        name=data["name"],
        method_type=data["method_type"],
        created=data.get("created"),
        updated=data.get("updated"),
        created_by=data["created_by"],
        archived=data["archived"],
        has_evaluations=data["has_evaluations"],
        last_step=data["last_step"],
        status=data["status"],
        comment=data.get("comment"),
        status_information=data.get("status_information"),
        buffer_calibrations=[parse_calibration(c) for c in data.get("buffer_calibrations", [])],
        formulation_calibrations=[
            parse_calibration(c) for c in data.get("formulation_calibrations", [])
        ],
        components=[parse_component(c) for c in data.get("components", [])],
        ph_buffer=data.get("ph_buffer"),
        ph_formulation=data.get("ph_formulation"),
        ph_limit_lower=data.get("ph_limit_lower"),
        ph_limit_upper=data.get("ph_limit_upper"),
        protein_concentration_formulation=data.get("protein_concentration_formulation"),
        protein_concentration_limit_lower=data.get("protein_concentration_limit_lower"),
        protein_concentration_limit_upper=data.get("protein_concentration_limit_upper"),
        validations=data.get("validations", []),
        with_concentration=data.get("with_concentration"),
        with_secondary_structure=data.get("with_secondary_structure"),
        with_similarity=data.get("with_similarity"),
        with_excipients=data.get("with_excipients"),
        with_polysorbate=data.get("with_polysorbate"),
        with_ph=data.get("with_ph"),
    )


def map_to_dataclass_create_qascan_eval(data: dict) -> List[cqerm.QAScanEvalResponse]:
    """Convert a list of JSON dicts into a list of Entry dataclass instances."""
    return [
        cqerm.QAScanEvalResponse(
            archived=item["archived"],
            comment=item["comment"],
            created=item["created"],
            created_by=item["created_by"],
            id=item["id"],
            measurement=cqerm.Measurement(
                acquisition_method=item["measurement"]["acquisition_method"],
                archived=item["measurement"]["archived"],
                created=item["measurement"]["created"],
                id=item["measurement"]["id"],
                measurement_timestamp=item["measurement"]["measurement_timestamp"],
                name=item["measurement"]["name"],
                source=item["measurement"]["source"],
                updated=item["measurement"]["updated"],
            ),
            method=cqerm.Method(
                id=item["method"]["id"],
                name=item["method"]["name"],
            ),
            name=item["name"],
            result=item["result"],
            status=item["status"],
            status_information=item["status_information"],
            updated=item["updated"],
        )
        for item in data
    ]


def map_to_dataclass_get_qascan_eval(data: dict) -> cqerm.QAScanEvalResponse:
    return cqerm.QAScanEvalResponse(
        archived=data["archived"],
        comment=data["comment"],
        created=data["created"],
        created_by=data["created_by"],
        id=data["id"],
        measurement=cqerm.Measurement(
            acquisition_method=data["measurement"]["acquisition_method"],
            archived=data["measurement"]["archived"],
            created=data["measurement"]["created"],
            id=data["measurement"]["id"],
            measurement_timestamp=data["measurement"]["measurement_timestamp"],
            name=data["measurement"]["name"],
            source=data["measurement"]["source"],
            updated=data["measurement"]["updated"],
        ),
        method=cqerm.Method(
            id=data["method"]["id"],
            name=data["method"]["name"],
        ),
        name=data["name"],
        result=cqerm.Result(
            alpha_helix_unit=data["result"]["alpha_helix_unit"],
            alpha_helix_value=data["result"]["alpha_helix_value"],
            beta_sheet_unit=data["result"]["beta_sheet_unit"],
            beta_sheet_value=data["result"]["beta_sheet_value"],
            components=[
                cqerm.ComponentEntry(
                    component=cqerm.Component(
                        id=comp["component"]["id"], name=comp["component"]["name"]
                    ),
                    unit=comp["unit"],
                    value=comp["value"],
                )
                for comp in data["result"]["components"]
            ],
            ph_value=data["result"]["ph_value"],
            protein_concentration_unit=data["result"]["protein_concentration_unit"],
            protein_concentration_value=data["result"]["protein_concentration_value"],
            similarity_value=data["result"]["similarity_value"],
        ),
        status=data["status"],
        status_information=data["status_information"],
        updated=data["updated"],
    )


def map_json_to_qascan_eval_result_model(json_data: dict) -> List[QAScanComparisonModel]:
    components = {
        comp["component"]["name"].lower(): comp["value"]
        for comp in json_data.get("result", {}).get("components", [])
    }

    # We roundoff values based on the number of decimal precision in the excel sheet
    return QAScanComparisonModel(
        measurement=json_data.get("measurement", {}).get("name"),
        histidin=safe_round(components.get("histidin"), 3),
        polysorbat80=safe_round(components.get("polysorbat80"), 3),
        polysorbat20=safe_round(components.get("polysorbat20"), 3),
        trehalose=safe_round(components.get("trehalose"), 3),
        nacl=safe_round(components.get("natriumchlorid"), 3),
        methionin=safe_round(components.get("methionin"), 3),
        saccharose=safe_round(components.get("saccharose"), 3),
        zitronensaeure=safe_round(components.get("zitronensaeure"), 3),
        phosphorsaeure=safe_round(components.get("phosphorsaeure"), 3),
        protein=safe_round(json_data.get("result", {}).get("protein_concentration_value"), 3),
        ph=safe_round(json_data.get("result", {}).get("ph_value"), 1),
        alphahelix=safe_round(json_data.get("result", {}).get("alpha_helix_value"), 2),
        betasheet=safe_round(json_data.get("result", {}).get("beta_sheet_value"), 2),
        proteinIdsimilarity=safe_round(json_data.get("result", {}).get("similarity_value"), 4),
    )


def map_json_to_dosim_eval_result_model(json_data: dict) -> List[DataDrivenComparisonModel]:
    components = json_data.get("result_summary", {}).get("data", [{}])[0].get("components", [])
    measurement_name = json_data.get("measurement", {}).get("name", "")

    component_map = {comp["name"].lower(): comp["value"] for comp in components}

    return DataDrivenComparisonModel(
        measurement=measurement_name,
        saccharose=component_map.get("saccharose"),
        glukose=component_map.get("glukose"),
        fruktose=component_map.get("fruktose"),
        milchsaeure=component_map.get("milchsaeure"),
        essigsaeure=component_map.get("essigsaeure"),
        brenztraubensaeure=component_map.get("brenztraubensaeure"),
        bernsteinsaeure=component_map.get("bernsteinsaeure"),
        zitronensaeure=component_map.get("zitronensaeure"),
        ameisensaeure=component_map.get("ameisensaeure"),
        alanin=component_map.get("alanin"),
        cystein=component_map.get("cystein"),
        lysin=component_map.get("lysin"),
        glutaminsaeure=component_map.get("glutaminsaeure"),
        isoleucin=component_map.get("isoleucin"),
        threonin=component_map.get("threonin"),
        phenylalanin=component_map.get("phenylalanin"),
        glutamin=component_map.get("glutamin"),
        phosphorsaeure=component_map.get("phosphorsaeure"),
        ammoniak=component_map.get("ammoniak"),
        schwefelsaeure=component_map.get("schwefelsaeure"),
    )


def map_datatable_to_qascan_method(step2, step31, step32, step33, step341) -> cqmm.QAScanMethod:
    """
    NOTE: This is only used for comparison purposes to check existing QA Scan method.\n
    DO NOT USE this function to create any API payloads.
    """

    def str_to_bool(val: str) -> bool:
        return val.strip().lower() == "true"

    # Feature toggles (step2)
    feature_map = {item["attribute"]: str_to_bool(item["checked"]) for item in step2}

    # Main component flags (step31)
    main_components = {item["component"].lower(): str_to_bool(item["main"]) for item in step31}

    # Calibration mapping (step32)
    def build_calibrations(step):
        return [
            cqmm.Calibration(
                id=item["measurement"], name=item["measurement"], measurement_timestamp=None
            )
            for item in step
        ]

    # Component concentration data and special values (step33)
    component_data = {}
    components = []
    protein_conc = None
    ph_buffer = None
    ph_formulation = None

    for item in step341:
        name = item["component"].strip().lower()
        formulation = float(item["formulation"])
        formulation_buffer = float(item["formulation_buffer"])

        if name == "protein concentration":
            protein_conc = formulation
        elif name == "ph":
            ph_formulation = formulation
            ph_buffer = formulation_buffer
        else:
            component_data[name] = {"formulation": formulation, "buffer": formulation_buffer}

    for name, data in component_data.items():
        comp_info = cqmm.ComponentInfo(id=name.replace(" ", "_"), name=name.capitalize(), iupac=[])
        comp = cqmm.Component(
            component=comp_info,
            concentration_buffer=data["buffer"],
            concentration_formulation=data["formulation"],
            concentration_limit_lower=data["formulation"]
            * (1 - (const.CONC_RANGE_OF_INTEREST / 100)),
            concentration_limit_upper=data["formulation"]
            * (1 + (const.CONC_RANGE_OF_INTEREST / 100)),
            main=main_components.get(name, False),
        )
        components.append(comp)

    return cqmm.QAScanMethod(
        id=None,
        name=None,
        method_type="qascan",
        created=None,
        updated=None,
        created_by=None,
        archived=False,
        has_evaluations=False,
        last_step=None,
        status=None,
        buffer_calibrations=build_calibrations(step33),
        formulation_calibrations=build_calibrations(step32),
        components=components,
        ph_buffer=ph_buffer,
        ph_formulation=ph_formulation,
        ph_limit_lower=ph_formulation - const.PH_RANGE_OF_INTEREST,
        ph_limit_upper=ph_formulation + const.PH_RANGE_OF_INTEREST,
        protein_concentration_formulation=protein_conc,
        protein_concentration_limit_lower=(
            (protein_conc * (1 - (const.CONC_RANGE_OF_INTEREST / 100))) if protein_conc else None
        ),
        protein_concentration_limit_upper=(
            (protein_conc * (1 + (const.CONC_RANGE_OF_INTEREST / 100))) if protein_conc else None
        ),
        validations=[],
        with_concentration=feature_map.get("with_concentration"),
        with_secondary_structure=feature_map.get("with_secondary_structure"),
        with_similarity=feature_map.get("with_similarity"),
        with_excipients=feature_map.get("with_excipients"),
        with_polysorbate=feature_map.get("with_polysorbate"),
        with_ph=feature_map.get("with_ph"),
    )
