import os
from enum import Enum
from pathlib import Path

ROOT_PROJECT_DIR = Path(__file__).parent.parent


class Env(Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    LOCAL = "local"


URLS = {
    Env.STAGING: "https://staging.clade-sphere.io/",
    Env.DEVELOPMENT: "https://development.clade-sphere.io/",
    Env.LOCAL: "https://development.clade-sphere.io/",
}

PROJECT = {
    Env.STAGING: "Project - Team All Member",
    Env.DEVELOPMENT: "Automation Project",
    Env.LOCAL: "Distinct Project",
}

ORGANIZATION = {
    Env.STAGING: "TEST ORGANIZATION",
    Env.DEVELOPMENT: "Avengers Org",
    Env.LOCAL: "Avengers Org",
}

USERS = {
    Env.DEVELOPMENT: {
        "owner": {
            "email": "jeffrey.manalo+development@clade.io",
            "password": "vZd3Yo%^ChSehs",
            "name": "Test_Owner_Do_Not_Delete",
        },
        "analyst": {
            "email": "8sazuuwar@mozmail.com",
            "password": "P@n0p10181920",
            "name": "Test_Sphere_Analyst",
        },
        "operator": {
            "email": "ftat6sq03@mozmail.com",
            "password": "o3{>|D@*R78:",
            "name": "test_sphere_operator",
        },
        "admin": {
            "email": "tccpxuzao@mozmail.com",
            "password": "s^rWsFf3IQv!#w$",
            "name": "Jeff Admin",
        },
    },
    Env.STAGING: {
        "admin": {
            "email": "tccpxuzao@mozmail.com",
            "password": "uqdy3Fyc7ZSjKrW",
            "name": "Test_Admin_Staging_Test",
        },
        "analyst": {
            "email": "8sazuuwar@mozmail.com",
            "password": "gAUzl6vdAkA9RRt",
            "name": "Test_Analyst_Staging",
        },
        "owner": {
            "email": "lhtdyf8cp@mozmail.com",
            "password": "LrIrYgpwNW0PQfO",
            "name": "Test_Owner_Staging",
        },
        "operator": {
            "email": "ftat6sq03@mozmail.com",
            "password": "xb1ACC5oxuL2lgz",
            "name": "Test_Operator_Staging",
        },
    },
    Env.LOCAL: {  # use dev credentials
        "owner": {
            "email": "jeffrey.manalo+development@clade.io",
            "password": "vZd3Yo%^ChSehs",
            "name": "Test_Owner_Do_Not_Delete",
        },
        "analyst": {
            "email": "8sazuuwar@mozmail.com",
            "password": "P@n0p10181920",
            "name": "Test_Sphere_Analyst",
        },
        "operator": {
            "email": "ftat6sq03@mozmail.com",
            "password": "o3{>|D@*R78:",
            "name": "test_sphere_operator",
        },
        "admin": {
            "email": "tccpxuzao@mozmail.com",
            "password": "s^rWsFf3IQv!#w$",
            "name": "Jeff Admin",
        },
    },
}

FAST_WAIT = 3_000
MID_WAIT = 7_000
LONG_WAIT = 12_000

EU_DATE_FORMAT = "%-d.%-m.%Y"
EU_DATE_FORMAT_REVERSE = "%d.%m.%Y"

# Assertion Texts
NACL_TEXT = (
    "Information: Natriumchlorid will be considered as requested but ommitted from the output. "
    "Internal algorithms for spectral correction do not allow for a calculation "
    "of the corresponding concentrations at the moment."
)
DATA_DRIVEN_METHOD_POPUP_TITLE = "Your new Data-Driven Method has been created as a draft"
DATA_DRIVEN_METHOD_POPUP_MSG = (
    "You can now review it and make it available to be used in evaluations."
)
DATA_DRIVEN_METHOD_NO_VALIDATION_TEXT = "Validation has been skipped during method creation."
REF_DRIVEN_METHOD_POPUP_TITLE = "The method is being created."
REF_DRIVEN_METHOD_POPUP_MSG = "This may take a moment."
REF_DRIVEN_HELP_TEXT_1 = "Please review your model for each analyte included."
REF_DRIVEN_HELP_TEXT_2 = (
    "You can change the default optimized number of factors "
    "based on your use case for all the analytes or per analyte."
)
REF_DRIVEN_HELP_TEXT_3 = "You cannot change a method after submission!"
METHOD_NAME_PLACEHOLDER = "method_name_dont_successfully_create"
METHODS_LIST_NO_MEASUREMENT_UPLOADED = "You need Measurements in order to create a Method."

# Data Driven Method Constants
CREATE_DOSIM_SINGLE_COMPONENT = "Aepfelsaeure"
CREATE_DOSIM_SINGLE_MEASUREMENT = "Measurement_3_1"

# Reference Driven Method Constants
PLS_SINGLE_ANALYTE = "Water"
PLS_MEASUREMENT = "Measurement_1_2,Measurement_3_1,Measurement_1_1"

# Reload Button Retry
MAX_RETRIES = 10

# Measurement Constant
MEASUREMENT_1_2 = "Measurement_1_2"

# Component Constants
WEINSAEURE = "Weinsaeure"
ESSIGSAEURE = "Essigsaeure"
SACCHAROSE = "Saccharose"
AEPFELSAEURE = "Aepfelsaeure"
NACL_NAMES = ["natriumchlorid", "nacl"]

# Remove Unusable Component Constants
REMOVE_UNUSABLE_COMP_POPUP_TITLE = "Data-Driven Method Creation failed."
REMOVE_UNUSABLE_COMP_POPUP_MSG = (
    "An insufficient number of suitable database entries exist for Essigsaeure, Aepfelsaeure. "
    "Please contact the CLADE Service team."
)
REMOVE_UNUSABLE_COMP_CONCENTRATION_VALUES = {
    ESSIGSAEURE: {"min": "200.9999", "max": "299.0001"},
    AEPFELSAEURE: {"min": "143.4444", "max": "250.3248"},
}
REMOVE_UNUSABLE_COMP_TOOL_TIP = (
    "The selected component is unavailable across selected pH range "
    "and concentration at the moment."
)

# EXCEL / CSVs / ZIP
API_DOSIM_TESTDATA_PATH = os.path.join("src", "api_utility", "testdata", "dosim")
API_QASCAN_TESTDATA_PATH = os.path.join("src", "api_utility", "testdata", "qascan")


class HttpMethod(Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


class Status(Enum):
    AVAILABLE = "available"
    DRAFT = "draft"
    FINISHED = "finished"
    FAILED = "failed"


class MethodType(Enum):
    QASCAN = "qascan"
    DOSIM = "dosim"


CONC_RANGE_OF_INTEREST = 10
PH_RANGE_OF_INTEREST = 0.25
