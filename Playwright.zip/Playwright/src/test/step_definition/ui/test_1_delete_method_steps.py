from playwright.sync_api import expect
from pytest_bdd import scenarios, then, when

import src.constants as const
from src.pom.base_page import BasePage
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.measurements_page import MeasurementsPage
from src.pom.methods_page import MethodsPage

scenarios(
    const.ROOT_PROJECT_DIR / "src/test/features/methods/list/active/delete.feature",
    const.ROOT_PROJECT_DIR / "src/test/features/methods/list/archived/delete.feature",
    const.ROOT_PROJECT_DIR / "src/test/features/methods/details/delete.feature",
)


@when("the user deletes the Method in Active Methods List Page")
def delete_method_in_methods_list_active_tab(context, methods_page: MethodsPage):
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.delete_methods_matching_string(context.method_name)


@when("the user deletes the Method in Archived Methods List Page")
def delete_method_in_methods_list_archived_tab(context, methods_page: MethodsPage):
    methods_page.go_to_archived_tab()
    delete_method_in_methods_list_active_tab(context, methods_page)


@when("the user deletes the Method in Methods Details Page from Active Tab")
def delete_method_in_methods_details_page_active_tab(
    context, methods_page: MethodsPage, base_page: BasePage
):
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.select_method_by_name(context.method_name)
    base_page.delete_method_in_details_page()
    methods_page.wait_for_loading_animation_to_end_without_data()


@when("the user deletes the Method in Methods Details Page from Archived Tab")
def delete_method_in_methods_details_page_archived_tab(
    context, methods_page: MethodsPage, data_driven_details_page: DataDrivenDetailsPage
):
    methods_page.go_to_archived_tab()
    delete_method_in_methods_details_page_active_tab(
        context, methods_page, data_driven_details_page
    )


@then("the method is successfully deleted")
def check_deletion(context, methods_page: MethodsPage, measurements_page: MeasurementsPage):
    methods_page.go_to_measurements_page()
    measurements_page.go_to_methods_page()
    expect(methods_page.methods_list).not_to_be_visible()

    # We also need to check Archived Tabs if method is not displayed in the list
    methods_page.go_to_archived_tab()
    expect(methods_page.methods_list).not_to_be_visible()


@then("the method cannot be deleted")
def check_cannot_delete(context, methods_page: MethodsPage, measurements_page: MeasurementsPage):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    expect(methods_page.action_delete_btn).to_be_disabled()
