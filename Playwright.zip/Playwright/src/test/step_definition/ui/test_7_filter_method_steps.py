from calendar import monthrange
from datetime import datetime as dt

from pytest_bdd import parsers, scenarios, then, when

from src.constants import EU_DATE_FORMAT_REVERSE, ROOT_PROJECT_DIR
from src.pom.methods_page import MethodsPage

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/methods/list/active/filtering.feature",
    ROOT_PROJECT_DIR / "src/test/features/methods/list/archived/filtering.feature",
)


@when(parsers.parse('the user filters Dates using "{start_date}" and "{end_date}"'))
def search_method_dates(context, start_date: str, end_date: str, methods_page: MethodsPage):
    context.pages_total_before_filtering = methods_page.get_total_list_pages()
    methods_page.refresh_page()
    methods_page.filter_date(start_date, end_date)


@when(parsers.parse('the user filters Status dropdown using "{method_status}"'))
def search_method_status(context, method_status, methods_page: MethodsPage):
    context.method_status = method_status
    methods_page.filter_status_dropdown(method_status)
    methods_page.wait_for_loading_animation_to_end_unknown_data()


@then("the Data Entries displayed contains the Specific Method Name ignore case")
def check_results_method_name(context):
    if context.method_list_value == []:
        raise Exception(
            f'There are no methods returned when filtering "{context.searched_method}" '
            "in Method Name textfield."
        )

    for value in context.method_list_value:
        if context.searched_method.casefold() not in value.casefold():
            raise Exception(
                f'Method List entry "{value}" does not contain the '
                f'string "{context.searched_method}".'
            )


@then(parsers.parse('the Data Entries displayed contains the Specific "{filter_type}" filter'))
def check_results_method_type(context, filter_type, methods_page: MethodsPage):
    if filter_type == "Method Type":
        filter = context.method_type
        methods = methods_page.get_method_list_property("method_type")
    elif filter_type == "Method Status":
        filter = context.method_status
        methods = methods_page.get_method_list_property("status")
    else:
        raise NotImplementedError

    assert methods, f'There are no methods returned when filtering for "{filter}".'
    assert all(
        filter == x for x in methods
    ), f'Data entries returned results with filter other than "{filter}":\n{methods}'


@then(
    parsers.parse('the methods list only contains entries between "{start_date}" and "{end_date}"')
)
def check_results_method_dates_period(
    context, start_date: str, end_date: str, methods_page: MethodsPage
):
    methods_page.wait_for_loading_animation_to_end_unknown_data()
    pages_total_after_filtering = methods_page.get_total_list_pages()
    method_dates = [
        date.split(", ")[0] for date in methods_page.get_method_list_property("created")
    ]

    today = dt.today().date()
    if start_date == "today":
        start_date = end_date = today.isoformat()
    elif start_date == "month":
        _, month_length = monthrange(today.year, today.month)
        start_date = today.replace(day=1).isoformat()
        end_date = today.replace(day=month_length).isoformat()

    assert context.pages_total_before_filtering >= pages_total_after_filtering
    assert all(
        dt.fromisoformat(start_date)
        <= dt.strptime(date, EU_DATE_FORMAT_REVERSE)
        <= dt.fromisoformat(end_date)
        for date in method_dates
    )


@then("the methods list is not filtered")
def check_methods_list_is_unfiltered(context, methods_page: MethodsPage):
    pages_total_after_filtering = methods_page.get_total_list_pages()
    assert context.pages_total_before_filtering == pages_total_after_filtering


@then("no data entries are displayed")
def check_method_list_empty(methods_page):
    assert not methods_page.get_method_list()
