from datetime import date

from playwright.sync_api import expect
from pytest_bdd import scenarios, then

import src.constants as const
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.data_driven_evaluation_details_page import DataDrivenEvaluationDetailsPage
from src.pom.evaluations_page import EvaluationsPage
from src.pom.measurement_details_page import MeasurementDetailsPage
from src.pom.ref_driven_details_page import ReferenceDrivenDetailsPage
from src.pom.ref_driven_evaluation_details_page import ReferenceDrivenEvaluationDetailsPage
from src.utility import Status

scenarios(const.ROOT_PROJECT_DIR / "src/test/features/evaluations/list/active/create.feature")


@then("the Data Driven evaluation single measurement is successfully created")
def check_evaluation_data_driven_single_measurement(
    context,
    evaluations_page: EvaluationsPage,
    data_driven_evaluation_details_page: DataDrivenEvaluationDetailsPage,
    data_driven_details_page: DataDrivenDetailsPage,
    measurement_details_page: MeasurementDetailsPage,
):
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Validate Evaluation List
    evaluations_page.wait_for_first_entry_to_have("status", Status.FINISHED.value)
    expect(evaluations_page.first_row.locator('[col-id="status"]')).to_have_text(
        Status.FINISHED.value
    )

    # Validate Evaluation Details Page
    evaluations_page.select_evaluation_by_name(context.evaluation_name)
    data_driven_evaluation_details_page.wait_for_details_to_load()

    """ MetaData Section """
    expect(data_driven_evaluation_details_page.status_finished_label).to_be_visible()
    expect(
        data_driven_evaluation_details_page.page.get_by_text(context.evaluation_name)
    ).to_be_visible()
    expect(data_driven_evaluation_details_page.data_driven_label).to_be_visible()
    expect(data_driven_evaluation_details_page.page.get_by_text(date_today)).to_be_visible()

    """ Method Link """
    data_driven_evaluation_details_page.go_to_link(context.method_name)
    data_driven_details_page.wait_for_url_to_have("methods/dosim/edit")
    data_driven_details_page.wait_for_data_driven_details_to_load()

    expect(data_driven_details_page.page.get_by_text(context.method_name)).to_be_visible()

    data_driven_details_page.go_back()
    data_driven_evaluation_details_page.wait_for_details_to_load()

    """ Measurement Link """
    data_driven_evaluation_details_page.go_to_link(context.list_measurement[0])
    measurement_details_page.wait_for_url_to_have("measurements")

    expect(measurement_details_page.measurement_name_txt).to_contain_text(
        context.list_measurement[0]
    )

    measurement_details_page.go_back()
    data_driven_evaluation_details_page.wait_for_details_to_load()

    """ Component Section """
    actual_evaluation_component_list = data_driven_evaluation_details_page.get_component_text()
    if "NaCl" in context.component_list:
        context.component_list.remove("NaCl")
    evaluation_unit_list = data_driven_evaluation_details_page.get_unit_text()

    assert context.component_list == actual_evaluation_component_list
    assert all("g/L" == x for x in evaluation_unit_list), 'Unit of measure is not using "g/L"'

    """ Residual Spectrum Section """
    expect(data_driven_evaluation_details_page.residual_spectrum_graph).to_be_visible()


@then("the Data Driven evaluation multiple measurement is successfully created")
def check_evaluation_data_driven_multiple_measurement(
    context,
    evaluations_page: EvaluationsPage,
    data_driven_evaluation_details_page: DataDrivenEvaluationDetailsPage,
    data_driven_details_page: DataDrivenDetailsPage,
    measurement_details_page: MeasurementDetailsPage,
):
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Validate Evaluation List
    evaluations_page.wait_for_all_entries_to_have(
        context.evaluation_name, "status", Status.FINISHED.value
    )
    actual_list_status = evaluations_page.evaluation_list.locator(
        '[col-id="status"]'
    ).all_inner_texts()
    assert all(Status.FINISHED.value == status for status in actual_list_status)

    # Validate Evaluation Details Page
    list_evaluations = (
        evaluations_page.evaluation_list.filter(has_text=context.evaluation_name)
        .locator('[col-id="name"]')
        .all()
    )

    # The default sort in displaying multiple evaluation is Descending.
    # We reverse the order of the elements inside the list for simplicity.
    rev_list = list_evaluations[::-1]

    for expected_idx, evaluation in enumerate(rev_list, start=1):
        evaluation_name = evaluation.inner_text()
        _, actual_idx = evaluation_name.split()

        evaluations_page.select_evaluation_by_name(evaluation_name)
        data_driven_evaluation_details_page.wait_for_details_to_load()

        """ MetaData Section """
        expect(data_driven_evaluation_details_page.status_finished_label).to_be_visible()
        expect(
            data_driven_evaluation_details_page.page.get_by_text(evaluation_name)
        ).to_be_visible()
        expect(data_driven_evaluation_details_page.data_driven_label).to_be_visible()
        expect(data_driven_evaluation_details_page.page.get_by_text(date_today)).to_be_visible()
        assert expected_idx == int(actual_idx)

        """ Method Link """
        data_driven_evaluation_details_page.go_to_link(context.method_name)
        data_driven_details_page.wait_for_url_to_have("methods/dosim/edit")
        data_driven_details_page.wait_for_data_driven_details_to_load()

        expect(data_driven_details_page.page.get_by_text(context.method_name)).to_be_visible()

        data_driven_details_page.go_back()
        data_driven_evaluation_details_page.wait_for_details_to_load()

        """ Measurement Link """
        # Since evaluation-measurement link is randomized,
        # we need to loop within the list of measurements to get the correct link
        for measurement in context.list_measurement:
            try:
                data_driven_evaluation_details_page.go_to_link(measurement)
                measurement_details_page.wait_for_url_to_have("measurements")

                expect(measurement_details_page.measurement_name_txt).to_contain_text(measurement)

                break
            except Exception:
                continue

        measurement_details_page.go_back()
        data_driven_evaluation_details_page.wait_for_details_to_load()

        """ Component Section """
        actual_evaluation_component_list = data_driven_evaluation_details_page.get_component_text()
        if "NaCl" in context.component_list:
            context.component_list.remove("NaCl")
        evaluation_unit_list = data_driven_evaluation_details_page.get_unit_text()

        assert context.component_list == actual_evaluation_component_list
        assert all("g/L" == x for x in evaluation_unit_list), 'Unit of measure is not using "g/L"'

        """ Residual Spectrum Section """
        expect(data_driven_evaluation_details_page.residual_spectrum_graph).to_be_visible()

        data_driven_evaluation_details_page.back_btn.click()
        data_driven_evaluation_details_page.wait_for_loading_animation_to_end_with_data()


@then("the Reference Driven evaluation single measurement is successfully created")
def check_evaluation_reference_driven_single_measurement(
    context,
    evaluations_page: EvaluationsPage,
    ref_driven_evaluation_details_page: ReferenceDrivenEvaluationDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
    measurement_details_page: MeasurementDetailsPage,
):
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Validate Evaluation List
    evaluations_page.wait_for_first_entry_to_have("status", Status.FINISHED.value)
    expect(evaluations_page.first_row.locator('[col-id="status"]')).to_have_text(
        Status.FINISHED.value
    )

    # Validate Evaluation Details Page
    evaluations_page.select_evaluation_by_name(context.evaluation_name)
    ref_driven_evaluation_details_page.wait_for_details_to_load()

    """ MetaData Section """
    expect(ref_driven_evaluation_details_page.status_finished_label).to_be_visible()
    expect(
        ref_driven_evaluation_details_page.page.get_by_text(context.evaluation_name)
    ).to_be_visible()
    expect(ref_driven_evaluation_details_page.ref_driven_label).to_be_visible()
    expect(ref_driven_evaluation_details_page.page.get_by_text(date_today)).to_be_visible()

    """ Method Link """
    ref_driven_evaluation_details_page.go_to_link(context.method_name)
    ref_driven_details_page.wait_for_url_to_have("methods/pls/edit")
    ref_driven_details_page.wait_for_ref_driven_to_load()

    expect(ref_driven_details_page.page.get_by_text(context.method_name)).to_be_visible()

    ref_driven_details_page.go_back()
    ref_driven_evaluation_details_page.wait_for_details_to_load()

    """ Measurement Link """
    ref_driven_evaluation_details_page.go_to_link(context.list_measurement[0])
    measurement_details_page.wait_for_url_to_have("measurements")

    expect(measurement_details_page.measurement_name_txt).to_contain_text(
        context.list_measurement[0]
    )

    measurement_details_page.go_back()
    ref_driven_evaluation_details_page.wait_for_details_to_load()

    """ Analyte Section """
    actual_evaluation_analyte_list = ref_driven_evaluation_details_page.get_analyte_text()
    evaluation_unit_list = ref_driven_evaluation_details_page.get_unit_text()

    assert context.analyte_name == actual_evaluation_analyte_list[0].strip()
    assert all(
        "g/L" == x.strip() for x in evaluation_unit_list
    ), 'Unit of measure is not using "g/L"'


@then("the Reference Driven evaluation multiple measurement is successfully created")
def check_evaluation_reference_driven_multiple_measurement(
    context,
    evaluations_page: EvaluationsPage,
    measurement_details_page: MeasurementDetailsPage,
    ref_driven_evaluation_details_page: ReferenceDrivenEvaluationDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Validate Evaluation List
    evaluations_page.wait_for_all_entries_to_have(
        context.evaluation_name, "status", Status.FINISHED.value
    )
    actual_list_status = evaluations_page.evaluation_list.locator(
        '[col-id="status"]'
    ).all_inner_texts()
    assert all(Status.FINISHED.value == status for status in actual_list_status)

    # Validate Evaluation Details Page
    list_evaluations = (
        evaluations_page.evaluation_list.filter(has_text=context.evaluation_name)
        .locator('[col-id="name"]')
        .all()
    )

    # The default sort in displaying multiple evaluation is Descending.
    # We reverse the order of the elements inside the list for simplicity.
    rev_list = list_evaluations[::-1]

    for expected_idx, evaluation in enumerate(rev_list, start=1):
        evaluation_name = evaluation.inner_text()
        _, actual_idx = evaluation_name.split()

        evaluations_page.select_evaluation_by_name(evaluation_name)
        ref_driven_evaluation_details_page.wait_for_details_to_load()

        """ MetaData Section """
        expect(ref_driven_evaluation_details_page.status_finished_label).to_be_visible()
        expect(ref_driven_evaluation_details_page.page.get_by_text(evaluation_name)).to_be_visible()
        expect(ref_driven_evaluation_details_page.ref_driven_label).to_be_visible()
        expect(ref_driven_evaluation_details_page.page.get_by_text(date_today)).to_be_visible()
        assert expected_idx == int(actual_idx)

        """ Method Link """
        ref_driven_evaluation_details_page.go_to_link(context.method_name)
        ref_driven_details_page.wait_for_url_to_have("methods/pls/edit")
        ref_driven_details_page.wait_for_ref_driven_to_load()

        expect(ref_driven_details_page.page.get_by_text(context.method_name)).to_be_visible()

        ref_driven_details_page.go_back()
        ref_driven_evaluation_details_page.wait_for_details_to_load()

        """ Measurement Link """
        # Since evaluation-measurement link is randomized,
        # we need to loop within the list of measurements to get the correct link
        for measurement in context.list_measurement:
            try:
                ref_driven_evaluation_details_page.go_to_link(measurement)
                measurement_details_page.wait_for_url_to_have("measurements")

                expect(measurement_details_page.measurement_name_txt).to_contain_text(measurement)

                break
            except Exception:
                continue

        measurement_details_page.go_back()
        ref_driven_evaluation_details_page.wait_for_details_to_load()

        """ Component Section """
        actual_evaluation_analyte_list = ref_driven_evaluation_details_page.get_analyte_text()
        evaluation_unit_list = ref_driven_evaluation_details_page.get_unit_text()

        assert context.analyte_name == actual_evaluation_analyte_list[0].strip()
        assert all(
            "g/L" == x.strip() for x in evaluation_unit_list
        ), 'Unit of measure is not using "g/L"'

        ref_driven_evaluation_details_page.back_btn.click()
        ref_driven_evaluation_details_page.wait_for_loading_animation_to_end_with_data()
