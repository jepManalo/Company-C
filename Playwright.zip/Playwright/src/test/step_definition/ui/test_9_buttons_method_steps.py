from playwright.sync_api import expect
from pytest_bdd import parsers, scenarios, then, when

from src.constants import ROOT_PROJECT_DIR
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.methods_page import MethodsPage
from src.pom.ref_driven_details_page import ReferenceDrivenDetailsPage
from src.utility import MethodType

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/methods/details/buttons.feature",
    ROOT_PROJECT_DIR / "src/test/features/methods/list/active/buttons.feature",
    ROOT_PROJECT_DIR / "src/test/features/methods/list/archived/buttons.feature",
)


@when(
    parsers.parse(
        'the user is in Methods Details page of "{method_type}" in Active Tab with "{status}"'
    )
)
def search_method_type_and_status_active_tab(
    method_type, status, navigate_to_methods_list, methods_page: MethodsPage
):
    methods_page.filter_types_dropdown(method_type)
    methods_page.filter_status_dropdown(status)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.methods_list.nth(0).click()


@when(
    parsers.parse(
        'the user is in Methods Details page of "{method_type}" in Archived Tab with "{status}"'
    )
)
def search_method_type_and_status_archive_tab(
    method_type, status, navigate_to_archived_methods_list, methods_page: MethodsPage
):
    methods_page.filter_types_dropdown(method_type)
    methods_page.filter_status_dropdown(status)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.methods_list.nth(0).click()


@when(parsers.parse('the user navigates to the "{method_type}" Methods Details Page - Active Tab'))
def search_method_type_active_tab(method_type, navigate_to_methods_list, methods_page: MethodsPage):
    methods_page.filter_types_dropdown(method_type)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.methods_list.nth(0).click()


@when(
    parsers.parse('the user navigates to the "{method_type}" Methods Details Page - Archived Tab')
)
def search_method_type_archive_tab(
    method_type, navigate_to_archived_methods_list, methods_page: MethodsPage
):
    methods_page.filter_types_dropdown(method_type)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.methods_list.nth(0).click()


@then(parsers.parse('all action buttons in "{method_type}" are disabled - Active detail'))
def check_btn_method_active(
    method_type,
    data_driven_details_page: DataDrivenDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    if method_type == MethodType.DATA_DRIVEN.value:
        expect(data_driven_details_page.export_btn).to_be_disabled()
        expect(data_driven_details_page.archive_btn).to_be_disabled()
        expect(data_driven_details_page.delete_btn).to_be_disabled()
    elif method_type == MethodType.REF_DRIVEN.value:
        expect(ref_driven_details_page.export_btn).to_be_disabled()
        expect(ref_driven_details_page.archive_btn).to_be_disabled()
        expect(ref_driven_details_page.delete_btn).to_be_disabled()


@then(parsers.parse('all action buttons in "{method_type}" are disabled - Archived detail'))
def check_btn_method_archived(
    method_type,
    data_driven_details_page: DataDrivenDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    if method_type == MethodType.DATA_DRIVEN.value:
        expect(data_driven_details_page.export_btn).to_be_disabled()
        expect(data_driven_details_page.unarchive_btn).to_be_disabled()
        expect(data_driven_details_page.delete_btn).to_be_disabled()
    elif method_type == MethodType.REF_DRIVEN.value:
        expect(ref_driven_details_page.export_btn).to_be_disabled()
        expect(ref_driven_details_page.unarchive_btn).to_be_disabled()
        expect(ref_driven_details_page.delete_btn).to_be_disabled()


@then("active action buttons are disabled")
def check_active_button_status(methods_page: MethodsPage):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    while methods_page.next_page_btn.is_enabled():
        expect(methods_page.new_method_btn).to_be_disabled()
        expect(methods_page.action_export_btn).to_be_disabled()
        for button in methods_page.action_delete_btn.all():
            expect(button).to_be_disabled()
        for button in methods_page.archive_btn_list.all():
            expect(button).to_be_disabled()
        methods_page.click_next_page_and_wait_with_data()


@then("archived action buttons are disabled")
def check_archive_button_status(methods_page: MethodsPage):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    while methods_page.next_page_btn.is_enabled():
        expect(methods_page.new_method_btn).not_to_be_visible()
        expect(methods_page.action_export_btn).to_be_disabled()
        for button in methods_page.action_delete_btn.all():
            expect(button).to_be_disabled()
        for button in methods_page.unarchive_btn_list.all():
            expect(button).to_be_disabled()
        methods_page.click_next_page_and_wait_with_data()


@then(parsers.parse('the user "{permission}" export the "{method_type}"'))
def check_export_btn_permission(
    method_type,
    permission,
    data_driven_details_page: DataDrivenDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    if method_type == MethodType.DATA_DRIVEN.value:
        if permission == "can":
            expect(data_driven_details_page.export_btn).to_be_enabled()
        elif permission == "cannot":
            expect(data_driven_details_page.export_btn).to_be_disabled()
    elif method_type == MethodType.REF_DRIVEN.value:
        if permission == "can":
            expect(ref_driven_details_page.export_btn).to_be_enabled()
        elif permission == "cannot":
            expect(ref_driven_details_page.export_btn).to_be_disabled()
