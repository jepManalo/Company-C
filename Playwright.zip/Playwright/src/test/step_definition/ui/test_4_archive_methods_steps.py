from playwright.sync_api import expect
from pytest_bdd import parsers, scenarios, then, when

from src.constants import ROOT_PROJECT_DIR
from src.pom.base_page import BasePage
from src.pom.evaluation_measurement_page import EvaluationMeasurementPage
from src.pom.evaluation_method_page import EvaluationMethodPage
from src.pom.evaluations_page import EvaluationsPage
from src.pom.methods_page import MethodsPage
from src.utility import Status

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/methods/list/active/archive.feature",
    ROOT_PROJECT_DIR / "src/test/features/methods/details/archive.feature",
)


@when(parsers.parse('the user clicks the "{action}" button in Details Page'))
def archive_method_details_page(
    context, action, search_method, methods_page: MethodsPage, base_page: BasePage
):
    methods_page.select_method_by_name(context.method_name)

    # Since this step definition is used for both Data Driven
    # and Reference Driven methods, we use base_page
    if action == "Archive":
        base_page.archive_btn.click()
    elif action == "Unarchive":
        base_page.unarchive_btn.click()

    # Since we do not have any visual cues after clicking the button,
    # We just wait implicitly
    base_page.page.wait_for_timeout(1000)


@then("the method is archived")
def check_archived_method(
    context,
    methods_page: MethodsPage,
):
    """Validation in Active Methods Tab"""
    methods_page.wait_for_loading_animation_to_end_without_data()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_without_data()
    expect(methods_page.page.get_by_text(context.method_name)).not_to_be_visible()

    """ Validaiton in Archived Methods Tab """
    methods_page.go_to_archived_tab()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    expect(methods_page.page.get_by_text(context.method_name)).to_be_visible()


@then("the method is unarchived")
def check_unarchived_method(
    context,
    methods_page: MethodsPage,
):
    """Validation in Archived Methods Tab"""
    methods_page.wait_for_loading_animation_to_end_without_data()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_without_data()
    expect(methods_page.page.get_by_text(context.method_name)).not_to_be_visible()

    """ Validaiton in Active Methods Tab """
    methods_page.go_to_active_tab()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    expect(methods_page.page.get_by_text(context.method_name)).to_be_visible()


@then("the Archive button changes to Unarchive button")
def check_archived_method_details_page(
    base_page: BasePage,
):
    expect(base_page.archive_btn).not_to_be_visible()
    expect(base_page.unarchive_btn).to_be_enabled()

    base_page.go_back()


@then("the Unarchive button changes to Archive button")
def check_unarchived_method_details_page(
    base_page: BasePage,
):
    expect(base_page.unarchive_btn).not_to_be_visible()
    expect(base_page.archive_btn).to_be_enabled()

    base_page.go_back()


@then("the method is available for evaluation")
def check_active_method_in_evaluation(
    context,
    methods_page: MethodsPage,
    evaluations_page: EvaluationsPage,
    evaluation_measurement_page: EvaluationMeasurementPage,
    evaluation_method_page: EvaluationMethodPage,
):
    if context.status == Status.AVAILABLE.value:
        # Validate Method is available for Evaluation
        methods_page.go_to_evaluations_page()
        evaluations_page.new_evaluation_btn.click()
        evaluation_measurement_page.measurement_for_validation.click()
        evaluation_measurement_page.next_btn.click()
        evaluation_method_page.filter_method(context.method_name)
        evaluation_method_page.wait_for_loading_animation_to_end_with_data()
        expect(evaluation_method_page.methods_list).to_be_visible()
    elif context.status == Status.DRAFT.value:
        return
    else:
        raise AssertionError(f"Unexpected...:{context.status}")


@then("the method is not available for evaluation")
def check_archived_method_in_evaluation(
    context,
    methods_page: MethodsPage,
    evaluations_page: EvaluationsPage,
    evaluation_measurement_page: EvaluationMeasurementPage,
    evaluation_method_page: EvaluationMethodPage,
):
    if context.status == Status.AVAILABLE.value:
        # Validate Method is available for Evaluation
        methods_page.go_to_evaluations_page()
        evaluations_page.new_evaluation_btn.click()
        evaluation_measurement_page.measurement_for_validation.click()
        evaluation_measurement_page.next_btn.click()
        evaluation_method_page.filter_method(context.method_name)
        evaluation_method_page.wait_for_loading_animation_to_end_without_data()
        expect(evaluation_method_page.methods_list).not_to_be_visible()

        evaluations_page.go_to_methods_page()
        methods_page.go_to_archived_tab()
    elif context.status == Status.DRAFT.value:
        return
    else:
        raise AssertionError(f"Unexpected...:{context.status}")
