from playwright.sync_api import expect
from pytest_bdd import scenarios, then, when

from src.constants import ROOT_PROJECT_DIR
from src.pom.evaluations_details_page import EvaluationsDetailsPage
from src.pom.evaluations_page import EvaluationsPage

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/evaluations/details/active/delete.feature",
    ROOT_PROJECT_DIR / "src/test/features/evaluations/details/archived/delete.feature",
    ROOT_PROJECT_DIR / "src/test/features/evaluations/list/active/delete.feature",
    ROOT_PROJECT_DIR / "src/test/features/evaluations/list/archived/delete.feature",
)


@when("the user deletes the Evaluation in Evaluation Details page from Active Evaluations tab")
def delete_evaluation_in_details_page_from_active_tab(
    navigate_to_active_evaluations_list,
    evaluations_page: EvaluationsPage,
    evaluations_details_page: EvaluationsDetailsPage,
):
    # Note that the newly created evaluation is always
    # at the first row of the Evaluation List page
    evaluations_page.evaluation_list.nth(0).click()
    evaluations_details_page.delete_evaluation()


@when("the user deletes the Evaluation in Evaluation Details page from Archived Evaluations tab")
def delete_evaluation_in_details_page_from_archived_tab(
    navigate_to_archived_evaluations_list,
    evaluations_page: EvaluationsPage,
    evaluations_details_page: EvaluationsDetailsPage,
):
    # Note that the newly created evaluation is always
    # at the first row of the Evaluation List page
    evaluations_page.evaluation_list.nth(0).click()
    evaluations_details_page.delete_evaluation()


@when("the user deletes the Evaluation from the Active Evaluation tab")
def delete_evaluation_from_active_list(
    context, navigate_to_active_evaluations_list, evaluations_page: EvaluationsPage
):
    # Note that the newly created evaluation is always
    # at the first row of the Evaluation List page
    evaluations_page.delete_evaluation(context.evaluation_name)


@when("the user deletes the Evaluation from the Archived Evaluation tab")
def delete_evaluation_from_archived_list(
    context, navigate_to_archived_evaluations_list, evaluations_page: EvaluationsPage
):
    # Note that the newly created evaluation is always
    # at the first row of the Evaluation List page
    evaluations_page.delete_evaluation(context.evaluation_name)


@when("the user archives the Evaluation from the Evaluation list")
def select_method(context, evaluations_page: EvaluationsPage):
    evaluations_page.archive_evaluation(context.evaluation_name)


@then("the evaluation is deleted")
def verify_deleted_evaluation(context, evaluations_page: EvaluationsPage):
    evaluations_page.go_to_active_tab()
    evaluations_page.wait_for_loading_animation_to_end_with_data()
    expect(evaluations_page.evaluation_list.locator('[col-id="name"]').nth(0)).not_to_have_text(
        context.evaluation_name
    )

    evaluations_page.go_to_archived_tab()
    evaluations_page.wait_for_loading_animation_to_end_with_data()
    expect(evaluations_page.evaluation_list.locator('[col-id="name"]').nth(0)).not_to_have_text(
        context.evaluation_name
    )
