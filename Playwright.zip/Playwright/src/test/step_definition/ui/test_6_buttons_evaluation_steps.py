from playwright.sync_api import expect
from pytest_bdd import parsers, scenarios, then

from src.constants import ROOT_PROJECT_DIR
from src.pom.evaluations_details_page import EvaluationsDetailsPage

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/evaluations/details/active/buttons.feature",
    ROOT_PROJECT_DIR / "src/test/features/evaluations/details/archived/buttons.feature",
)


@then(parsers.parse('"{buttons}" button is disabled'))
def check_button(evaluations_details_page: EvaluationsDetailsPage, buttons):
    # Tooltips are not working on chromium but working in non-automation chrome driver.
    # We skip checking on tool tips in our automation for now until this is resolved.
    # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2215
    if buttons == "archive":
        expect(evaluations_details_page.archive_btn).to_be_disabled()
        expect(evaluations_details_page.unarchive_btn).not_to_be_visible()
    elif buttons == "delete":
        expect(evaluations_details_page.delete_btn).to_be_disabled()
    elif buttons == "unarchive":
        expect(evaluations_details_page.unarchive_btn).to_be_disabled()
        expect(evaluations_details_page.archive_btn).not_to_be_visible()
    else:
        raise Exception(f"{buttons} is not implemented in Evaluations Details page")
