from pytest_bdd import parsers, scenarios, then, when

from src.constants import ROOT_PROJECT_DIR
from src.pom.methods_page import MethodsPage
from src.utility import METHOD_STATUS_ORDER

scenarios(
    ROOT_PROJECT_DIR / "src/test/features/methods/list/archived/sorting.feature",
    ROOT_PROJECT_DIR / "src/test/features/methods/list/active/sorting.feature",
)


@when(parsers.parse('the user sorts names "{order}"'))
def sort_by_names(context, order, methods_page: MethodsPage):
    methods_page.sort_by_column("name", order)
    context.order = order
    context.method_list = methods_page.get_method_list_property("name")


@when(parsers.parse('the user sorts status "{order}"'))
def sort_by_status(context, order, methods_page: MethodsPage):
    methods_page.sort_by_column("status", order)
    context.order = order
    context.method_list = methods_page.get_method_list_property("status")


@then("the Method Names displayed are sorted correctly")
def check_correct_names_order(context):
    ascending = sorted(context.method_list)
    descending = ascending[::-1]
    order = context.order

    if order == "ascending":
        assert context.method_list == ascending
    elif order == "descending":
        assert context.method_list == descending
    elif order == "default":
        # Regarding the status ordering there is an ongoing issue,
        # that also touches the 'default' sorting:
        # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2169
        # Thus we do not test that, for the time being.
        return
    else:
        raise AssertionError(f"Invalid ordering direction {order}")


@then("the Method Status displayed are sorted correctly")
def check_correct_status_order(context):
    status_order_mapping = {stat.value: pos for pos, stat in enumerate(METHOD_STATUS_ORDER)}
    ascending = sorted(context.method_list, key=status_order_mapping.get)
    descending = ascending[::-1]

    order = context.order
    if order == "ascending":
        assert context.method_list == ascending
    elif order == "descending":
        assert context.method_list == descending
    elif order == "default":
        # Regarding the status ordering there is an ongoing issue,
        # that also touches the 'default' sorting:
        # https://gitlab.com/mbio/mbiosphere/sphere/-/issues/2169
        # Thus we do not test that, for the time being.
        return
    else:
        raise AssertionError(f"Invalid ordering direction {order}")
