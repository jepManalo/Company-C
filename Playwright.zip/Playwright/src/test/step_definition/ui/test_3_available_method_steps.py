from playwright.sync_api import expect
from pytest_bdd import parsers, scenarios, then, when

from src.constants import ROOT_PROJECT_DIR
from src.pom.base_page import BasePage
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.evaluation_measurement_page import EvaluationMeasurementPage
from src.pom.evaluation_method_page import EvaluationMethodPage
from src.pom.evaluations_page import EvaluationsPage
from src.pom.methods_page import MethodsPage
from src.utility import Status

scenarios(ROOT_PROJECT_DIR / "src/test/features/methods/details/available.feature")


@when(
    parsers.parse(
        'the user searches for methods with type "{method_type}", status "{method_status}"'
    )
)
def search_data_driven_method_with_method_name(
    method_type, method_status, navigate_to_methods_list, methods_page: MethodsPage
):
    methods_page.filter_types_dropdown(method_type)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.filter_status_dropdown(method_status)
    methods_page.wait_for_loading_animation_to_end_with_data()


@when("the user selects a method from the list")
def select_method(methods_page: MethodsPage):
    methods_page.methods_list.nth(0).click()


@when("the user makes the created method Available")
def make_data_driven_method_available(context, methods_page: MethodsPage, base_page: BasePage):
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.select_method_by_name(context.method_name)
    base_page.make_method_available()
    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.wait_for_first_entry_to_have("status", Status.AVAILABLE.value)


@then("the methods are now available for evaluation")
def check_available_status(
    context,
    methods_page: MethodsPage,
    data_driven_details_page: DataDrivenDetailsPage,
    evaluations_page: EvaluationsPage,
    evaluation_measurement_page: EvaluationMeasurementPage,
    evaluation_method_page: EvaluationMethodPage,
):
    methods_page.clear_all_filter()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()

    # Validate Methods List Page
    actual_method_status_list = methods_page.get_method_list_property("status")
    assert actual_method_status_list[0] == Status.AVAILABLE.value

    # Validate Methods Details Page
    methods_page.select_method_by_name(context.method_name)
    actual_method_status = data_driven_details_page.get_method_status()
    assert actual_method_status == Status.AVAILABLE.value

    # Validate Method is available for Evaluation
    methods_page.go_to_evaluations_page()
    evaluations_page.new_evaluation_btn.click()
    evaluation_measurement_page.measurement_for_validation.click()
    evaluation_measurement_page.next_btn.click()
    evaluation_method_page.filter_method(context.method_name)
    evaluation_method_page.wait_for_loading_animation_to_end_with_data()
    expect(evaluation_method_page.methods_list).to_be_visible()


@then("the Make Available button is not visible")
def check_make_available_button(data_driven_details_page: DataDrivenDetailsPage):
    expect(data_driven_details_page.make_available_btn).not_to_be_visible()
