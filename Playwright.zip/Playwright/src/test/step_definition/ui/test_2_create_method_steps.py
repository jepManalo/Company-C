from datetime import date

from playwright.sync_api import expect
from pytest_bdd import parsers, scenarios, then, when

import src.constants as const
from src.pom.create_method_page import CreateMethodPage
from src.pom.data_driven_component_page import DataDrivenComponentPage
from src.pom.data_driven_concentration_page import DataDrivenConcentrationPage
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.data_driven_measurement_page import DataDrivenMeasurementPage
from src.pom.methods_page import MethodsPage
from src.pom.ref_driven_analyte_page import ReferenceDrivenAnalytePage
from src.pom.ref_driven_details_page import ReferenceDrivenDetailsPage
from src.pom.ref_driven_measurement_page import ReferenceDrivenMeasurementPage
from src.utility import Status

scenarios(
    const.ROOT_PROJECT_DIR / "src/test/features/methods/list/active/create.feature",
    const.ROOT_PROJECT_DIR / "src/test/features/methods/list/archived/create.feature",
)


@when(
    parsers.parse(
        "the user creates a new Data Driven Method using "
        '"{component}", "{min_conc}", "{max_conc}", "{measurement}", "{validation}"'
    )
)
def create_data_driven_single_component(
    context,
    component,
    min_conc,
    max_conc,
    measurement,
    validation,
    nonce,
    generate_ph_level,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    data_driven_measurement_page: DataDrivenMeasurementPage,
    data_driven_concentration_page: DataDrivenConcentrationPage,
):
    context.component = component
    context.min_conc = min_conc
    context.max_conc = max_conc
    context.measurement = measurement
    context.validation = validation
    context.method_name = f"{nonce}-{component}-{validation}Validation"
    context.min_ph = generate_ph_level[0]
    context.max_ph = generate_ph_level[1]

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(context.method_name)
    data_driven_component_page.set_ph_levels(context.min_ph, context.max_ph)
    data_driven_component_page.add_components([context.component])
    data_driven_component_page.update_concentration(
        context.component, context.min_conc, context.max_conc
    )

    if validation == "with":
        data_driven_component_page.create_method_with_validation()
        data_driven_measurement_page.select_measurements([context.measurement])
        data_driven_measurement_page.next_btn.click()
        data_driven_concentration_page.finalize_method_creation()
    else:
        data_driven_component_page.create_method_without_validation()

    methods_page.wait_confirmation_pop_up_to_appear()


@when(
    parsers.parse(
        "the user creates a new Data Driven Method using "
        '"{component}", "{measurement}", "{validation}"'
    )
)
def create_data_driven_multiple_component(
    context,
    component,
    measurement,
    validation,
    nonce,
    generate_ph_level,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    data_driven_measurement_page: DataDrivenMeasurementPage,
    data_driven_concentration_page: DataDrivenConcentrationPage,
):
    context.component_list = component.split(",")
    context.measurement_list = measurement.split(",")
    context.validation = validation
    context.method_name = f"{nonce}-{component}-{validation}Validation"
    context.min_ph = generate_ph_level[0]
    context.max_ph = generate_ph_level[1]

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(context.method_name)
    data_driven_component_page.set_ph_levels(context.min_ph, context.max_ph)
    data_driven_component_page.add_components(context.component_list)

    if validation == "with":
        data_driven_component_page.create_method_with_validation()
        data_driven_measurement_page.select_measurements(context.measurement_list)
        data_driven_measurement_page.next_btn.click()
        data_driven_concentration_page.finalize_method_creation()
    else:
        data_driven_component_page.create_method_without_validation()

    methods_page.wait_confirmation_pop_up_to_appear()


@when(
    parsers.parse(
        'the user creates a new Reference Driven Method using "{measurement}", "{analyte_name}"'
    )
)
def create_ref_driven_single_analyte(
    context,
    measurement,
    analyte_name,
    nonce,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    ref_driven_measurement_page: ReferenceDrivenMeasurementPage,
    ref_driven_analyte_page: ReferenceDrivenAnalytePage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    context.measurement_list = measurement.split(",")
    context.method_name = f"{nonce}-{analyte_name}"
    context.analyte_name = analyte_name

    methods_page.click_new_method_btn()
    create_method_page.initialize_ref_driven_creation(context.method_name)
    ref_driven_measurement_page.select_measurements(context.measurement_list)
    ref_driven_measurement_page.next_btn.click()
    ref_driven_analyte_page.change_analyte_name(context.analyte_name)
    ref_driven_analyte_page.finalize_method_creation()

    """
    NOTE:
    =================================================================
    If the method is in "Creating" status, user is in Details Page
    If the method is in "Validating" status, user is in List Page
    We need to handle these fluctuating situations to not have flaky tests
    """
    if "methods/pls/edit" in ref_driven_details_page.page.url:
        ref_driven_details_page.return_to_methods_list()

    methods_page.wait_confirmation_pop_up_to_appear()


@when("the user clicks Clear Datatable button during Data Driven Method creation")
def click_clear_datatable_button(
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    navigate_to_methods_list,
):
    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(const.METHOD_NAME_PLACEHOLDER)
    data_driven_component_page.add_components(
        [const.ESSIGSAEURE, const.AEPFELSAEURE, const.WEINSAEURE]
    )
    data_driven_component_page.remove_all_btn.click()


@when("the user clicks Remove Unusable Component button during Data Driven Method creation")
def click_remove_unusable_component_button(
    context,
    generate_ph_level,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
):
    create_data_driven_method_with_unusable_component(
        context, generate_ph_level, methods_page, create_method_page, data_driven_component_page
    )
    data_driven_component_page.remove_unusable_components_btn.click()


@when("the user creates a Data Driven Method using component with unusable concentrations")
def create_data_driven_method_with_unusable_component(
    context,
    generate_ph_level,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
):
    context.removed_components = [const.ESSIGSAEURE, const.AEPFELSAEURE]
    context.retained_components = [const.WEINSAEURE, const.SACCHAROSE]
    list_of_components = [const.WEINSAEURE, const.ESSIGSAEURE, const.SACCHAROSE, const.AEPFELSAEURE]

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(const.METHOD_NAME_PLACEHOLDER)
    data_driven_component_page.set_ph_levels(generate_ph_level[0], generate_ph_level[1])
    data_driven_component_page.add_components(list_of_components)

    # We only update the concentration values of the removed_components list
    # so that they become unusable
    for component in context.removed_components:
        data_driven_component_page.update_concentration(
            component,
            const.REMOVE_UNUSABLE_COMP_CONCENTRATION_VALUES[component]["min"],
            const.REMOVE_UNUSABLE_COMP_CONCENTRATION_VALUES[component]["max"],
        )

    data_driven_component_page.skip_validation_chekbox.click()
    data_driven_component_page.create_btn.click()
    data_driven_component_page.wait_confirmation_pop_up_to_appear()


@when(
    parsers.parse('the user adds or removes "{components}" using the Component List dialogue box')
)
def add_remove_component_using_component_list_modal(
    context,
    components,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
):
    context.component_list = components.split(",")

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(const.METHOD_NAME_PLACEHOLDER)

    # Add components
    data_driven_component_page.select_components_btn.click()
    data_driven_component_page.wait_for_component_loading_animation_to_end()
    data_driven_component_page.select_components(context.component_list)
    context.add_selected_component_text = (
        data_driven_component_page.selected_component_text.inner_text()
    )

    # Remove one component
    data_driven_component_page.select_components([context.component_list[-1]])
    context.remove_one_selected_component_text = (
        data_driven_component_page.selected_component_text.inner_text()
    )

    # Remove the remaining components
    data_driven_component_page.select_components(context.component_list[:-1])
    context.remove_all_selected_component_text = (
        data_driven_component_page.selected_component_text.inner_text()
    )


@when(
    parsers.parse('the user adds or removes "{measurements}" during Data Driven Methods creation')
)
def remove_measurement_during_data_driven_method_creation(
    context,
    measurements,
    generate_ph_level,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    data_driven_measurement_page: DataDrivenMeasurementPage,
):
    context.measurement_list = measurements.split(",")

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(const.METHOD_NAME_PLACEHOLDER)
    data_driven_component_page.set_ph_levels(generate_ph_level[0], generate_ph_level[1])
    data_driven_component_page.add_components([const.CREATE_DOSIM_SINGLE_COMPONENT])

    data_driven_component_page.create_method_with_validation()

    # Add measurements
    data_driven_measurement_page.select_measurements(context.measurement_list)
    context.add_selected_measurement_text = (
        data_driven_measurement_page.selected_measurement_text.inner_text()
    )

    # Remove one measurement
    data_driven_measurement_page.select_measurements([context.measurement_list[-1]])
    context.remove_one_selected_measurement_text = (
        data_driven_measurement_page.selected_measurement_text.inner_text()
    )

    # Remove the remaining measurements
    data_driven_measurement_page.select_measurements(context.measurement_list[:-1])
    context.remove_all_selected_measurement_text = (
        data_driven_measurement_page.selected_measurement_text.inner_text()
    )


@then("the method is successfully created for Single Components")
def check_method_creation_single(
    context,
    methods_page: MethodsPage,
    data_driven_details_page: DataDrivenDetailsPage,
):
    ph_level = f"{context.min_ph} – {context.max_ph}"
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Confirmation Popup Section
    expect(data_driven_details_page.popup_msg).to_have_text(const.DATA_DRIVEN_METHOD_POPUP_MSG)
    expect(data_driven_details_page.popup_title).to_have_text(const.DATA_DRIVEN_METHOD_POPUP_TITLE)

    # Validate Methods Details Page
    """ Validation Data Section """
    if "methods/overview" in methods_page.page.url:
        methods_page.wait_for_loading_animation_to_end_with_data()
        methods_page.refresh_page()
        methods_page.select_method_by_name(context.method_name)

        expect(data_driven_details_page.no_validation_text).to_have_text(
            const.DATA_DRIVEN_METHOD_NO_VALIDATION_TEXT
        )
    else:
        data_driven_details_page.refresh_page()
        data_driven_details_page.wait_for_data_driven_with_validation_details_to_load()

        expect(data_driven_details_page.prediction_error_graph).to_be_visible()
        expect(data_driven_details_page.residual_spectrum_graph).to_be_visible()

        measurement_list_txt = data_driven_details_page.get_measurement_text()
        legend_txt = data_driven_details_page.get_legend_text()
        measurement_dropdown_options = data_driven_details_page.get_measurement_dropdown_options()

        assert measurement_list_txt.count(context.measurement) == 1
        assert measurement_dropdown_options.count(context.measurement) == 1
        assert legend_txt.count(context.component) == 1

    """ MetaData Section """
    expect(data_driven_details_page.status_draft_label).to_be_visible()
    expect(data_driven_details_page.method_name_txt).to_contain_text(context.method_name)
    expect(data_driven_details_page.ph_range_txt).to_have_text(ph_level)
    expect(data_driven_details_page.method_creation_date_txt).to_contain_text(date_today)
    expect(data_driven_details_page.created_by_txt).to_have_text(context.name)
    expect(data_driven_details_page.data_driven_label).to_be_visible()

    """ Components Table Section """
    component_list_txt = data_driven_details_page.get_component_text()
    assert component_list_txt.count(context.component) == 1
    expect(data_driven_details_page.components_list_block).to_contain_text(context.min_conc)
    expect(data_driven_details_page.components_list_block).to_contain_text(context.max_conc)

    # Validate Methods List Page
    data_driven_details_page.return_to_methods_list()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()

    expect(methods_page.first_row_status_draft_label).to_be_visible()
    expect(methods_page.first_row_method_name_label).to_have_text(context.method_name)


@then("the method is successfully created for Multi Components")
def check_method_creation_multiple(
    context,
    methods_page: MethodsPage,
    data_driven_details_page: DataDrivenDetailsPage,
):
    ph_level = f"{context.min_ph} – {context.max_ph}"
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    # Confirmation Popup Section
    expect(data_driven_details_page.popup_msg).to_have_text(const.DATA_DRIVEN_METHOD_POPUP_MSG)
    expect(data_driven_details_page.popup_title).to_have_text(const.DATA_DRIVEN_METHOD_POPUP_TITLE)

    # Validate Methods Details Page
    """ Validation Data Section """
    if "methods/overview" in methods_page.page.url:
        methods_page.wait_for_loading_animation_to_end_with_data()
        methods_page.refresh_page()
        methods_page.select_method_by_name(context.method_name)

        expect(data_driven_details_page.no_validation_text).to_have_text(
            const.DATA_DRIVEN_METHOD_NO_VALIDATION_TEXT
        )
    else:
        data_driven_details_page.refresh_page()
        data_driven_details_page.wait_for_data_driven_with_validation_details_to_load()

        expect(data_driven_details_page.prediction_error_graph).to_be_visible()
        expect(data_driven_details_page.residual_spectrum_graph).to_be_visible()

        measurement_list_txt = data_driven_details_page.get_measurement_text()
        legend_list_txt = data_driven_details_page.get_legend_text()
        measurement_dropdown_options = data_driven_details_page.get_measurement_dropdown_options()

        for measurement in context.measurement_list:
            assert measurement_list_txt.count(measurement) == 1
            assert measurement_dropdown_options.count(measurement) == 1

        for component in context.component_list:
            if component == "NaCl":
                continue

            assert legend_list_txt.count(component) == 1

    """ MetaData Section """
    expect(data_driven_details_page.status_draft_label).to_be_visible()
    expect(data_driven_details_page.method_name_txt).to_contain_text(context.method_name)
    expect(data_driven_details_page.ph_range_txt).to_have_text(ph_level)
    expect(data_driven_details_page.method_creation_date_txt).to_contain_text(date_today)
    expect(data_driven_details_page.created_by_txt).to_have_text(context.name)
    expect(data_driven_details_page.data_driven_label).to_be_visible()

    """ Component Table Section """
    component_list_txt = data_driven_details_page.get_component_text()

    for component in context.component_list:
        if component == "NaCl":
            expect(data_driven_details_page.nacl_help_txt).to_be_visible()
            continue

        assert component_list_txt.count(component) == 1

    # Validate Methods List Page
    data_driven_details_page.return_to_methods_list()
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()

    expect(methods_page.first_row_status_draft_label).to_be_visible()
    expect(methods_page.first_row_method_name_label).to_have_text(context.method_name)


@then("the method is successfully created for Single Analyte")
def check_method_creation_single_analyte(
    context,
    methods_page: MethodsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
):
    date_today = date.today().strftime(const.EU_DATE_FORMAT)

    """ Confirmation Popup Section """
    expect(methods_page.popup_msg).to_have_text(const.REF_DRIVEN_METHOD_POPUP_MSG)
    expect(methods_page.popup_title).to_have_text(const.REF_DRIVEN_METHOD_POPUP_TITLE)

    # Validate Methods List Page
    methods_page.wait_for_first_entry_to_have("status", Status.DRAFT.value)
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()

    expect(methods_page.first_row_status_draft_label).to_be_visible()
    expect(methods_page.first_row_method_name_label).to_have_text(context.method_name)

    # Validate Methods Details Page
    methods_page.select_method_by_name(context.method_name)
    ref_driven_details_page.wait_for_ref_driven_to_load()

    """ MetaData Section """
    expect(ref_driven_details_page.status_draft_label).to_be_visible()
    expect(ref_driven_details_page.method_name_txt).to_contain_text(context.method_name)
    expect(ref_driven_details_page.method_creation_date_txt).to_contain_text(date_today)
    expect(ref_driven_details_page.created_by_txt).to_have_text(context.name)
    expect(ref_driven_details_page.ref_driven_label).to_be_visible()

    """ Help Text Section """
    expect(ref_driven_details_page.help_text_1).to_be_visible()
    expect(ref_driven_details_page.help_text_2).to_be_visible()
    expect(ref_driven_details_page.help_text_3).to_be_visible()

    """ Factors per Analyte Section """
    legend_list_txt = ref_driven_details_page.get_legend_text()

    for value in legend_list_txt:
        if context.analyte_name not in value:
            raise Exception(
                f'Legend entry "{value}" does not contain the string "{context.analyte_name}".'
            )

    expect(ref_driven_details_page.factors_per_analyte_chekbox).not_to_be_checked()
    expect(ref_driven_details_page.factor_slider).to_be_visible()

    """ Analyte Section """
    expect(ref_driven_details_page.cross_validation_error_graph).to_be_visible()
    expect(ref_driven_details_page.predicted_vs_measurement_graph).to_be_visible()


@then("all the components are removed from the list")
def all_components_removed(data_driven_component_page: DataDrivenComponentPage):
    # Components List Section
    expect(data_driven_component_page.components_list_table_data).not_to_be_visible()

    # Buttons Section
    expect(data_driven_component_page.continue_to_validation_btn).to_be_disabled()


@then("unusable icon and error popup is displayed to the user")
def unusable_component_ui(data_driven_component_page: DataDrivenComponentPage):
    # Error Popup Section
    expect(data_driven_component_page.popup_msg).to_have_text(const.REMOVE_UNUSABLE_COMP_POPUP_MSG)
    expect(data_driven_component_page.popup_title).to_have_text(
        const.REMOVE_UNUSABLE_COMP_POPUP_TITLE
    )

    # Components List Section
    tool_tip_first = data_driven_component_page.unusable_tool_tip.first.get_attribute(
        "nztooltiptitle"
    )
    tool_tip_last = data_driven_component_page.unusable_tool_tip.last.get_attribute(
        "nztooltiptitle"
    )

    assert tool_tip_first == const.REMOVE_UNUSABLE_COMP_TOOL_TIP
    assert tool_tip_last == const.REMOVE_UNUSABLE_COMP_TOOL_TIP

    expect(data_driven_component_page.unusable_icon.first).to_be_visible()
    expect(data_driven_component_page.unusable_icon.last).to_be_visible()


@then("all the unusable components are removed from the list")
def all_unusable_components_removed(context, data_driven_component_page: DataDrivenComponentPage):
    # Components List Section
    [
        expect(selected_comp_name).not_to_have_text(component)
        for component in context.removed_components
        for selected_comp_name in data_driven_component_page.selected_components_name_list.all()
    ]

    [
        expect(selected_comp_name).to_have_text(component)
        for component in context.retained_components
        for selected_comp_name in data_driven_component_page.selected_components_name_list.all()
    ]

    # Buttons Section
    expect(data_driven_component_page.create_btn).to_be_enabled()


@then("the label 'Selected components: x' is updated")
def check_component_label_is_updated(context):
    total_component_count = len(context.component_list)

    assert f"Selected components: {total_component_count}" == context.add_selected_component_text
    assert (
        f"Selected components: {total_component_count - 1}"
        == context.remove_one_selected_component_text
    )
    assert "Selected components: 0" == context.remove_all_selected_component_text


@then("the label 'Currently selected: x measurements' is updated")
def check_measurement_label_is_updated(context):
    total_component_count = len(context.measurement_list)

    assert f"Currently selected: {total_component_count}" in context.add_selected_measurement_text
    assert (
        f"Currently selected: {total_component_count - 1}"
        in context.remove_one_selected_measurement_text
    )
    assert "Currently selected: 0" in context.remove_all_selected_measurement_text


@then("New Method button is not displayed")
def check_new_method_button_not_displayed(methods_page: MethodsPage):
    expect(methods_page.new_method_btn).not_to_be_visible()


@then('the label "You need Measurements in order to create a Method." is displayed')
def check_display_no_measurement_uploaded(methods_page: MethodsPage):
    expect(methods_page.no_measurement_uploaded_label).to_be_visible()
    expect(methods_page.no_measurement_uploaded_label).to_have_text(
        const.METHODS_LIST_NO_MEASUREMENT_UPLOADED
    )
    expect(methods_page.no_measurement_uploaded_measurement_link).to_be_enabled()


@then("New Method button is disabled")
def check_new_method_button_disabled(methods_page: MethodsPage):
    expect(methods_page.new_method_btn).to_be_disabled()
