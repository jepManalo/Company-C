from pytest_bdd import parsers, scenarios, when
from sttable import parse_str_table

import src.api_utility.utils as utility
import src.constants as const

scenarios(
    const.ROOT_PROJECT_DIR / "src/test/features/datatest/qascan_consistency.feature",
)


@when(parsers.parse("the user prepares Step 2 - Analytical Attributes input:\n{table_with_header}"))
def create_qascan_step_2(context, table_with_header):
    context.step2_datatable = parse_str_table(table_with_header)


@when(
    parsers.parse("the user prepares Step 3-1 - Components Selection input:\n{table_with_header}")
)
def create_qascan_step_3_1(context, table_with_header):
    context.step3_1_datatable = parse_str_table(table_with_header)


@when(parsers.parse("the user prepares Step 3-2 - Formulation input:\n{table_with_header}"))
def create_qascan_step_3_2(context, table_with_header):
    context.step3_2_datatable = parse_str_table(table_with_header)


@when(parsers.parse("the user prepares Step 3-3 - Buffer input:\n{table_with_header}"))
def create_qascan_step_3_3(context, table_with_header):
    context.step3_3_datatable = parse_str_table(table_with_header)


@when(parsers.parse("the user prepares Step 3-4-1 - Reference Values input:\n{table_with_header}"))
def create_qascan_step_3_4_1(context, table_with_header):
    context.step3_4_1_datatable = parse_str_table(table_with_header)


@when("the user makes the QA SCAN method available")
def make_qascan_available(context):
    if context.method_status == const.Status.AVAILABLE.value:
        return

    # Make the QA Scan method available
    utility.make_method_available(
        context=context,
        method_type=const.MethodType.QASCAN,
        method_id=context.method_id,
    )


@when("the user creates QA Scan method")
def check_qascan(context, nonce):
    suffix = f"{context.testdata}-QAScan-Consistency-Test"

    if utility.reuse_existing_qascan_method_if_any(context, search_name=suffix):
        return

    context.method_name = f"{nonce}-{suffix}"
    context.org_id = utility.get_org_id(context.client, context.url, context.org)
    context.proj_id = utility.get_project_id(
        context.client, context.url, context.org_id, context.project
    )

    utility.create_initial_qascan_method(context)
    utility.set_analytical_attributes(context)
    utility.select_components(context)
    utility.calibrate_formulation(context)
    utility.calibrate_buffer(context)
    utility.set_reference_values(context)
    utility.complete_review_page(context)
