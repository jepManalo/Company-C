from pytest_bdd import given, parsers, scenarios, then, when
from sttable import parse_str_table

import src.api_utility.api_deserializer as deserializer
import src.api_utility.utils as utility
import src.constants as const
from src.utility import extract_dosim_suffix

scenarios(
    const.ROOT_PROJECT_DIR / "src/test/features/datatest/dosim_consistency.feature",
    const.ROOT_PROJECT_DIR / "src/test/features/datatest/dosim_persistency.feature",
)


@given(parsers.parse('the measurement from "{measurement}" is uploaded to the Project'))
def upload_measurement(context, measurement):
    context.measurement_name = measurement.replace(".json", "")

    utility.upload_json_measurements_if_missing(
        context=context,
        search_names=[context.measurement_name],
        file_path=const.API_DOSIM_TESTDATA_PATH,
        json_file_names=[measurement],
    )


@when(
    parsers.parse(
        'the user creates a Data Driven Method with pH values "{min_ph}", "{max_ph}" '
        "using the following components:\n{table_with_header}"
    )
)
def create_data_driven_single_component(
    context,
    min_ph,
    max_ph,
    table_with_header,
    nonce,
):
    # Prepare the method_name and search_name
    method_name, suffix = extract_dosim_suffix(context=context, nonce=nonce)
    context.method_name = method_name

    # Prepare the gherkin table
    component_list = utility.create_component_payload(
        context=context, datatable=parse_str_table(table_with_header)
    )

    # Let us check first if there is an existing Method for Consistency Test
    method_result = utility.check_existing_dosim_methods(
        context=context, search_name=suffix, component_list=component_list
    )

    # If there are existing method, do not create a new one
    if method_result:
        print(f"Existing method found! Name: {method_result.name}")

        context.method_id = method_result.id
        context.method_status = method_result.status

        # Override the context.method_name{x} with the existing method
        context.method_name = method_result.name

        return

    # If there are no method retrieved, create a new one
    # Parse table and construct component list with float concentrations
    created_method = utility.create_dosim_method(
        context=context,
        method_name=context.method_name,
        min_ph=float(min_ph),
        max_ph=float(max_ph),
        component_list=component_list,
    )

    # Get method_id for pre-requisite to execute make available API
    context.method_id = created_method.id
    context.method_status = created_method.status


@when(
    parsers.parse(
        'the user creates Data Driven Method "{method_count}" '
        'with pH values "{min_ph}", "{max_ph}" '
        "using the following input data via API:\n{table_with_header}"
    )
)
def create_data_driven_two_times(
    context,
    method_count,
    min_ph,
    max_ph,
    table_with_header,
    nonce,
):
    # Prepare the method_name and search_name
    method_name, search_name = extract_dosim_suffix(
        context=context, nonce=nonce, method_count=method_count
    )
    setattr(context, f"method_name{method_count}", method_name)

    # Prepare the gherkin table data set
    component_list = utility.create_component_payload(
        context=context, datatable=parse_str_table(table_with_header)
    )

    # Let us check first if there is an existing Method for Consistency Test
    method_result = utility.check_existing_dosim_methods(
        context=context, search_name=search_name, component_list=component_list
    )

    # If there is an existing method, do not create a new one
    if method_result:
        setattr(context, f"method_id{method_count}", method_result.id)
        setattr(context, f"method_status{method_count}", method_result.status)

        # Override the context.method_name{x} with the existing method
        setattr(context, f"method_name{method_count}", method_result.name)

        print(f"Existing method found! Name: {method_result.name}")

        return

    # If there are no method, create a new one
    created_method = utility.create_dosim_method(
        context=context,
        method_name=method_name,
        component_list=component_list,
        min_ph=float(min_ph),
        max_ph=float(max_ph),
    )

    setattr(context, f"method_id{method_count}", created_method.id)
    setattr(context, f"method_status{method_count}", created_method.status)


@when("the user makes the DOSIM method available")
def make_dosim_available(context):
    if context.method_status == const.Status.AVAILABLE.value:
        return

    utility.make_method_available(
        context=context,
        method_type=const.MethodType.DOSIM,
        method_id=context.method_id,
    )


@when("the user makes all the DOSIM methods available")
def make_dosims_available(context):
    # Let us first check how many "method_name" substring are there in context
    method_name_attrs = [attr for attr in dir(context) if "method_name" in attr]
    method_name_count = len(method_name_attrs)

    # If all the existing methods have available status, we skip this 'when' statement
    all_available = all(
        getattr(context, f"method_status{x}") == const.Status.AVAILABLE.value
        for x in range(1, method_name_count + 1)
    )

    if all_available:
        return

    for x in range(1, method_name_count + 1):
        method_status = getattr(context, f"method_status{x}")
        method_id = getattr(context, f"method_id{x}")

        if method_status == const.Status.AVAILABLE.value:
            continue

        utility.make_method_available(
            context=context, method_type=const.MethodType.DOSIM, method_id=method_id, index=x
        )


@when(parsers.parse('the user runs "{count}" evaluations using the created method'))
def create_dosim_evaluation(context, count):
    context.list_actual_api_result = []
    measurement_endpoint = f"analytics/api/v2/measurements/{context.proj_id}/"

    # We need to get first the measurement id to be used in the evaluation
    context.measurement_id = utility.get_measurement_id(
        context.client,
        base_url=context.url,
        endpoint=measurement_endpoint,
        params_payload={"name": context.measurement_name},
    )

    for x in range(1, int(count) + 1):
        # We create evaluations
        list_evaluation_ids = utility.create_and_poll_evaluation(
            context=context,
            method_id=context.method_id,
            measurement_id=[context.measurement_id],
            evaluation_name=context.method_name,
            parser=deserializer.map_to_dataclass_create_dosim_eval,
            index=x,
        )

        context.list_actual_api_result.append(
            utility.get_dosim_concentration_values(
                context=context,
                list_evaluation_ids=list_evaluation_ids,
            )
        )

    print("DOSIM Evaluation concentration value extraction from the API response is successful!")


@when(
    parsers.parse(
        'the user creates "{count1}" evaluations using Method "{method_count1}", '
        'with "{count2}" evaluations executed between using Method "{method_count2}"'
    )
)
def create_dosim_evaluation_with_pause(context, count1, count2):
    context.list_actual_api_result = []
    measurement_endpoint = f"analytics/api/v2/measurements/{context.proj_id}/"

    # We need to get first the measurement id to be used in the evaluation
    context.measurement_id = utility.get_measurement_id(
        context.client,
        base_url=context.url,
        endpoint=measurement_endpoint,
        params_payload={"name": context.measurement_name},
    )

    for x in range(1, int(count1) + 1):
        # We create evaluations
        list_evaluation_ids = utility.create_and_poll_evaluation(
            context=context,
            method_id=context.method_id1,
            measurement_id=[context.measurement_id],
            evaluation_name=context.method_name1,
            parser=deserializer.map_to_dataclass_create_dosim_eval,
            index=x,
        )

        context.list_actual_api_result.append(
            utility.get_dosim_concentration_values(
                context=context,
                list_evaluation_ids=list_evaluation_ids,
            )
        )

        # Check if we are halfway and create evaluations using method 2
        if x == int(count1) // 2:
            for y in range(1, int(count2) + 1):
                # We create evaluations using method 2
                # NOTE: We do not put the evaluations in context.list_actual_api_result because
                # we are only concerned with persistency on the evaluation of the 1st method
                utility.create_and_poll_evaluation(
                    context=context,
                    method_id=context.method_id2,
                    measurement_id=[context.measurement_id],
                    evaluation_name=context.method_name2,
                    parser=deserializer.map_to_dataclass_create_dosim_eval,
                    index=f"{x}.{y}",
                )

    print("DOSIM Evaluation concentration value extraction from the API response is successful!")


@then("the concentration results must be identical across all evaluations")
def abc(context):
    # Compare all the evaluations we have in list_actual_api_result
    # There should be no difference in the concentration values
    baseline = context.list_actual_api_result[0]

    mismatches = [
        (ind, api_result)
        for ind, api_result in enumerate(context.list_actual_api_result)
        if api_result != baseline
    ]

    if mismatches:
        print("Mismatched Evaluation found: ")
        for ind, val in mismatches:
            print(f"Evaluation {ind}: {val} != {baseline}")
    else:
        print("All evaluations matched the baseline.")
