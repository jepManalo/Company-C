from playwright.sync_api import Page

import src.constants as const
from src.pom.base_page import BasePage
from src.utility import MethodType, Status


class DataDrivenDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)

        # Metadata texts
        self.method_name_txt = page.locator("(//table//tr[2]//td[1]//span)[1]")
        self.method_type_txt = page.locator("//table//tr[2]//td[2]//span")
        self.ph_range_txt = page.locator("//table//tr[2]//td[3]//span")
        self.method_creation_date_txt = page.locator(
            "//table//tr[2]//td[4]//span[@class='ant-descriptions-item-content']"
        )
        self.created_by_txt = page.locator(
            "//table//tr[2]//td[5]//span[@class='ant-descriptions-item-content']"
        )
        self.status_draft_label = page.get_by_text(Status.DRAFT.value)
        self.data_driven_label = page.get_by_text(MethodType.DATA_DRIVEN.value, exact=True)

        # Selected Components Section
        self.list_of_components = (
            page.locator('[name="center"]').get_by_role("rowgroup").nth(0).get_by_role("row")
        )
        self.list_of_measurements = (
            page.locator('[name="center"]').get_by_role("rowgroup").nth(1).get_by_role("row")
        )
        self.components_list_block = page.locator('[name="center"]').get_by_role("rowgroup").nth(0)
        self.measurements_list_block = (
            page.locator('[name="center"]').get_by_role("rowgroup").nth(1)
        )
        self.nacl_help_txt = page.get_by_text(const.NACL_TEXT)

        # Validation Data Section
        self.measurement_dropdown = page.locator('[id="selectMeasurement"]')
        self.prediction_error_graph_legend = page.locator('[class="legendtext"]')
        self.list_of_measurement_from_measurement_dropdown = page.locator("nz-option-item")
        self.residual_spectrum_graph = page.locator("plotly-plot").nth(0)
        self.prediction_error_graph = page.locator("plotly-plot").nth(1)
        self.no_validation_text = page.get_by_text("Validation Data").locator("p")

    def wait_for_data_driven_with_validation_details_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector("plotly-plot", state="visible")

    def wait_for_data_driven_details_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        try:
            self.page.wait_for_selector("plotly-plot", state="visible")
        except Exception:
            self.page.wait_for_selector(
                f"//*[text()={const.DATA_DRIVEN_METHOD_NO_VALIDATION_TEXT}]",
                state="visible",
                timeout=const.FAST_WAIT,
            )

    def get_method_status(self):
        return self.method_name_txt.inner_text().split("\n")[-1]

    def get_legend_text(self):
        return [gl.text_content() for gl in self.prediction_error_graph_legend.all()]

    def return_to_methods_list(self):
        self.wait_for_url_to_have("methods/dosim/edit")
        self.back_btn.click()
        self.wait_for_loading_animation_to_end_unknown_data()

    def get_component_text(self):
        return [
            gl.text_content()
            for gl in self.list_of_components.locator('[col-id="component.name"]').all()
        ]

    def get_measurement_text(self):
        return [
            gl.text_content()
            for gl in self.list_of_measurements.locator('[col-id="measurementName"]').all()
        ]

    def get_measurement_dropdown_options(self):
        self.measurement_dropdown.click()

        return [
            gl.text_content().strip()
            for gl in self.list_of_measurement_from_measurement_dropdown.all()
        ]

    def get_delete_btn(self):
        return self.delete_btn.is_disabled()

    def get_archive_btn(self):
        return self.archive_btn.is_disabled()

    def get_unarchive_btn(self):
        return self.unarchive_btn.is_disabled()

    def get_export_btn(self):
        return self.export_btn.is_disabled()
