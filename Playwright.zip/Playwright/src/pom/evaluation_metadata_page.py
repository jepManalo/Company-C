from playwright.sync_api import Page

from src.pom.base_page import BasePage


class EvaluationMetadataPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.evaluation_name_txt_field = page.locator('[formcontrolname="evaluationName"]')
        self.create_btn = page.get_by_role("button", name="Create")

    def finalize_evaluation_creation(self, evaluation_name: str):
        self.evaluation_name_txt_field.fill(evaluation_name)
        self.create_btn.click()
        self.wait_for_loading_animation_to_end_with_data()
