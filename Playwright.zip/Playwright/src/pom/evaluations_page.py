from playwright.sync_api import Page

from src.pom.base_page import BasePage
from src.utility import MethodType

"""
Page object for both active evaluations list and
archived evaluations list pages
"""


class EvaluationsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.new_evaluation_btn = page.get_by_role("button", name="New Evaluation")
        self.evaluation_list = page.locator('[data-ref="eContainer"]').get_by_role("row")
        self.action_delete_btn = page.locator('[data-test="delete"]')
        self.action_archive_btn = page.locator('[data-test="container"]')
        self.delete_modal_ok_btn = page.get_by_role("button", name="OK")
        self.method_type_dropdown = page.locator('[nzplaceholder="Method-Type"]')
        self.types_ref_driven_opt = page.locator(f'[title="{MethodType.REF_DRIVEN.value}"]')
        self.types_data_driven_opt = page.locator(f'[title="{MethodType.DATA_DRIVEN.value}"]')
        self.archived_evaluations_tab = page.locator('[routerlinkactive="active"]').get_by_text(
            "Archived Evaluations"
        )
        self.active_evaluations_tab = page.locator('[routerlinkactive="active"]').get_by_text(
            "Active Evaluations"
        )

    def filter_method_types_dropdown(self, method_type: str):
        self.method_type_dropdown.click()

        if method_type == MethodType.DATA_DRIVEN.value:
            self.types_data_driven_opt.click()
        elif method_type == MethodType.REF_DRIVEN.value:
            self.types_ref_driven_opt.click()
        else:
            raise NotImplementedError

    def delete_evaluation(self, evaluation_name: str):
        child = self.page.get_by_text(evaluation_name, exact=True)
        self.page.locator('[data-ref="eBodyViewport"]').locator('[role="row"]').filter(
            has=child
        ).locator('[data-test="delete"]').click()
        self.delete_modal_ok_btn.click()
        self.wait_for_loading_animation_to_end_with_data()

    def archive_evaluation(self, evaluation_name: str):
        child = self.page.get_by_text(evaluation_name, exact=True)
        self.page.locator('[data-ref="eBodyViewport"]').locator('[role="row"]').filter(
            has=child
        ).locator('[data-test="container"]').click()
        self.wait_for_loading_animation_to_end_with_data()

    def select_evaluation_by_name(self, evaluation_name: str):
        self.page.get_by_text(evaluation_name).click()

    def go_to_archived_tab(self):
        self.archived_evaluations_tab.click()
        self.wait_for_loading_animation_to_end_unknown_data()

    def go_to_active_tab(self):
        self.active_evaluations_tab.click()
        self.wait_for_loading_animation_to_end_unknown_data()
