from playwright.sync_api import Page

from src.pom.base_page import BasePage
from src.utility import SORT_ORDER_CLICK_MAP, MethodType, Status

"""
Page object for both active methods list and
archived methods list pages
"""


class MethodsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.method_name_txt_field = page.get_by_placeholder("Name")
        self.methods_list = page.locator('[data-ref="eContainer"]').get_by_role("row")
        self.evaluations_icon_locator = page.locator('[data-icon="evaluation_sphere"]')

        # Dropdowns & Selections
        self.types_dropdown = page.locator('[name="type"]')
        self.types_ref_driven_opt = page.locator(f'[title="{MethodType.REF_DRIVEN.value}"]')
        self.types_data_driven_opt = page.locator(f'[title="{MethodType.DATA_DRIVEN.value}"]')
        self.status_dropdown = page.locator('[name="status"]')
        self.status_draft_opt = page.locator(f'[title="{Status.DRAFT.value}"]')
        self.status_available_opt = page.locator(f'[title="{Status.AVAILABLE.value}"]')
        self.status_failed_opt = page.locator(f'[title="{Status.FAILED.value}"]')
        self.status_pending_opt = page.locator(f'[title="{Status.PENDING.value}"]')
        self.status_creating_opt = page.locator(f'[title="{Status.CREATING.value}"]')
        self.status_validating_opt = page.locator(f'[title="{Status.VALIDATING.value}"]')

        # Left Navigation Bar
        self.measurements_icon_locator = page.locator('[data-icon="measurement"]')

        # Tabs
        self.active_tab = page.locator('[routerlinkactive="active"]').get_by_text("Active Methods")
        self.archived_tab = page.locator('[routerlinkactive="active"]').get_by_text(
            "Archived Methods"
        )

        # Labels
        self.first_row_status_draft_label = page.get_by_text(Status.DRAFT.value).nth(0)
        self.first_row_status_validating_label = page.get_by_text(Status.VALIDATING.value).nth(0)
        self.no_measurement_uploaded_label = page.locator('[class="warning-text ng-star-inserted"]')
        self.first_row_method_name_label = (
            page.locator('[data-ref="eContainer"]').get_by_role("row").locator("[col-id='name']")
        )

        # Buttons
        self.next_page_btn = page.get_by_role("button", name="Next Page")
        self.new_method_btn = page.get_by_role("button", name="New Method")
        self.action_delete_btn = page.locator('[data-test="delete"]')
        self.dropdown_close_btn = page.locator('[nztype="close-circle"]').nth(0)
        self.action_export_btn = page.locator('[data-test="export-button"]')
        self.delete_modal_ok_btn = page.get_by_role("button", name="OK")
        self.archive_btn_list = (
            page.locator('[data-ref="eContainer"]')
            .get_by_role("row")
            .locator('[col-id="actions"]')
            .locator('[data-test="container"]')
        )
        self.unarchive_btn_list = (
            page.locator('[data-ref="eContainer"]')
            .get_by_role("row")
            .locator('[col-id="actions"]')
            .locator('[data-test="unarchive"]')
        )

        # Date picker elements
        self.date_dropdown = page.locator("nz-range-picker")
        self.date_today = page.get_by_text("today")
        self.date_month = page.get_by_text("this month")
        self.date_start = page.get_by_placeholder("start date")
        self.date_end = page.get_by_placeholder("end date")

        # Table Headers
        self.method_name_header = page.get_by_role("columnheader", name="Method", exact=True)
        self.method_status_header = page.get_by_role("columnheader", name="Status", exact=True)

        # Links
        self.no_measurement_uploaded_measurement_link = page.locator(
            '//a[contains(@href, "measurements")]'
        )

        # Tool tip
        self.action_delete_btn_tool_tip = page.locator(".ant-tooltip-inner")

    def filter_method_name(self, method: str):
        self.method_name_txt_field.clear()
        self.wait_for_loading_animation_to_end_with_data()
        self.method_name_txt_field.fill(method)

    def get_method_list(self):
        return self.methods_list.all()

    def get_total_list_pages(self):
        return int(self.page.locator('[data-ref="lbTotal"]').inner_text())

    def get_method_list_property(self, prop: str):
        list_prop_value = []
        current_list = self.get_method_list()

        list_label = self.get_label_of_list_using_col_id_property(current_list, prop)
        list_prop_value.extend(list_label)

        while self.next_page_btn.is_enabled():
            self.click_next_page_and_wait_with_data()
            current_list = self.get_method_list()
            list_label = self.get_label_of_list_using_col_id_property(current_list, prop)

            list_prop_value.extend(list_label)

        return list_prop_value

    def get_label_of_list_using_col_id_property(self, current_list, property):
        list_value = []
        for element in current_list:
            value = element.locator(f'[col-id="{property}"]').inner_text()
            list_value.append(value)

        return list_value

    def filter_date(self, start, end):
        self.date_dropdown.click()

        if start == "today":
            self.date_today.click()
        elif start == "month":
            self.date_month.click()
        else:
            self.date_start.fill(start)
            self.date_end.fill(end)
            self.date_end.press("Tab")

    def sort_by_column(self, column: str, order: str):
        if column == "name":
            header = self.method_name_header
        elif column == "status":
            header = self.method_status_header
        for _ in range(SORT_ORDER_CLICK_MAP[order]):
            header.click()

    def filter_types_dropdown(self, method_type: str):
        self.types_dropdown.click()

        if method_type == MethodType.DATA_DRIVEN.value:
            self.types_data_driven_opt.click()
        elif method_type == MethodType.REF_DRIVEN.value:
            self.types_ref_driven_opt.click()
        else:
            raise NotImplementedError

    def filter_status_dropdown(self, method_status: str):
        self.status_dropdown.click()

        if method_status == Status.DRAFT.value:
            self.status_draft_opt.click()
        elif method_status == Status.AVAILABLE.value:
            self.status_available_opt.click()
        elif method_status == Status.FAILED.value:
            self.status_failed_opt.click()
        elif method_status == Status.PENDING.value:
            self.status_pending_opt.click()
        elif method_status == Status.CREATING.value:
            self.status_creating_opt.click()
        elif method_status == Status.VALIDATING.value:
            self.status_validating_opt.click()

    def click_next_page_btn(self):
        self.next_page_btn.click()
        self.wait_for_api_request_to_end()

    def click_next_page_and_wait_with_data(self):
        self.click_next_page_btn()
        self.wait_for_page_to_load()
        self.wait_for_loading_animation_to_end_with_data()

    def click_new_method_btn(self):
        self.new_method_btn.click()
        self.wait_for_api_request_to_end()

    def select_method_by_name(self, method_name: str):
        self.page.get_by_text(method_name).click()

    def delete_methods_matching_string(self, method_name: str):
        filtered_methods = self.methods_list.filter(has_text=method_name).all()

        if not filtered_methods:
            raise Exception(
                f"There is no method to delete. Check method name: {method_name} filter."
            )

        for _ in filtered_methods:
            self.action_delete_btn.first.click()
            self.delete_modal_ok_btn.click()
            self.wait_for_loading_animation_to_end_unknown_data()

    def go_to_archived_tab(self):
        self.archived_tab.click()
        self.wait_for_loading_animation_to_end_unknown_data()

    def go_to_active_tab(self):
        self.active_tab.click()
        self.wait_for_loading_animation_to_end_unknown_data()

    def go_to_measurements_page(self):
        self.measurements_icon_locator.click()
        self.wait_for_url_to_have("measurements/overview")
        self.wait_for_loading_animation_to_end_unknown_data()

    def clear_all_filter(self):
        self.method_name_txt_field.clear()
        self.wait_for_loading_animation_to_end_with_data()
        self.types_dropdown.hover()
        self.dropdown_close_btn.click()
        self.wait_for_loading_animation_to_end_with_data()
        self.status_dropdown.hover()
        self.dropdown_close_btn.click()
        self.wait_for_loading_animation_to_end_with_data()

    def go_to_evaluations_page(self):
        self.evaluations_icon_locator.click()
        self.wait_for_url_to_have("evaluations/overview")
        self.wait_for_loading_animation_to_end_unknown_data()
