from playwright.sync_api import Page

from src.pom.base_page import BasePage


class OverviewPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.project_drop_down = self.page.locator("id=projectSelector")
        self.org_drop_down = self.page.locator("id=organizationSelector")

    def select_project(self, project: str):
        self.project_drop_down.click()
        self.page.locator("ul").get_by_text(project).click()
        self.page.wait_for_timeout(1000)

    def select_org(self, org: str):
        self.org_drop_down.click()
        self.page.locator("ul").get_by_text(org).click()
        self.page.wait_for_timeout(1000)
