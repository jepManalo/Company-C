from playwright.sync_api import Page

from src.pom.base_page import BasePage

"""
Page object for both active measurements list and
archived measurements list pages
"""


class MeasurementsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.methods_icon_locator = self.page.locator('[data-icon="method"]')
        self.evaluations_icon_locator = self.page.locator('[data-icon="evaluation_sphere"]')
        self.archive_btn = self.page.locator("data-test=container")

    def go_to_evaluations_page(self):
        self.evaluations_icon_locator.click()
        self.wait_for_url_to_have("evaluations/overview")
        self.wait_for_loading_animation_to_end_unknown_data()
