from playwright.sync_api import Page

from src.pom.base_page import BasePage

"""
Page object for both data driven evaluations details and
reference driven evaluations details pages
"""


class EvaluationsDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.archive_btn = page.get_by_role("button", name="Archive", exact=True)
        self.unarchive_btn = page.get_by_role("button", name="Unarchive", exact=True)
        self.delete_btn = page.get_by_role("button", name="Delete", exact=True)

    def delete_evaluation(self):
        self.delete_btn.click()
        self.confirm_deletion_btn.click()
        self.wait_for_loading_animation_to_end_with_data()
