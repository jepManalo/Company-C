from playwright.sync_api import Page

from src.pom.base_page import BasePage


class PassphrasePage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.unlock_btn = self.page.get_by_role("button", name="Unlock")
        self.catch_phrase_txt_field = self.page.get_by_placeholder("Enter the passphrase")
        self.create_key_txt_field = self.page.get_by_placeholder("Enter a passphrase")
        self.create_key_confirm_txt_field = self.page.get_by_placeholder("Confirm the passphrase")
        self.create_btn = self.page.get_by_role("button", name="Create")

    def unlock(self, passphrase: str):
        self.catch_phrase_txt_field.fill(passphrase)
        self.unlock_btn.click()
        self.wait_for_api_request_to_end()

    def create_key(self, passphrase: str):
        self.create_key_txt_field.fill(passphrase)
        self.create_key_confirm_txt_field.fill(passphrase)
        self.create_btn.click()
        self.wait_for_api_request_to_end()
