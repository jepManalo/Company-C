from playwright.sync_api import Page

from src.pom.base_page import BasePage


class MeasurementDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.measurement_name_txt = page.locator("//table//tr[2]//td[1]//span")

    def get_measurement_name(self):
        return self.measurement_name_txt.inner_text()
