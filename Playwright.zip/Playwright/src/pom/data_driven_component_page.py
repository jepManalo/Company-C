from playwright.sync_api import Page

import src.constants as const
from src.pom.base_page import BasePage


class DataDrivenComponentPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)

        # Text fields
        self.min_ph_txt_field = page.locator('[name="minPh"]')
        self.max_ph_txt_field = page.locator('[name="maxPh"]')

        # Buttons
        self.select_components_btn = page.get_by_role("button", name="Select Components")
        self.create_btn = page.get_by_role("button", name="Create")
        self.continue_to_validation_btn = page.get_by_role("button", name="Continue to Validation")
        self.remove_all_btn = page.get_by_role("button", name="Remove All")
        self.remove_unusable_components_btn = page.get_by_role(
            "button", name="Remove unusable Components"
        )

        # Checkbox
        self.skip_validation_chekbox = page.get_by_label("Skip validation")

        # Component List Popup
        self.component_name_txt_field = page.locator('[name="searchName"]')
        self.component_done_btn = page.get_by_role("button", name="Done")
        self.component_list_label = page.get_by_text("Component List")
        self.iupac_label_header = page.get_by_text("IUPAC name")
        self.selected_component_text = page.get_by_text("Selected components")
        self.components_list_table_data = page.get_by_role("document").get_by_role("gridcell")

        # Unusable Components elements
        self.unusable_icon = (
            page.get_by_role("gridcell")
            .and_(page.locator('[col-id="unusable"]'))
            .locator("[nz-icon]")
        )
        self.unusable_tool_tip = (
            page.get_by_role("gridcell")
            .and_(page.locator('[col-id="unusable"]'))
            .locator("[nz-tooltip]")
        )

        # Selected Components Table
        self.selected_components_name_list = (
            page.locator('[role="presentation"]')
            .and_(page.locator('[role="center"]'))
            .locator('[col-id="name"]')
        )

    def set_ph_levels(self, min_ph, max_ph):
        self.min_ph_txt_field.fill(min_ph)
        self.max_ph_txt_field.fill(max_ph)

    def create_method_with_validation(self):
        self.continue_to_validation_btn.click()
        self.wait_for_page_to_load()
        self.wait_for_loading_animation_to_end_with_data()

    def create_method_without_validation(self):
        self.skip_validation_chekbox.click()
        self.create_btn.click()
        self.wait_for_url_to_not_have("create")
        self.wait_for_page_to_load()
        self.wait_for_loading_animation_to_end_with_data()

    def select_components(self, components: list):
        for component in components:
            self.component_name_txt_field.fill(component)

            # Since we do not have a Search button,
            # outside clicks ensures that search feature is triggered.
            self.component_list_label.click()

            self.wait_for_page_to_load()
            self.wait_for_component_loading_animation_to_end()
            self.page.get_by_text(component, exact=True).click()
            self.page.wait_for_timeout(1000)

    def add_components(self, components: list):
        self.select_components_btn.click()
        self.wait_for_page_to_load()
        self.wait_for_component_loading_animation_to_end()
        self.select_components(components)
        self.component_done_btn.click()

    def update_concentration(self, component_name: str, min_conc: str, max_conc: str):
        component_row = self.page.get_by_role("row").filter(
            has=self.page.get_by_text(component_name)
        )
        component_min_concentration_txt_field = component_row.locator(
            '[col-id="min_concentration"]'
        )
        component_max_concentration_txt_field = component_row.locator(
            '[col-id="max_concentration"]'
        )

        component_min_concentration_txt_field.click()
        self.page.keyboard.type(min_conc)

        # We need outside click so that min concentration can be saved
        self.iupac_label_header.click()

        component_max_concentration_txt_field.click()
        self.page.keyboard.type(max_conc)

        # We need outside click so that max concentration can be saved
        self.iupac_label_header.click()

    def wait_for_component_loading_animation_to_end(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector("[class=ag-loading]", state="hidden")
        try:
            self.components_list_table_data.first.wait_for(state="visible", timeout=const.MID_WAIT)
        except Exception:
            raise Exception("There are no Components Displayed in Component List Modal.")

    def clear_components_list(self):
        self.clear_datatable_btn.click()
