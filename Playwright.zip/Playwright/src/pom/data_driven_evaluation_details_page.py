from typing import Tuple

from playwright.sync_api import Locator, Page

from src.pom.base_page import BasePage
from src.utility import MethodType, Status


class DataDrivenEvaluationDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.residual_spectrum_graph = page.locator("plotly-plot").nth(0)
        self.components_list_block = page.locator('[name="center"]').get_by_role("rowgroup")
        self.list_of_components = self.components_list_block.get_by_role("row")
        self.status_finished_label = page.get_by_text(Status.FINISHED.value)
        self.data_driven_label = page.get_by_text(MethodType.DATA_DRIVEN.value, exact=True)

    def get_component_text(self):
        return [
            gl.text_content() for gl in self.list_of_components.locator('[col-id="name"]').all()
        ]

    def get_unit_text(self):
        return [
            gl.text_content() for gl in self.list_of_components.locator('[col-id="unit"]').all()
        ]

    def wait_for_details_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector("plotly-plot", state="visible")

    def extract_comp_concentration_values(self, row: Locator) -> Tuple[str, str]:
        comp_name = row.locator('[col-id="name"]').inner_text()
        comp_conc = row.locator('[col-id="value"]').inner_text()

        return comp_name, comp_conc
