from playwright.sync_api import Page

from src.pom.base_page import BasePage


class LandingPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.email_txt_field = self.page.locator('[data-test="form-field-email"]').get_by_role(
            "textbox"
        )
        self.password_txt_field = self.page.locator(
            '[data-test="form-field-password"]'
        ).get_by_role("textbox")
        self.sign_in_btn = self.page.locator('button[name="sign-in"]')

    def login(self, username: str, password: str):
        self.email_txt_field.fill(username)
        self.password_txt_field.fill(password)
        self.sign_in_btn.click()
