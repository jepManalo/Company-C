from playwright.sync_api import Page

from src.pom.base_page import BasePage


class CreateMethodPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.data_driven_opt = page.get_by_role("radio").nth(1)
        self.ref_driven_opt = page.get_by_role("radio").nth(0)
        self.method_name_txt_field = page.get_by_role("textbox")
        self.next_btn = page.get_by_role("button", name="Next")

    def initialize_data_driven_creation(self, method_name):
        self.method_name_txt_field.fill(method_name)
        self.data_driven_opt.click()
        self.next_btn.click()
        self.wait_for_api_request_to_end()

    def initialize_ref_driven_creation(self, method_name):
        self.method_name_txt_field.fill(method_name)
        self.ref_driven_opt.click()
        self.next_btn.click()
        self.wait_for_api_request_to_end()
