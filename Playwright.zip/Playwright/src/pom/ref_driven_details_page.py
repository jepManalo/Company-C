from playwright.sync_api import Page

import src.constants as const
from src.pom.base_page import BasePage
from src.utility import MethodType, Status


class ReferenceDrivenDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)

        # Reference Driven Details
        self.cross_validation_error_graph = page.locator(
            '[class="draglayer cursor-crosshair"]'
        ).locator('[class="xy"]')
        self.predicted_vs_measurement_graph = page.locator(
            '[class="draglayer cursor-crosshair"]'
        ).locator('[class="x2y2"]')
        self.factors_per_analyte_chekbox = page.get_by_label("Adjust Factors per Analyte")
        self.factor_slider = page.locator(".small-form-container")
        self.graph_legend = page.locator('[class="legendtext"]')

        # Metadata texts
        self.method_name_txt = page.locator("(//table//tr[2]//td[1]//span)[1]")
        self.method_type_txt = page.locator("//table//tr[2]//td[2]//span")
        self.method_creation_date_txt = page.locator(
            "//table//tr[2]//td[3]//span[@class='ant-descriptions-item-content']"
        )
        self.created_by_txt = page.locator(
            "//table//tr[2]//td[4]//span[@class='ant-descriptions-item-content']"
        )
        self.status_draft_label = page.get_by_text(Status.DRAFT.value)
        self.ref_driven_label = page.get_by_text(MethodType.REF_DRIVEN.value, exact=True)

        # Help texts
        self.help_text_1 = page.get_by_text(const.REF_DRIVEN_HELP_TEXT_1)
        self.help_text_2 = page.get_by_text(const.REF_DRIVEN_HELP_TEXT_2)
        self.help_text_3 = page.get_by_text(const.REF_DRIVEN_HELP_TEXT_3)

    def wait_for_ref_driven_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector("plotly-plot", state="visible")

    def get_legend_text(self):
        return [gl.text_content() for gl in self.graph_legend.all()]

    def return_to_methods_list(self):
        self.wait_for_url_to_have("methods/pls/edit")
        self.back_btn.click()
        self.wait_for_loading_animation_to_end_unknown_data()

    def get_delete_btn(self):
        return self.delete_btn.is_disabled()

    def get_archive_btn(self):
        return self.delete_btn.is_disabled()

    def get_unarchive_btn(self):
        status = "Disabled" if self.unarchive_btn.is_disabled() else "Enabled"
        return status

    def get_export_btn(self):
        status = "Disabled" if self.export_btn.is_disabled() else "Enabled"
        return status
