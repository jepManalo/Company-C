from playwright.sync_api import Page

import src.constants as const
from src.pom.base_page import BasePage


class EvaluationMeasurementPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.next_btn = page.get_by_role("button", name="Next", exact=True)
        # Selected Measurement to use for validation purposes:
        self.measurement_for_validation = page.get_by_text(const.MEASUREMENT_1_2)
