from typing import Tuple

from playwright.sync_api import Locator, Page

from src.pom.base_page import BasePage


class QAScanEvaluationDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.evaluation_result_block = page.locator('[name="center"]').get_by_role("rowgroup")
        self.list_of_attributes = self.evaluation_result_block.get_by_role("row")

    def wait_for_details_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector("plotly-plot", state="visible")

    def extract_eval_result_values(self, row: Locator) -> Tuple[str, str]:
        comp_name = row.locator('[col-id="name"]').inner_text()
        comp_conc = row.locator('[col-id="value"]').inner_text()

        return comp_name, comp_conc
