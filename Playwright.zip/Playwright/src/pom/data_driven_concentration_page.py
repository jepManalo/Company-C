import random

from playwright.sync_api import Page

from src.pom.base_page import BasePage


class DataDrivenConcentrationPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.create_btn = page.get_by_role("button", name="Create")
        self.concentration_txt_field = page.locator("input")

    def finalize_method_creation(self):
        # We assume that the user only enters concentration value
        # from numbers 0-10 with 2 decimal places
        list_concentration_txt_field = self.concentration_txt_field.all()

        for txt_field in list_concentration_txt_field:
            concentration = round(random.uniform(0, 10), 2)
            txt_field.fill(str(concentration))

        self.create_btn.click()
        self.wait_for_url_to_not_have("create")
