import random

from playwright.sync_api import Page

from src.pom.base_page import BasePage


class ReferenceDrivenAnalytePage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.create_btn = page.get_by_role("button", name="Create")
        self.concentration_txt_field = page.locator('input[placeholder="-"]')
        self.analyte1_name_txt_field = page.get_by_text("Analyte 1")
        self.analyte_name_txt_field = page.locator('[type="text"]')
        self.analyte_name_check_btn = page.locator('[type="addon"]')

    def change_analyte_name(self, new_analyte_name: str):
        self.analyte1_name_txt_field.click()
        self.analyte_name_txt_field.fill(new_analyte_name)
        self.analyte_name_check_btn.click()

    def change_multiple_analyte_name(self, new_analyte_name: str, analyte_count=1):
        for idx in range(analyte_count):
            old_analyte_name = f"Analyte {idx}"
            self.page.get_by_text(old_analyte_name).click()
            self.analyte_name_txt_field.fill(new_analyte_name)
            self.analyte_name_check_btn.click()

    def finalize_method_creation(self):
        # We assume that the user only enters concentration value
        # from numbers 0-10 with 3 decimal places
        list_concentration_txt_field = self.concentration_txt_field.all()

        for txt_field in list_concentration_txt_field:
            concentration = round(random.uniform(0, 10), 3)
            txt_field.fill(str(concentration))

        self.create_btn.click()
        self.wait_for_url_to_not_have("create")
