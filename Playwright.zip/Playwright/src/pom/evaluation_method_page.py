from playwright.sync_api import Page

from src.pom.base_page import BasePage


class EvaluationMethodPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.method_name_txt_field = page.get_by_placeholder("Method Name")
        self.methods_list = page.locator('[data-ref="eContainer"]').get_by_role("row")
        self.next_btn = page.get_by_role("button", name="Next", exact=True)

    def filter_method(self, method_name: str):
        self.method_name_txt_field.clear()
        self.method_name_txt_field.fill(method_name)

    def select_method(self, method_name: str):
        self.filter_method(method_name)
        self.wait_for_loading_animation_to_end_with_data()
        self.page.get_by_text(method_name).click()
