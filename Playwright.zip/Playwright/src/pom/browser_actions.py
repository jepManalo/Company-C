import re

from playwright.sync_api import Page, TimeoutError, expect

import src.constants as const

"""
Parent Class of Base Page
Other Browser Actions such as Refresh,
clicking Back / Forward Button, etc. are placed here
"""


class BrowserActions:
    def __init__(self, page: Page) -> None:
        self.page = page
        self.loading = page.locator("[class=ag-loading]")
        self.empty_default = page.locator('[class="ant-empty-img-default"]')
        self.table_list_data = page.get_by_role("gridcell").and_(page.locator("[col-id]"))

    def navigate(self, url: str):
        self.page.goto(url)
        return url

    def wait_for_loading_animation_to_end_unknown_data(self):
        """
        Use this function if there is a loading animation in a list
        and it is not known whether to expect data or not.
        """
        self.page.on("requestfinished", lambda request: request.url)
        self.loading.first.wait_for(state="hidden")
        try:
            self.table_list_data.first.wait_for(state="visible", timeout=const.MID_WAIT)
        except TimeoutError:
            self.empty_default.wait_for(state="visible")

    def wait_for_loading_animation_to_end_with_data(self):
        """
        Use this function if there is a loading animation in a list
        and further data is expected to be displayed.
        """
        self.page.on("requestfinished", lambda request: request.url)
        self.loading.first.wait_for(state="hidden")
        self.table_list_data.first.wait_for(state="visible")

    def wait_for_loading_animation_to_end_without_data(self):
        """
        Use this function if there is a loading animation in a list
        and further data is not expected to be displayed.
        """
        self.page.on("requestfinished", lambda request: request.url)
        self.loading.first.wait_for(state="hidden")
        self.empty_default.wait_for(state="visible")

    def wait_for_page_to_load(self):
        self.page.wait_for_load_state(state="load")
        self.page.wait_for_load_state(state="domcontentloaded")
        self.page.wait_for_load_state(state="networkidle")

    def wait_for_url_to_have(self, url: str):
        self.page.wait_for_url(f"**{url}**")

    def wait_for_api_request_to_end(self):
        self.page.on("requestfinished", lambda request: request.url)

    def wait_for_url_to_not_have(self, url: str):
        expect(self.page).not_to_have_url(re.compile(f"({url})"), timeout=const.LONG_WAIT)

    def go_back(self):
        """
        This function imitates clicking the "Left Arrow" Icon from the browser menu
        """
        self.page.go_back()

    def refresh_page(self):
        self.page.reload()
