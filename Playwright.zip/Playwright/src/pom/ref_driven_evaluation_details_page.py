from playwright.sync_api import Page

from src.pom.base_page import BasePage
from src.utility import MethodType, Status


class ReferenceDrivenEvaluationDetailsPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.list_of_analyte = page.locator("tbody").nth(1).locator("tr")
        self.status_finished_label = page.get_by_text(Status.FINISHED.value)
        self.ref_driven_label = page.get_by_text(MethodType.REF_DRIVEN.value, exact=True)

    def get_analyte_text(self):
        return [gl.text_content() for gl in self.list_of_analyte.locator("td").nth(0).all()]

    def wait_for_details_to_load(self):
        self.page.on("requestfinished", lambda request: request.url)
        self.page.wait_for_selector('table[style*="table-layout"]', state="visible")

    def get_unit_text(self):
        return [gl.text_content() for gl in self.list_of_analyte.locator("td").nth(2).all()]
