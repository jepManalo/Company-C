from playwright.sync_api import Page

from src.pom.base_page import BasePage


class ReferenceDrivenMeasurementPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.first_measurement_entry = page.get_by_role("rowgroup").locator('[row-index="0"]')
        self.next_btn = page.get_by_role("button", name="Next", exact=True)
