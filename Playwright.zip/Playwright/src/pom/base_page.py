from playwright.sync_api import Page

import src.constants as const
from src.pom.browser_actions import BrowserActions

"""
Parent Class of all Page Objects
This is where common functionalities between Page Objects are located
"""


class BasePage(BrowserActions):
    def __init__(self, page: Page) -> None:
        super().__init__(page)

        # Left Navigation Bar
        self.methods_icon_locator = self.page.locator('[data-icon="method"]')

        # Details View Buttons
        self.make_available_btn = page.get_by_role("button", name="Make Available")
        self.back_btn = page.get_by_role("button", name="Back")
        self.archive_btn = page.get_by_role("Button", name="Archive", exact=True)
        self.unarchive_btn = page.get_by_role("Button", name="Unarchive", exact=True)
        self.delete_btn = page.get_by_role("Button", name="Delete", exact=True)
        self.confirm_deletion_btn = page.get_by_role("Button", name="OK", exact=True)
        self.export_btn = page.get_by_role("Button", name="Export", exact=True)

        # List View Buttons
        self.reload_btn = page.get_by_role("button").locator('[nztype="reload"]')

        # Others
        self.loading = page.locator("[class=ag-loading]")
        self.popup_title = page.locator(".ant-notification-topRight").locator(
            ".ant-notification-notice-message"
        )
        self.popup_msg = page.locator(".ant-notification-topRight").locator(
            ".ant-notification-notice-description"
        )
        self.first_row = page.locator('[data-ref="eContainer"]').get_by_role("row").nth(0)
        self.measurement_name_txt_field = page.get_by_placeholder("Name")
        self.breadcrumb = page.locator("nz-breadcrumb-item").nth(1)

    def make_method_available(self):
        self.make_available_btn.click()
        self.back_btn.click()

    def delete_method_in_details_page(self):
        self.delete_btn.click()
        self.confirm_deletion_btn.click()

    def get_popup_msg(self):
        return self.popup_msg.inner_text()

    def get_popup_title(self):
        return self.popup_title.inner_text()

    def wait_for_first_entry_to_have(self, column_name: str, status: str):
        """
        We allow the user to click the Reload button at most 10 times
        until FIRST ROW ENTRY is in desired <status>.
        Entries = Measurements or Methods or Evaluations
        """
        for _ in range(const.MAX_RETRIES):
            self.reload_btn.click()
            self.wait_for_loading_animation_to_end_with_data()

            # We only consider the first entry in the List
            if self.first_row.locator(f'[col-id="{column_name}"]').inner_text() == status:
                break

            # We put an implicit wait here so that we do not stress the servers
            self.page.wait_for_timeout(const.FAST_WAIT)

    def wait_confirmation_pop_up_to_appear(self):
        self.page.wait_for_selector(".ant-notification-topRight", state="visible")

    def select_measurements(self, measurements: list):
        for measurement in measurements:
            self.measurement_name_txt_field.clear()
            self.measurement_name_txt_field.fill(measurement)

            # Since we do not have a Search button,
            # outside clicks ensures that search feature is triggered.
            self.breadcrumb.click()

            self.wait_for_page_to_load()
            self.wait_for_loading_animation_to_end_with_data()
            self.page.get_by_text(measurement, exact=True).click()

    def wait_for_all_entries_to_have(self, entry_name: str, column_name: str, expected_status: str):
        """
        We allow the user to click the Reload button at most 10 times
        until ALL ENTRIES are in desired <status>.
        Entries = Measurements or Methods or Evaluations
        """
        for _ in range(const.MAX_RETRIES):
            self.reload_btn.click()
            self.wait_for_loading_animation_to_end_with_data()

            list_rows = (
                self.page.locator('[role="row"]')
                .filter(has_text=entry_name)
                .locator(f'[col-id="{column_name}"]')
                .all()
            )

            # There will be instances wherein after clicking Reload Button,
            # not all Evaluation entry is in Finished status. Some Evaluations
            # remains in Running Status and then we repeat the loop.
            list_status = [row.inner_text() for row in list_rows]

            if all(status == expected_status for status in list_status):
                break

            # We put an implicit wait here so that we do not stress the servers
            self.page.wait_for_timeout(const.FAST_WAIT)

    def go_to_link(self, link_name: str):
        """
        This clicks the link within FAST_WAIT = 3secs.
        """
        self.page.get_by_role("link", name=link_name).click(timeout=const.FAST_WAIT)

    def go_to_methods_page(self):
        self.methods_icon_locator.click()
        self.wait_for_url_to_have("methods/overview")
        self.wait_for_loading_animation_to_end_unknown_data()

    def navigate_to_dosim_evaluation_details_via_url(self, base_url, project_id, evaluation_id):
        self.page.goto(f"{base_url}p/{project_id}/evaluations/dosim/detail/{evaluation_id}/")

    def navigate_to_qascan_evaluation_details_via_url(self, base_url, project_id, evaluation_id):
        self.page.goto(f"{base_url}p/{project_id}/evaluations/qascan/detail/{evaluation_id}/")
