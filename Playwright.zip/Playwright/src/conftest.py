import os
import random
from secrets import token_hex

import pytest
from playwright.sync_api import Browser, BrowserContext, Page
from pytest_bdd import given, parsers, then, when

import src.api_utility.api_deserializer as deserializer
import src.api_utility.utils as utility
import src.constants as const
from api_utility.testdata.dosim.dosim_testdata_model import DataDrivenComparisonModel
from api_utility.testdata.qascan.qascan_testdata_model import QAScanComparisonModel
from src.api_utility.api_client import APIClient
from src.pom.base_page import BasePage
from src.pom.create_method_page import CreateMethodPage
from src.pom.data_driven_component_page import DataDrivenComponentPage
from src.pom.data_driven_concentration_page import DataDrivenConcentrationPage
from src.pom.data_driven_details_page import DataDrivenDetailsPage
from src.pom.data_driven_evaluation_details_page import DataDrivenEvaluationDetailsPage
from src.pom.data_driven_measurement_page import DataDrivenMeasurementPage
from src.pom.evaluation_measurement_page import EvaluationMeasurementPage
from src.pom.evaluation_metadata_page import EvaluationMetadataPage
from src.pom.evaluation_method_page import EvaluationMethodPage
from src.pom.evaluations_details_page import EvaluationsDetailsPage
from src.pom.evaluations_page import EvaluationsPage
from src.pom.landing_page import LandingPage
from src.pom.measurement_details_page import MeasurementDetailsPage
from src.pom.measurements_page import MeasurementsPage
from src.pom.methods_page import MethodsPage
from src.pom.overview_page import OverviewPage
from src.pom.passphrase_page import PassphrasePage
from src.pom.qascan_evaluation_details_page import QAScanEvaluationDetailsPage
from src.pom.ref_driven_analyte_page import ReferenceDrivenAnalytePage
from src.pom.ref_driven_details_page import ReferenceDrivenDetailsPage
from src.pom.ref_driven_evaluation_details_page import ReferenceDrivenEvaluationDetailsPage
from src.pom.ref_driven_measurement_page import ReferenceDrivenMeasurementPage
from src.utility import (
    MethodType,
    Status,
    compare_unordered_lists,
    load_expected_results_from_csv,
    normalize_qascan_eval_data,
    remove_trailing_zeros,
)


@pytest.fixture()
def startup_teardown(browser: Browser, request):
    section_name = request.module.__name__.split(".")[1]
    func_name = request.node.name

    # To renable video, just remove the comment on record_video_dir
    context = browser.new_context(
        locale="de-DE",
        timezone_id="Europe/Berlin",
        # record_video_dir=f"test-results/{section_name}/{func_name}/",
        # record_video_size={"width": 640, "height": 480}
    )

    context.tracing.start(sources=True, snapshots=True)

    yield context

    context.tracing.stop(path=f"test-results/{section_name}/{func_name}/trace.zip")
    context.close()


@pytest.fixture
def page_creation(startup_teardown: BrowserContext) -> Page:
    return startup_teardown.new_page()


@pytest.fixture
def env(pytestconfig):
    env = const.Env(pytestconfig.getoption("--env"))
    if env not in const.Env:
        raise AttributeError(
            f"Requested env <{env}> must be in:\n`{list(const.Env)}`",
        )
    return env


@pytest.fixture
def get_base_url(env):
    url = const.URLS[env]
    print(f"base_url: {url}")
    return url


@pytest.fixture
def get_organization(env):
    org = const.ORGANIZATION[env]
    print(f"organization: {org}")
    return org


@pytest.fixture
def get_project(env):
    proj = const.PROJECT[env]
    print(f"project: {proj}")
    return proj


@pytest.fixture
def get_details(env):
    details = const.USERS[env]
    return details


@pytest.fixture
def landing_page(page_creation) -> LandingPage:
    return LandingPage(page_creation)


@pytest.fixture
def measurements_page(page_creation) -> MeasurementsPage:
    return MeasurementsPage(page_creation)


@pytest.fixture
def passphrase_page(page_creation) -> PassphrasePage:
    return PassphrasePage(page_creation)


@pytest.fixture
def overview_page(page_creation) -> OverviewPage:
    return OverviewPage(page_creation)


@pytest.fixture
def methods_page(page_creation) -> MethodsPage:
    return MethodsPage(page_creation)


@pytest.fixture
def create_method_page(page_creation) -> CreateMethodPage:
    return CreateMethodPage(page_creation)


@pytest.fixture
def data_driven_component_page(page_creation) -> DataDrivenComponentPage:
    return DataDrivenComponentPage(page_creation)


@pytest.fixture
def data_driven_measurement_page(page_creation) -> DataDrivenMeasurementPage:
    return DataDrivenMeasurementPage(page_creation)


@pytest.fixture
def data_driven_concentration_page(page_creation) -> DataDrivenConcentrationPage:
    return DataDrivenConcentrationPage(page_creation)


@pytest.fixture
def data_driven_details_page(page_creation) -> DataDrivenDetailsPage:
    return DataDrivenDetailsPage(page_creation)


@pytest.fixture
def ref_driven_measurement_page(page_creation) -> ReferenceDrivenMeasurementPage:
    return ReferenceDrivenMeasurementPage(page_creation)


@pytest.fixture
def ref_driven_analyte_page(page_creation) -> ReferenceDrivenAnalytePage:
    return ReferenceDrivenAnalytePage(page_creation)


@pytest.fixture
def ref_driven_details_page(page_creation) -> ReferenceDrivenDetailsPage:
    return ReferenceDrivenDetailsPage(page_creation)


@pytest.fixture
def evaluations_page(page_creation) -> EvaluationsPage:
    return EvaluationsPage(page_creation)


@pytest.fixture
def evaluation_measurement_page(page_creation) -> EvaluationMeasurementPage:
    return EvaluationMeasurementPage(page_creation)


@pytest.fixture
def evaluation_method_page(page_creation) -> EvaluationMethodPage:
    return EvaluationMethodPage(page_creation)


@pytest.fixture
def evaluation_metadata_page(page_creation) -> EvaluationMetadataPage:
    return EvaluationMetadataPage(page_creation)


@pytest.fixture
def evaluations_details_page(page_creation) -> EvaluationsDetailsPage:
    return EvaluationsDetailsPage(page_creation)


@pytest.fixture
def data_driven_evaluation_details_page(page_creation) -> DataDrivenEvaluationDetailsPage:
    return DataDrivenEvaluationDetailsPage(page_creation)


@pytest.fixture
def ref_driven_evaluation_details_page(page_creation) -> ReferenceDrivenEvaluationDetailsPage:
    return ReferenceDrivenEvaluationDetailsPage(page_creation)


@pytest.fixture
def measurement_details_page(page_creation) -> MeasurementDetailsPage:
    return MeasurementDetailsPage(page_creation)


@pytest.fixture
def qascan_evaluation_details_page(page_creation) -> QAScanEvaluationDetailsPage:
    return QAScanEvaluationDetailsPage(page_creation)


@pytest.fixture
def base_page(page_creation) -> BasePage:
    return BasePage(page_creation)


@pytest.fixture
def nonce():
    return token_hex(5)


@pytest.fixture
def generate_ph_level() -> list:
    actual_min_ph = round(random.uniform(0, 14), 2)
    actual_max_ph = round(random.uniform(actual_min_ph, 14), 2)
    actual_min_ph = remove_trailing_zeros(actual_min_ph)
    actual_max_ph = remove_trailing_zeros(actual_max_ph)
    return [actual_min_ph, actual_max_ph]


def pytest_bdd_before_scenario(request, feature, scenario):
    print("Feature tags:", feature.tags)
    print("Scenario tags:", scenario.tags)

    request.config.feature_tags = feature.tags
    request.config.scenario_tags = scenario.tags


# BDD - COMMON STEPS SECTION:
def pytest_bdd_step_error(request, feature, scenario, step, step_func, step_func_args, exception):
    print(f"Step failed: {step}")


@given(parsers.parse('the user is logged in to Sphere using "{account}" account'))
def log_in_sphere_ui_step(context, account, get_base_url, landing_page: LandingPage, get_details):
    username = get_details[account]["email"]
    password = get_details[account]["password"]
    name = get_details[account]["name"]
    context.username = username
    context.password = password
    context.name = name

    url = landing_page.navigate(get_base_url)
    landing_page.login(username, password)

    return url


@pytest.fixture
def log_in_sphere_ui_fixture(context, landing_page: LandingPage):
    landing_page.navigate(context.url)
    landing_page.login(context.username, context.password)


@given(parsers.parse('the user is logged in to Sphere using "{account}" account via API'))
def log_in_sphere_api(
    context,
    request,
    account,
    get_base_url,
    get_details,
    get_project,
    get_organization,
):
    username = get_details[account]["email"]
    password = get_details[account]["password"]
    name = get_details[account]["name"]
    context.username = username
    context.password = password
    context.name = name
    context.url = get_base_url
    context.org = get_organization
    context.project = get_project

    # Get the Tags for the feature files
    feature_tag = getattr(request.config, "feature_tags")

    # Check for which product the test is for
    if any(const.MethodType.DOSIM.value in tag.lower() for tag in feature_tag):
        context.product = const.MethodType.DOSIM
    elif any(const.MethodType.QASCAN.value in tag.lower() for tag in feature_tag):
        context.product = const.MethodType.QASCAN

    # Instantiate APIClient class
    client = APIClient()

    # Create payload for log in
    payload_credential = {"email": context.username, "password": context.password}

    # Execute login API
    login_response = client.api_request(
        method=const.HttpMethod.POST.value,
        base_url=context.url,
        endpoint="tenantservice/api/v1/login/",
        json=payload_credential,
    )

    if login_response.ok:
        print("API Logged in!")

        # storing client into a context which can be called later
        context.client = client
    else:
        raise Exception("API Login failed")


@pytest.fixture
def select_organization_and_project(
    context,
    get_project,
    get_organization,
    overview_page: OverviewPage,
    measurements_page: MeasurementsPage,
    passphrase_page: PassphrasePage,
):
    passphrase_page.unlock(context.password)
    overview_page.select_org(get_organization)
    overview_page.select_project(get_project)
    measurements_page.wait_for_url_to_have("measurements/overview")
    measurements_page.wait_for_page_to_load()
    measurements_page.wait_for_loading_animation_to_end_unknown_data()


@pytest.fixture
def select_organization_and_nothing_project(
    context,
    get_organization,
    overview_page: OverviewPage,
    measurements_page: MeasurementsPage,
    passphrase_page: PassphrasePage,
):
    passphrase_page.unlock(context.password)
    overview_page.select_org(get_organization)
    overview_page.select_project("Nothing")
    measurements_page.wait_for_url_to_have("measurements/overview")
    measurements_page.wait_for_page_to_load()
    measurements_page.wait_for_loading_animation_to_end_unknown_data()


@pytest.fixture
def search_method(context, methods_page: MethodsPage):
    methods_page.filter_method_name(context.method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()


@pytest.fixture
@given("the user is in Active Methods List Page")
@when("the user navigates to Active Methods List Page")
def navigate_to_methods_list(
    select_organization_and_project,
    measurements_page: MeasurementsPage,
):
    measurements_page.go_to_methods_page()


@when("the user navigates to Active Methods List Page in Nothing project")
def navigate_to_methods_list_nothing_proj(
    select_organization_and_nothing_project,
    measurements_page: MeasurementsPage,
):
    measurements_page.go_to_methods_page()


@pytest.fixture
@given("the user is in Archived Methods List Page")
@when("the user navigates to Archived Methods List Page")
def navigate_to_archived_methods_list(
    navigate_to_methods_list,
    methods_page: MethodsPage,
):
    methods_page.go_to_archived_tab()


@when("the user navigates to Archived Methods List Page in Nothing project")
def navigate_to_archived_methods_list_nothing_proj(
    select_organization_and_nothing_project,
    measurements_page: MeasurementsPage,
    methods_page: MethodsPage,
):
    measurements_page.go_to_methods_page()
    methods_page.go_to_archived_tab()


@pytest.fixture
@given("the user is in Active Evaluations List Page")
@when("the user navigates to Active Evaluations List Page")
def navigate_to_active_evaluations_list(
    select_organization_and_project,
    measurements_page: MeasurementsPage,
):
    measurements_page.go_to_evaluations_page()


@pytest.fixture
@given("the user is in Archived Evaluations List Page")
@when("the user navigates to Archived Evaluations List Page")
def navigate_to_archived_evaluations_list(
    navigate_to_active_evaluations_list,
    evaluations_page: EvaluationsPage,
):
    evaluations_page.go_to_archived_tab()


@given(parsers.parse('the user has created "{status}" Data Driven Method "{validation}", "{nacl}"'))
def create_data_driven_method(
    context,
    status,
    validation,
    nacl,
    nonce,
    generate_ph_level,
    navigate_to_methods_list,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    data_driven_details_page: DataDrivenDetailsPage,
    data_driven_measurement_page: DataDrivenMeasurementPage,
    data_driven_concentration_page: DataDrivenConcentrationPage,
):
    context.method_name = f"{nonce}-{const.CREATE_DOSIM_SINGLE_COMPONENT}-{validation}Validation"
    context.status = status

    components_list = [const.CREATE_DOSIM_SINGLE_COMPONENT]
    if nacl == "with":
        components_list.append("NaCl")
    context.component_list = components_list

    methods_page.click_new_method_btn()
    create_method_page.initialize_data_driven_creation(context.method_name)
    data_driven_component_page.set_ph_levels(generate_ph_level[0], generate_ph_level[1])
    data_driven_component_page.add_components(context.component_list)

    if validation == "with":
        data_driven_component_page.create_method_with_validation()
        data_driven_measurement_page.select_measurements([const.CREATE_DOSIM_SINGLE_MEASUREMENT])
        data_driven_measurement_page.next_btn.click()
        data_driven_concentration_page.finalize_method_creation()
        data_driven_details_page.return_to_methods_list()
    else:
        data_driven_component_page.create_method_without_validation()

    methods_page.wait_for_first_entry_to_have("status", Status.DRAFT.value)

    if status == Status.AVAILABLE.value:
        methods_page.select_method_by_name(context.method_name)
        data_driven_details_page.make_method_available()
        methods_page.wait_for_loading_animation_to_end_with_data()
        methods_page.wait_for_first_entry_to_have("status", Status.AVAILABLE.value)
    elif status != Status.DRAFT.value:
        raise Exception("Incorrect status")


@when(
    parsers.parse(
        'the user creates a new Evaluation with "{measurement}" using the newly created method'
    )
)
def create_evaluation(
    context,
    measurement,
    methods_page: MethodsPage,
    evaluations_page: EvaluationsPage,
    evaluation_measurement_page: EvaluationMeasurementPage,
    evaluation_method_page: EvaluationMethodPage,
    evaluation_metadata_page: EvaluationMetadataPage,
):
    context.evaluation_name = f"evaluation-{context.method_name}"

    # The context below may contain one measurement -OR- a list of measurement
    context.list_measurement = measurement.split(",")

    methods_page.go_to_evaluations_page()
    evaluations_page.new_evaluation_btn.click()
    evaluation_measurement_page.select_measurements(context.list_measurement)
    evaluation_measurement_page.next_btn.click()
    evaluation_method_page.select_method(context.method_name)
    evaluation_method_page.next_btn.click()
    evaluation_metadata_page.finalize_evaluation_creation(context.evaluation_name)


@given(parsers.parse('the user has created "{status}" Reference Driven Method'))
def create_ref_driven_method(
    context,
    status,
    nonce,
    navigate_to_methods_list,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
    ref_driven_measurement_page: ReferenceDrivenMeasurementPage,
    ref_driven_analyte_page: ReferenceDrivenAnalytePage,
):
    context.analyte_name = const.PLS_SINGLE_ANALYTE
    context.method_name = f"{nonce}-{const.PLS_SINGLE_ANALYTE}"
    context.status = status

    methods_page.click_new_method_btn()
    create_method_page.initialize_ref_driven_creation(context.method_name)
    ref_driven_measurement_page.select_measurements(const.PLS_MEASUREMENT.split(","))
    ref_driven_measurement_page.next_btn.click()
    ref_driven_analyte_page.change_analyte_name(context.analyte_name)
    ref_driven_analyte_page.finalize_method_creation()

    """
    NOTE:
    =================================================================
    If the method is in "Creating" status, user is in Details Page
    If the method is in "Validating" status, user is in List Page
    We need to handle these fluctuating situations to not have flaky tests
    """
    if "methods/pls/edit" in ref_driven_details_page.page.url:
        ref_driven_details_page.return_to_methods_list()

    methods_page.wait_for_first_entry_to_have("status", Status.DRAFT.value)

    if status == Status.AVAILABLE.value:
        methods_page.select_method_by_name(context.method_name)
        ref_driven_details_page.make_method_available()
        methods_page.wait_for_loading_animation_to_end_with_data()
        methods_page.wait_for_first_entry_to_have("status", Status.AVAILABLE.value)
    elif status != Status.DRAFT.value:
        raise Exception("Incorrect status")


@given(parsers.parse('the user has created "{method_type}"'))
def create_general_driven_method(
    context,
    method_type,
    nonce,
    generate_ph_level,
    navigate_to_methods_list,
    methods_page: MethodsPage,
    create_method_page: CreateMethodPage,
    data_driven_component_page: DataDrivenComponentPage,
    data_driven_details_page: DataDrivenDetailsPage,
    ref_driven_details_page: ReferenceDrivenDetailsPage,
    ref_driven_measurement_page: ReferenceDrivenMeasurementPage,
    ref_driven_analyte_page: ReferenceDrivenAnalytePage,
):
    if method_type == MethodType.REF_DRIVEN.value:
        context.analyte_name = const.PLS_SINGLE_ANALYTE
        context.method_name = f"{nonce}-{const.PLS_SINGLE_ANALYTE}"

        methods_page.click_new_method_btn()
        create_method_page.initialize_ref_driven_creation(context.method_name)
        ref_driven_measurement_page.select_measurements(const.PLS_MEASUREMENT.split(","))
        ref_driven_measurement_page.next_btn.click()
        ref_driven_analyte_page.change_analyte_name(context.analyte_name)
        ref_driven_analyte_page.finalize_method_creation()

        if "methods/pls/edit" in ref_driven_details_page.page.url:
            ref_driven_details_page.return_to_methods_list()

        methods_page.wait_for_first_entry_to_have("status", Status.DRAFT.value)

        methods_page.select_method_by_name(context.method_name)
        ref_driven_details_page.make_method_available()

    elif method_type == MethodType.DATA_DRIVEN.value:
        context.method_name = f"{nonce}-{const.CREATE_DOSIM_SINGLE_COMPONENT}-Validation"
        components_list = [const.CREATE_DOSIM_SINGLE_COMPONENT]

        context.component_list = components_list

        methods_page.click_new_method_btn()
        create_method_page.initialize_data_driven_creation(context.method_name)
        data_driven_component_page.set_ph_levels(generate_ph_level[0], generate_ph_level[1])
        data_driven_component_page.add_components(context.component_list)
        data_driven_component_page.create_method_without_validation()

        methods_page.wait_for_first_entry_to_have("status", Status.DRAFT.value)

        methods_page.select_method_by_name(context.method_name)
        data_driven_details_page.make_method_available()

    methods_page.wait_for_loading_animation_to_end_with_data()
    methods_page.wait_for_first_entry_to_have("status", Status.AVAILABLE.value)


@when(parsers.parse('the user searches for "{method_name}"'))
def search_method_name(context, method_name, methods_page: MethodsPage):
    context.searched_method = method_name
    methods_page.filter_method_name(method_name)
    methods_page.wait_for_loading_animation_to_end_with_data()
    context.method_list_value = methods_page.get_method_list_property("name")


@when(parsers.parse('the user filters Types dropdown using "{method_type}"'))
def search_method_type(context, method_type, methods_page: MethodsPage):
    context.method_type = method_type
    methods_page.filter_types_dropdown(method_type)
    methods_page.wait_for_loading_animation_to_end_with_data()


@when(parsers.parse('the user clicks the "{action}" button in Methods List Page'))
def archive_method(
    action,
    search_method,
    methods_page: MethodsPage,
):
    if action == "Archive":
        methods_page.archive_btn_list.click()
    elif action == "Unarchive":
        methods_page.unarchive_btn_list.click()

    methods_page.wait_for_loading_animation_to_end_without_data()


@pytest.fixture
@when(parsers.parse('the user filters Method-Types dropdown using "{method_type}"'))
def search_method_type_for_evaulation(context, method_type, evaluations_page: EvaluationsPage):
    context.method_type = method_type
    evaluations_page.filter_method_types_dropdown(method_type)
    evaluations_page.wait_for_loading_animation_to_end_with_data()


@when("the user selects an evaluation from the list")
def select_evaluation(context, evaluations_page: EvaluationsPage):
    context.evaluation_name = evaluations_page.evaluation_list.nth(0).inner_text()
    evaluations_page.evaluation_list.nth(0).click()


@given(parsers.parse('the measurements in "{zip_filename}" are uploaded to the project'))
def upload_measurements(context, zip_filename):
    file_path = (
        const.API_DOSIM_TESTDATA_PATH
        if context.product == const.MethodType.DOSIM
        else os.path.join(const.API_QASCAN_TESTDATA_PATH, context.testdata)
    )

    file_path = os.path.normpath(file_path)

    utility.upload_measurement_zip_file_if_missing(
        context=context,
        subname=context.measurement_subname,
        file_path=file_path,
        zip_file_name=zip_filename,
    )


@given(parsers.parse('the expected results file "{testdata}" is loaded'))
def load_generic_expected_results(context, testdata):
    context.testdata = testdata

    base_path = (
        const.API_DOSIM_TESTDATA_PATH
        if context.product == const.MethodType.DOSIM
        else const.API_QASCAN_TESTDATA_PATH
    )

    model_class = (
        DataDrivenComparisonModel
        if context.product == const.MethodType.DOSIM
        else QAScanComparisonModel
    )

    # We load the expected data concetrations from csv
    context.list_expected_result = load_expected_results_from_csv(
        base_path=base_path, subfolder=context.testdata, model_class=model_class
    )

    # We store the measurement name substring for searching purposes later
    measurement_name = str(context.list_expected_result[0].measurement)

    if context.product == const.MethodType.DOSIM:
        context.measurement_subname = measurement_name.split("_")[1]
    else:
        context.measurement_subname = "_".join(measurement_name.split("_")[1:3])

    # We store all the measurement names from the CSV file
    context.measurement_names = {result.measurement for result in context.list_expected_result}


@when("evaluations and concentration values are derived from the uploaded measurements")
def create_dosim_evaluations(context):
    measurement_endpoint = f"analytics/api/v2/measurements/{context.proj_id}/"

    # We need to get first the list of measurement ids to be used in the evaluation
    context.list_measurement_ids = [
        utility.get_measurement_id(
            context.client,
            base_url=context.url,
            endpoint=measurement_endpoint,
            params_payload={"name": name, "archived": False},
        )
        for name in context.measurement_names
    ]

    parser = (
        deserializer.map_to_dataclass_create_dosim_eval
        if context.product == const.MethodType.DOSIM
        else deserializer.map_to_dataclass_create_qascan_eval
    )

    context.list_evaluation_ids = utility.create_and_poll_evaluation(
        context=context,
        method_id=context.method_id,
        measurement_id=context.list_measurement_ids,
        evaluation_name=context.method_name,
        parser=parser,
    )

    get_concentration_values = (
        utility.get_dosim_concentration_values
        if context.product == const.MethodType.DOSIM
        else utility.get_qascan_concentration_values
    )

    context.list_actual_api_result = get_concentration_values(
        context=context,
        list_evaluation_ids=context.list_evaluation_ids,
    )

    print("DOSIM Evaluation concentration value extraction from the API response is successful!")


@then(
    parsers.parse(
        'the API-derived concentrations match the CSV values within a "{tolerance}%" tolerance'
    )
)
def evaluate_api_and_excel_dosim_eval_conc_values(context, tolerance):
    tolerance_float = float(tolerance) / 100

    # Compare the 2 dataclasses using a primary key, in this case, measurement name
    success, issues = compare_unordered_lists(
        context.list_expected_result,
        context.list_actual_api_result,
        primary_key=lambda p: p.measurement,
        tolerance=tolerance_float,
    )

    # Print all the mismatches
    if not success:
        for issue in issues:
            key = issue.get("key")
            field = issue.get("field")
            reason = issue.get("reason")
            val1 = issue.get("value_list1")
            val2 = issue.get("value_list2")

            if val1 is not None:
                lower_limit = val1 - (val1 * tolerance_float)
                upper_limit = val1 + (val1 * tolerance_float)

                print(
                    f"\nAPI vs Excel: Measurement [{key}]:\n"
                    f"Component '{field}' mismatch ({reason}):\n"
                    f"Expected -> {val1}\n"
                    f"Expected Lower Limit -> {lower_limit}\n"
                    f"Expected Upper Limit -> {upper_limit}\n"
                    f"Actual -> {val2}\n"
                    f"Difference -> {abs(val1 - val2)}\n"
                )
            else:
                print(
                    f"\nAPI vs Excel: Measurement [{key}]:\n"
                    f"Component '{field}' mismatch ({reason}):\n"
                    f"Expected -> {val1}\n"
                    f"Actual -> {val2}\n"
                )

        raise Exception("Issues found!")
    else:
        print("All items matched within tolerance for API vs Excel.")


@then("the UI-derived concentrations match the API values exactly")
def evaluate_ui_and_api_dosim_eval_conc_values(context):
    # Compare the 2 dataclasses using a primary key, in this case, measurement name
    # Since this is UI vs API, there should be no tolerance between them
    success, issues = compare_unordered_lists(
        context.list_actual_api_result,
        context.list_actual_ui_result,
        primary_key=lambda p: p.measurement,
        tolerance=0,
    )

    # Print all the mismatches
    if not success:
        for issue in issues:
            key = issue.get("key")
            field = issue.get("field")
            reason = issue.get("reason")
            val1 = issue.get("value_list1")
            val2 = issue.get("value_list2")

            print(
                f"\nUI vs API: Measurement [{key}]:\n"
                f"Component '{field}' mismatch ({reason}):\n"
                f"Expected -> {val1} != Actual -> {val2}\n"
            )

        raise Exception("Issues found!")
    else:
        print("All items matched for UI vs API.")


@when("concentration values are extracted from the Evaluation Details via the UI")
def extract_conc_values_via_ui(
    context,
    log_in_sphere_ui_fixture,
    select_organization_and_project,
    data_driven_evaluation_details_page: DataDrivenEvaluationDetailsPage,
    qascan_evaluation_details_page: QAScanEvaluationDetailsPage,
    measurement_details_page: MeasurementDetailsPage,
):
    context.list_actual_ui_result = []

    is_dosim = context.product == const.MethodType.DOSIM

    page = data_driven_evaluation_details_page if is_dosim else qascan_evaluation_details_page
    navigator = (
        page.navigate_to_dosim_evaluation_details_via_url
        if is_dosim
        else page.navigate_to_qascan_evaluation_details_via_url
    )
    extractor = (
        page.extract_comp_concentration_values if is_dosim else page.extract_eval_result_values
    )
    data = page.list_of_components if is_dosim else page.list_of_attributes
    comparison_model = DataDrivenComparisonModel if is_dosim else QAScanComparisonModel

    print(f"Starting {context.product} Evaluation concentration value extraction from the UI...")

    for eval_id in context.list_evaluation_ids:
        # We go directly to the evaluation details page
        navigator(base_url=context.url, project_id=context.proj_id, evaluation_id=eval_id)
        page.wait_for_loading_animation_to_end_with_data()

        # We get the measurement name from the evaluation
        page.go_to_link(context.measurement_subname.split("_")[0])
        measurement_name = measurement_details_page.get_measurement_name()
        measurement_details_page.go_back()
        page.wait_for_loading_animation_to_end_with_data()

        result_data = {"measurement": measurement_name}

        # We extract concentration value for each component
        for row in data.all():
            comp_name, comp_conc = extractor(row)

            if not is_dosim:
                result_data.update(
                    normalize_qascan_eval_data(comp_name=comp_name.lower(), comp_conc=comp_conc)
                )
            else:
                result_data[comp_name.lower()] = float(comp_conc)

        context.list_actual_ui_result.append(comparison_model(**result_data))

    print(f"{context.product} Evaluation concentration value extraction from the UI is successful!")
