import copy
import csv
import json
import zipfile
from dataclasses import asdict, fields, is_dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple, Type, Union

from src.api_utility.api_models.response.create_qascan_method_response_model import QAScanMethod


class MethodType(Enum):
    DATA_DRIVEN = "Data Driven"
    REF_DRIVEN = "Reference Driven"


class Status(Enum):
    DRAFT = "Draft"
    VALIDATING = "Validating"
    AVAILABLE = "Available"
    FAILED = "Failed"
    PENDING = "Pending"
    CREATING = "Creating"
    FINISHED = "Finished"


# Order according to analytics-django backend:
# https://gitlab.com/mbio/mbiosphere/analytics-django/-/blob/main/src/analytics/method/models.py#L65-L72
METHOD_STATUS_ORDER = (
    Status.CREATING,
    Status.FAILED,
    Status.PENDING,
    Status.VALIDATING,
    Status.DRAFT,
    Status.AVAILABLE,
)


SORT_ORDER_CLICK_MAP = {
    "default": 0,
    "ascending": 1,
    "descending": 2,
}

ORDINAL_DICTIONARY = {
    "1st": 1,
    "2nd": 2,
    "3rd": 3,
    "4th": 4,
    "5th": 5,
    "6th": 6,
    "7th": 7,
    "8th": 8,
    "9th": 9,
    "10th": 10,
}


def remove_trailing_zeros(num: Union[int, float]) -> str:
    """This removes trailing zeros.

    examples:

    >>> remove_trailing_zeros(10.01)
    '10.01'
    >>> remove_trailing_zeros(10.05)
    '10.05'
    >>> remove_trailing_zeros(10.99)
    '10.99'
    >>> remove_trailing_zeros(10.50)
    '10.5'
    >>> remove_trailing_zeros(10.00)
    '10'
    >>> remove_trailing_zeros(10.0)
    '10'
    >>> remove_trailing_zeros(10)
    '10'
    >>> remove_trailing_zeros(0)
    '0'
    >>> remove_trailing_zeros(-10.10)
    '-10.1'
    """
    return f"{num:.2f}".rstrip("0").rstrip(".")


def load_expected_results_from_csv(base_path: str, subfolder: str, model_class: Type) -> List:
    data = []
    file_path = Path(base_path) / subfolder / "expected_results.csv"

    with open(file_path, mode="r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            values = {}

            for field in fields(model_class):
                name = field.name
                value = row.get(name)

                if name == "measurement":
                    values[name] = value
                elif value in (None, ""):
                    values[name] = None
                else:
                    values[name] = round(float(value), 6)

            row_data = model_class(**values)
            data.append(row_data)

        return data


def extract_dosim_suffix(context, nonce: str, method_count=None):
    """
    Generate a suffix and full method name based on context and method count.

    Args:
        context: The pytest-bdd context object.
        nonce: A unique string to ensure method name uniqueness.
        method_count (Optional): If provided, indicates multiple methods are expected.

    Returns:
        Tuple[str, str]: The generated method name and suffix.
    """
    if hasattr(context, "testdata"):
        suffix = f"-DOSIM_{context.testdata}-Consistency-Test"
    elif method_count:
        suffix = "-DOSIM-2-Persistency-test"
    else:
        suffix = "-DOSIM-Persistency-test"

    method_name = f"{nonce}{suffix}{method_count}" if method_count else f"{nonce}{suffix}"

    return method_name, suffix


def is_close(a: Any, b: Any, tolerance=0.05) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if a == b == 0:
            return True
        try:
            return abs(a - b) / max(abs(a), abs(b)) <= tolerance
        except ZeroDivisionError:
            return False

    return a == b


def compare_dataclasses(dc1: Any, dc2: Any, tolerance=0.05) -> List[Tuple[str, str, float, float]]:
    mismatches = []

    for field in fields(dc1):
        val1 = getattr(dc1, field.name)
        val2 = getattr(dc2, field.name)

        # Check if both are None
        if val1 is None and val2 is None:
            continue

        # Check for None mismatch
        if val1 is None or val2 is None:
            mismatches.append((field.name, "None value mismatch", val1, val2))
            continue

        # Check string mismatch
        if isinstance(val1, str) and isinstance(val2, str):
            if val1 != val2:
                mismatches.append((field.name, "String mismatch", val1, val2))
            continue

        # Check numerical closeness
        if not is_close(val1, val2, tolerance):
            mismatches.append(
                (field.name, f"Not within {tolerance * 100:.2f}% tolerance", val1, val2)
            )

    return mismatches


def compare_unordered_lists(
    list1: List[Any], list2: List[Any], primary_key: Callable[[Any], Any], tolerance
) -> Tuple[bool, List[dict]]:
    all_mismatch_messages = []

    # Generate a dict where:
    # key = primary_key
    # value = list of dataclasses
    dict2 = {primary_key(item): item for item in list2}

    for item1 in list1:
        key = primary_key(item1)
        item2 = dict2.get(key)

        if item2 is None:
            all_mismatch_messages.append(
                {"reason": f"Missing Measurement {key} in Actual Results!"}
            )
            continue

        mismatches = compare_dataclasses(item1, item2, tolerance)

        for field, reason, val1, val2 in mismatches:
            all_mismatch_messages.append(
                {
                    "key": key,
                    "field": field,
                    "reason": reason,
                    "value_list1": val1,
                    "value_list2": val2,
                }
            )

    return len(all_mismatch_messages) == 0, all_mismatch_messages


def safe_round(value, decimal_place) -> Optional[float]:
    """
    This rounds off a float to a certain decimal precision.
    Returns None if the value = None.

    Args:
        value: Float value to be rounded off.
        decimal_place: Number of decimal places.

    Returns:
        Rounded of float value OR None.
    """
    try:
        return round(float(value), decimal_place)
    except (TypeError, ValueError):
        return None


def count_files_in_zip(zip_path):
    """
    Counts how many files are inside the ZIP.

    Args:
        zip_path: File path of the zip file

    Returns:
        Number of files inside the zip
    """
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        file_list = zip_ref.namelist()

        # Count files (excluding directories)
        file_count = sum(1 for f in file_list if not f.endswith("/"))

    return file_count


def normalize_qascan_eval_data(comp_name: str, comp_conc: str):
    result_data = {}

    name_map = {
        "protein concentration": "protein",
        "alpha-helix": "alphahelix",
        "beta-sheet": "betasheet",
        "protein id (similarity)": "proteinIdsimilarity",
        "natriumchlorid": "nacl",
    }

    clean_name = comp_name.split(" [")[0].strip()
    key = name_map.get(clean_name)

    if key:
        result_data[key] = float(comp_conc)
    else:
        result_data[clean_name] = float(comp_conc)

    return result_data


def build_step2_attribute_string(datatable):
    selected_attrs = [
        row["attribute"] for row in datatable if row["checked"].strip().lower() == "true"
    ]

    if len(selected_attrs) == len(datatable):
        return "all"

    selected_attrs_string = ", ".join(selected_attrs)

    return selected_attrs_string


def compare_qascan_details(data1: QAScanMethod, data2: QAScanMethod) -> bool:
    """
    Use to compare 2 QA Scan method details to check if the setup is the same.
    DO NOT USE for assertion purposes.
    """
    comparison_buffer_calibrations = compare_dataclass_lists(
        data1.buffer_calibrations, data2.buffer_calibrations, ["measurement_timestamp", "id"]
    )
    comparison_components = compare_dataclass_lists(
        data1.components, data2.components, ["component.iupac", "component.id"]
    )
    comparison_formulation_calibrations = compare_dataclass_lists(
        data1.formulation_calibrations,
        data2.formulation_calibrations,
        ["measurement_timestamp", "id"],
    )

    return (
        comparison_buffer_calibrations
        and comparison_components
        and comparison_formulation_calibrations
        and data1.method_type == data2.method_type
        and data1.ph_buffer == data2.ph_buffer
        and data1.ph_formulation == data2.ph_formulation
        and data1.ph_limit_lower == data2.ph_limit_lower
        and data1.ph_limit_upper == data2.ph_limit_upper
        and data1.protein_concentration_formulation == data2.protein_concentration_formulation
        and data1.protein_concentration_limit_lower == data2.protein_concentration_limit_lower
        and data1.protein_concentration_limit_upper == data2.protein_concentration_limit_upper
        and data1.with_concentration == data2.with_concentration
        and data1.with_excipients == data2.with_excipients
        and data1.with_ph == data2.with_ph
        and data1.with_polysorbate == data2.with_polysorbate
        and data1.with_secondary_structure == data2.with_secondary_structure
        and data1.with_similarity == data2.with_similarity
    )


def remove_nested_keys(data: dict, keys_to_remove: List[str]) -> dict:
    """
    Removes nested keys from a dictionary given a list of dotted paths like 'info.id'.

    Parameters:
        data: The original dictionary (often from a dataclass via `asdict`)
        keys_to_remove: A list of key paths in dotted notation (e.g. 'info.iupac')

    Returns:
        A deep-copied dictionary with the specified nested keys removed
    """
    # Create a deep copy to avoid mutating the original dictionary
    data = copy.deepcopy(data)

    # Iterate over each nested key path to remove
    for key_path in keys_to_remove:
        # Split the dotted path into parts, e.g., 'info.iupac' → ['info', 'iupac']
        parts = key_path.split(".")

        # Start at the root of the dictionary
        d = data

        # Traverse the dictionary using all parts except the last one
        for part in parts[:-1]:
            # Ensure we are at a dictionary and the key exists
            if isinstance(d, dict) and part in d:
                # Go one level deeper
                d = d[part]
            else:
                # If any part of the path is missing, stop traversal for this path
                d = None
                break

        # After reaching the parent of the target key, remove the final key if it exists
        if isinstance(d, dict):
            # Use pop with default to avoid KeyError
            d.pop(parts[-1], None)

    # Return the modified copy
    return data


def normalize_dataclass(instance: Any, ignore_fields: List[str]) -> dict:
    """
    Converts a dataclass to a dict and removes the specified fields.
    Supports nested dataclasses.
    """
    if not is_dataclass(instance):
        raise TypeError("Only dataclass instances are supported")

    flat_dict = asdict(instance)

    return remove_nested_keys(flat_dict, ignore_fields)


def compare_dataclass_lists(list1: List[Any], list2: List[Any], ignore_fields: List[str]) -> bool:
    """
    Compares two lists of dataclasses, ignoring order and specified fields.
    """
    if len(list1) != len(list2):
        return False

    # Normalize each dataclass in the list by removing the specified fields
    normalized_1 = [normalize_dataclass(item, ignore_fields) for item in list1]
    normalized_2 = [normalize_dataclass(item, ignore_fields) for item in list2]

    # Sort the normalized dictionaries so the comparison is order-insensitive
    # Sorting is done by converting the dictionary to a tuple of sorted key-value pairs
    sorted_1 = sorted(normalized_1, key=lambda x: json.dumps(x, sort_keys=True))
    sorted_2 = sorted(normalized_2, key=lambda x: json.dumps(x, sort_keys=True))

    return sorted_1 == sorted_2
